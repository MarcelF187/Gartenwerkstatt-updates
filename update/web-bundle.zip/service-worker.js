// Service Worker – Fundament für den Offline-Betrieb (Phase 1).
//
// Ziel dieser Phase: Die gesamte App-Oberfläche (alle Seiten, Stile, Skripte
// und die per CDN geladenen Bibliotheken wie Tailwind/FontAwesome/Schriften)
// wird lokal vorgehalten, damit die App auch ganz ohne Netz startet und
// korrekt aussieht.
//
// NOCH NICHT Teil dieser Phase (kommt in Phase 2-4):
//   - Login ohne Server (Offline-Anmeldung)
//   - lokale Datenhaltung + Synchronisierung der erfassten Daten
// Deshalb werden /api-Aufrufe hier weiterhin direkt ans Netz gereicht.

const VERSION = "go-v8";
const SHELL_CACHE = `${VERSION}-shell`;   // App-Oberfläche (bei Installation)
const RUNTIME_CACHE = `${VERSION}-rt`;    // CDN/Schriften/Seiten, im Betrieb gefüllt

// Alle Seiten der App vorab holen, damit auch noch nie geöffnete Seiten offline
// verfügbar sind.
const SEITEN = [
  "/", "/home.html", "/login.html", "/2fa.html", "/account.html",
  "/tagesbericht.html", "/bautagesbericht.html", "/heckenschnitt.html",
  "/baumliste.html", "/kalender.html", "/statistik.html", "/lv-bau.html",
  "/admin/berichte.html", "/admin/mitarbeiter.html", "/admin/stammdaten.html"
];
const LOKALE_ASSETS = [
  "/manifest.webmanifest",
  "/css/theme.css", "/css/theme-light.css",
  // Tailwind (Layout) und FontAwesome (Symbole) liegen lokal im Projekt -
  // keine CDN-Abhängigkeit mehr, damit alles offline funktioniert.
  "/js/vendor/tailwind.js",
  "/css/fontawesome/all.min.css",
  "/css/fontawesome/webfonts/fa-solid-900.woff2",
  "/css/fontawesome/webfonts/fa-regular-400.woff2",
  "/css/fontawesome/webfonts/fa-brands-400.woff2",
  "/js/theme-toggle.js", "/js/pwa.js", "/js/auth.js", "/js/offline.js",
  "/js/vendor/exceljs.min.js", "/js/vendor/leaflet.js", "/js/vendor/leaflet.css",
  "/logos/GrueneOase_20J_RZN_4c-7740d298.svg",
  "/logos/favicon-64.png", "/logos/favicon-256.png",
  "/logos/icon-192.png", "/logos/icon-512.png"
];

// Fremd-Hosts, deren Dateien offline gebraucht werden (Stile/Schriften/Karten-
// Bibliothek). Werden im Betrieb beim ersten Laden zwischengespeichert.
const CDN_HOSTS = [
  "cdn.tailwindcss.com",
  "cdnjs.cloudflare.com",
  "fonts.googleapis.com",
  "fonts.gstatic.com",
  "unpkg.com"
];

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const shell = await caches.open(SHELL_CACHE);
    // Einzeln laden, damit ein fehlendes Element nicht die ganze Installation kippt
    await Promise.all([...SEITEN, ...LOKALE_ASSETS].map(async (url) => {
      try {
        const res = await fetch(url, { credentials: "same-origin" });
        // Nicht cachen, wenn die Anfrage zur Login-Seite umgeleitet wurde
        // (Installation läuft anfangs unangemeldet). Die echten Seiten werden
        // nach dem Login über die Nachricht "precache-pages" nachgeladen.
        if (res.ok && !res.redirected) await shell.put(url, res.clone());
      } catch { /* offline installiert -> wird später im Betrieb nachgeladen */ }
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

// Nach dem Login schickt die App diese Nachricht, damit ALLE Seiten jetzt
// angemeldet (also mit echtem Inhalt statt Login-Weiterleitung) im Cache landen
// und offline zuverlässig öffnen.
self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "precache-pages") {
    event.waitUntil((async () => {
      const shell = await caches.open(SHELL_CACHE);
      await Promise.all(SEITEN.map(async (url) => {
        try {
          const res = await fetch(url, { credentials: "same-origin" });
          if (res.ok && !res.redirected) await shell.put(url, res.clone());
        } catch { /* ignorieren */ }
      }));
    })());
  }
});

const istLokalesAsset = (url) =>
  /\/(css|js|logos)\//.test(url.pathname) || url.pathname === "/manifest.webmanifest";

const istCdn = (url) => CDN_HOSTS.includes(url.hostname);

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  const url = new URL(request.url);

  // 1a) Referenzdaten-GETs (Stammdaten, Kunden, Projekte, Pflegelisten):
  //     Netz zuerst und Antwort ablegen -> offline aus dem letzten Stand
  //     bedienbar, damit Formulare und Listen ohne Netz funktionieren.
  const istReferenz = url.origin === self.location.origin && (
    url.pathname.startsWith("/api/stammdaten") ||
    url.pathname === "/api/heckenschnitt/kunden" ||
    url.pathname === "/api/projekte" ||
    url.pathname.startsWith("/api/baumlisten")
  );
  if (istReferenz) {
    event.respondWith((async () => {
      const cache = await caches.open(RUNTIME_CACHE);
      try {
        const res = await fetch(request);
        if (res && res.ok) cache.put(request, res.clone());
        return res;
      } catch {
        const treffer = await cache.match(request);
        return treffer || new Response(JSON.stringify({ ok: false, offline: true }),
          { headers: { "Content-Type": "application/json" }, status: 503 });
      }
    })());
    return;
  }

  // 1b) Übrige API immer frisch aus dem Netz (Schreibvorgänge laufen über die
  //     Offline-Warteschlange in offline.js, nicht über den Service Worker).
  if (url.origin === self.location.origin && url.pathname.startsWith("/api/")) return;

  // 2) OpenStreetMap-Kacheln: cache-first wie CDN-Dateien. Für die server-lose
  // App gibt es keine gebündelte Basiskarte - Kacheln von Gebieten, die schon
  // einmal online betrachtet wurden, bleiben aber danach offline verfügbar.
  // Nie besuchte Gebiete zeigen offline weiterhin keine Kachel (kein Weg, das
  // ohne echte Kartendaten im Repo zu umgehen).
  if (url.hostname === "tile.openstreetmap.org") {
    event.respondWith((async () => {
      const cache = await caches.open(RUNTIME_CACHE);
      const treffer = await cache.match(request);
      if (treffer) return treffer;
      try {
        const res = await fetch(request);
        if (res && res.ok) cache.put(request, res.clone());
        return res;
      } catch {
        return treffer || Response.error();
      }
    })());
    return;
  }

  // 3) CDN-Dateien (Tailwind, FontAwesome, Schriften, Leaflet): cache-first,
  //    beim ersten Online-Laden ablegen -> danach offline verfügbar
  if (istCdn(url)) {
    event.respondWith((async () => {
      const cache = await caches.open(RUNTIME_CACHE);
      const treffer = await cache.match(request);
      if (treffer) return treffer;
      try {
        const res = await fetch(request);
        // "opaque" Antworten (no-cors) haben status 0 - trotzdem ablegen
        if (res && (res.ok || res.type === "opaque")) cache.put(request, res.clone());
        return res;
      } catch {
        return treffer || Response.error();
      }
    })());
    return;
  }

  // 4) Lokale statische Dateien: sofort aus dem Cache, im Hintergrund auffrischen
  if (url.origin === self.location.origin && istLokalesAsset(url)) {
    event.respondWith((async () => {
      const cache = await caches.open(SHELL_CACHE);
      const treffer = await cache.match(request);
      const netz = fetch(request).then((res) => {
        if (res && res.ok) cache.put(request, res.clone());
        return res;
      }).catch(() => treffer);
      return treffer || netz;
    })());
    return;
  }

  // 5) Seitenaufrufe: Netz zuerst; offline die gecachte Seite, sonst die
  //    Startseite, sonst ein schlichter Hinweis.
  if (request.mode === "navigate") {
    event.respondWith((async () => {
      try {
        const res = await fetch(request);
        // frisch geladene Seite gleich mit ablegen
        if (res && res.ok) {
          const cache = await caches.open(SHELL_CACHE);
          cache.put(new URL(request.url).pathname, res.clone());
        }
        return res;
      } catch {
        const cache = await caches.open(SHELL_CACHE);
        return (await cache.match(url.pathname)) ||
               (await cache.match(url.pathname + ".html")) ||
               (await cache.match("/home.html")) ||
               new Response(
                 "<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                 "<div style='font-family:sans-serif;text-align:center;padding:15vh 24px;color:#334155'>" +
                 "<h1 style='color:#065f46'>Offline</h1><p>Diese Seite wurde noch nicht geladen. Bitte einmal online öffnen.</p></div>",
                 { headers: { "Content-Type": "text/html; charset=utf-8" } }
               );
      }
    })());
  }
});
