// Automatisches Hintergrund-Update fuer die server-lose App - ganz ohne
// Play Store und ohne die APK jedes Mal von Hand neu zu installieren.
//
// Funktionsweise: Bei jedem App-Start prueft dieses Skript (nur in der
// installierten App, nie in einer normalen Browser-Vorschau) eine kleine,
// oeffentlich gehostete manifest.json (siehe .github/workflows/
// build-android-apk.yml, Schritt "Update-Bundle veroeffentlichen"). Steht
// dort eine neuere Version als die gerade laufende, wird nur der Web-Code
// (alles unter public/ - HTML/CSS/JS) im Hintergrund heruntergeladen und
// aktiviert sich selbst beim naechsten Start/Minimieren der App - ohne
// Unterbrechung einer gerade laufenden Eingabe.
//
// Ist kein Internet da, bricht der Check einfach ab und die App laeuft wie
// gewohnt komplett offline mit dem zuletzt geladenen Stand weiter. Aendert
// sich mal etwas am nativen Teil (neue Berechtigung, neues Capacitor-
// Plugin), greift dieser Mechanismus nicht - dafuer braucht es weiterhin
// eine neu gebaute, manuell installierte APK.
(function () {
  "use strict";

  // GitHub Pages statt raw.githubusercontent.com: Letzteres limitiert
  // unauthentifizierte Anfragen recht aggressiv pro IP - bei Mobilfunknetzen
  // teilen sich oft viele Nutzer dieselbe oeffentliche IP (CGNAT), sodass
  // einzelne Geraete faelschlich "kein Internet" melden, obwohl nur GitHub
  // gerade limitiert. Pages (Fastly-CDN) kennt dieses Limit nicht und ist
  // fuer das oeffentliche gartenwerkstatt-updates-Repo kostenlos.
  const MANIFEST_URL = "https://marcelf187.github.io/gartenwerkstatt-updates/update/manifest.json";
  const LETZTER_CHECK_KEY = "go-hotupdate-last-check";
  const CHECK_INTERVAL_MS = 5 * 60 * 1000; // nicht bei jeder Seiten-Navigation neu pruefen

  // Kernlogik, sowohl fuer den automatischen Check beim Start als auch fuer
  // den manuellen "Nach Updates suchen"-Knopf (siehe home.html). Gibt einen
  // Status zurueck, den die UI anzeigen kann - wichtig, weil "next()" die
  // neue Version erst beim naechsten Neustart/Minimieren aktiviert: ein
  // einfaches Minimieren reicht auf manchen Geraeten nicht, Android haelt die
  // App oft im Hintergrund am Leben, ohne den Prozess wirklich zu beenden.
  async function pruefeUndAktualisiere({ ignoriereIntervall = false } = {}) {
    if (!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform())) {
      return { status: "nicht_installierte_app" };
    }
    const CapacitorUpdater = window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater;
    if (!CapacitorUpdater) return { status: "plugin_fehlt" };

    // Muss so frueh wie moeglich aufgerufen werden - sonst geht das Plugin
    // nach ein paar Sekunden davon aus, dass das Bundle fehlerhaft ist, und
    // rollt automatisch auf die vorherige Version zurueck. Mehrfacher Aufruf
    // (z.B. durch den manuellen Knopf) ist unproblematisch.
    await CapacitorUpdater.notifyAppReady();

    if (!ignoriereIntervall) {
      const zuletzt = Number(localStorage.getItem(LETZTER_CHECK_KEY) || 0);
      if (Date.now() - zuletzt < CHECK_INTERVAL_MS) return { status: "kuerzlich_geprueft" };
    }
    localStorage.setItem(LETZTER_CHECK_KEY, String(Date.now()));

    try {
      const res = await fetch(MANIFEST_URL, { cache: "no-store" });
      if (!res.ok) return { status: "fehler" };
      const manifest = await res.json();
      if (!manifest || !manifest.version || !manifest.url) return { status: "fehler" };

      const { bundle } = await CapacitorUpdater.current();
      if (bundle && bundle.version === manifest.version) {
        return { status: "aktuell", version: manifest.version };
      }

      const { bundles } = await CapacitorUpdater.list();
      const vorhanden = (bundles || []).find((b) => b.version === manifest.version && b.status !== "error");
      const zielBundle = vorhanden || (await CapacitorUpdater.download({ url: manifest.url, version: manifest.version }));

      // Erst beim naechsten Neustart/Minimieren aktivieren (next), nicht
      // sofort (set) - so wird eine gerade laufende Eingabe nie mittendrin
      // unterbrochen.
      await CapacitorUpdater.next({ id: zielBundle.id });
      return { status: "update_geladen", version: manifest.version };
    } catch (err) {
      console.warn("Hot-Update-Check fehlgeschlagen (kein Problem, App laeuft mit der aktuellen Version weiter):", err);
      return { status: "fehler" };
    }
  }

  window.GOHotUpdate = { pruefeJetzt: () => pruefeUndAktualisiere({ ignoriereIntervall: true }) };

  function start() { pruefeUndAktualisiere(); }
  if (document.readyState === "complete") start();
  else window.addEventListener("load", start);
})();
