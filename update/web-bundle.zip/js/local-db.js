// Lokale "Datenbank im Browser" für die server-lose App (Capacitor/Android).
//
// Ersetzt Postgres komplett durch IndexedDB. Jede Tabelle aus dem Server-Schema
// wird 1:1 als Object-Store nachgebildet (gleiche Feldnamen), damit local-api.js
// die bestehenden Seiten unverändert bedienen kann. Autor: es gibt keinen
// Server mehr, der etwas absichert - dieses "Backend" läuft im selben Prozess
// wie die Seite, die es aufruft (vertrauenswürdiges Einzelgerät).
(function () {
  const DB_NAME = "gruene-oase-local";
  const DB_VERSION = 12;

  // Stores, die am geräteübergreifenden WLAN-Sync (Hauptgerät/Nebengerät,
  // siehe public/js/lan-sync.js) teilnehmen, brauchen einen client_uuid-Index
  // (Fremdschlüssel gehen über die Leitung nie als rohe id - jedes Gerät hat
  // seine eigene, unabhängige Auto-Increment-Sequenz). Bewusst NICHT unique:
  // die Eindeutigkeit stellt der Sync-Anwendungscode selbst per Dedupe sicher,
  // ein DB-Constraint waere in einer Bulk-Apply-Transaktion nur ein weiterer
  // Fehlerfall. tagesberichte/heckenschnitt hatten client_uuid schon vorher
  // (reine Offline-Idempotenz) - deren bestehender unique-Index bleibt unangetastet.
  const STORES = {
    meta: { keyPath: "key" },
    kunden: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] },
    notizen: { keyPath: "id", autoIncrement: true, indexes: [["kunde_id", "kunde_id"], ["client_uuid", "client_uuid"]] },
    // "blob" enthält das bereits im Browser komprimierte JPEG direkt als
    // Blob (IndexedDB unterstützt das nativ) - kein Umweg über Base64. Der
    // Bild-INHALT (blob) läuft NICHT über den normalen JSON-WLAN-Sync (siehe
    // SYNC_STORES_V7 unten und public/js/lan-sync.js) - nur die Metadaten
    // inkl. client_uuid; die eigentlichen Bytes holt lan-sync.js in einem
    // eigenen, getrennten Übertragungsschritt je Foto nach.
    notiz_bilder: { keyPath: "id", autoIncrement: true, indexes: [["notiz_id", "notiz_id"], ["client_uuid", "client_uuid"]] },
    users: { keyPath: "id", autoIncrement: true, indexes: [["username", "username", { unique: true }], ["client_uuid", "client_uuid"]] },
    stammdaten: { keyPath: "id", autoIncrement: true, indexes: [["typ", "typ"], ["bereich", "bereich"], ["client_uuid", "client_uuid"]] },
    tagesberichte: {
      keyPath: "id", autoIncrement: true,
      indexes: [["bericht_nr", "bericht_nr", { unique: true }], ["client_uuid", "client_uuid", { unique: true }]]
    },
    heckenschnitt: {
      keyPath: "id", autoIncrement: true,
      indexes: [["kunde", "kunde"], ["datum", "datum"], ["client_uuid", "client_uuid", { unique: true }]]
    },
    // Vorher-/Nachher-Fotos je Heckenschnitt-Eintrag - gleiches Muster wie
    // notiz_bilder: das komprimierte JPEG liegt direkt als Blob im Store.
    heckenschnitt_bilder: { keyPath: "id", autoIncrement: true, indexes: [["eintrag_id", "eintrag_id"], ["client_uuid", "client_uuid"]] },
    baumlisten: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] },
    baumlisten_items: { keyPath: "id", autoIncrement: true, indexes: [["liste_id", "liste_id"], ["client_uuid", "client_uuid"]] },
    projekte: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] },
    bautagesberichte: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid", { unique: true }]] },
    lv_bau_projekte: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] },
    lv_bau_listen: { keyPath: "id", autoIncrement: true, indexes: [["projekt_id", "projekt_id"], ["client_uuid", "client_uuid"]] },
    lv_bau_items: { keyPath: "id", autoIncrement: true, indexes: [["liste_id", "liste_id"], ["client_uuid", "client_uuid"]] },
    termine: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] },
    // Urlaubstage: neuer Store, keine bestehenden Zeilen - deshalb keine
    // eigene SYNC_STORES_V8-Nachrüstung noetig, die Schleife oben legt ihn
    // beim Anlegen direkt mit client_uuid-Index an.
    urlaub: { keyPath: "id", autoIncrement: true, indexes: [["mitarbeiter_id", "mitarbeiter_id"], ["client_uuid", "client_uuid"]] },
    // Rollen/Berechtigungen: KEIN autoIncrement - "id" ist hier bewusst ein
    // von local-api.js vergebener, bereits global eindeutiger Slug (nicht
    // pro Geraet unabhaengig hochzaehlend wie sonst ueberall), weil er direkt
    // als users.role gespeichert wird und deshalb OHNE FK-Uebersetzung
    // (siehe FK_FELDER in lan-sync.js) geraeteuebergreifend gueltig sein muss.
    // client_uuid dient hier ausschliesslich als Sync-Abgleichsschluessel wie
    // bei jedem anderen Store, nicht als Fremdschluessel-Ziel.
    rollen: { keyPath: "id", indexes: [["client_uuid", "client_uuid"]] },
    // Bauplan-Tool: "blob" enthält das gerenderte Planbild direkt (gleiches
    // Blob-Muster wie notiz_bilder) - läuft deshalb wie diese über
    // BILDER_STORES in lan-sync.js (Metadaten per normalem JSON-Sync, der
    // Bild-Inhalt selbst über den getrennten Foto-Übertragungsschritt).
    bauplaene: { keyPath: "id", autoIncrement: true, indexes: [["projekt_id", "projekt_id"], ["client_uuid", "client_uuid"]] },
    // Eine Ebene je Bauplan trägt Freihand-Striche und Notiz-Pins zusammen in
    // striche/notizen (Pixel-Koordinaten im Planbild) - siehe
    // backend/migrations/036_bauplaene.sql für die ausführliche Begründung.
    bauplan_ebenen: { keyPath: "id", autoIncrement: true, indexes: [["bauplan_id", "bauplan_id"], ["client_uuid", "client_uuid"]] },
    // Materialverbrauch (Bau) - siehe backend/migrations/039_material.sql fuer
    // die ausfuehrliche Begruendung des Datenmodells. material_katalog haelt je
    // Material-ART eine Zeile mit den Auswahlwerten als Arrays (dimensionen/
    // varianten), material_eintraege die einzelnen Verbrauchs-Zeilen.
    material_katalog: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] },
    materiallisten: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] },
    material_eintraege: { keyPath: "id", autoIncrement: true, indexes: [["liste_id", "liste_id"], ["client_uuid", "client_uuid"]] },
    // Audit-Log (rein lokal, läuft NICHT über den WLAN-Sync - kein
    // client_uuid): protokolliert Änderungen an besonders datenverlust-
    // anfälligen Stores (siehe PROTOKOLL_STORES unten) sowie unerwartete
    // JS-Fehler, damit sich Vorfälle wie "Pflegeliste plötzlich leer" im
    // Nachhinein zeitlich einordnen lassen. "bereich" ist z.B. "baumlisten_items",
    // "typ" ist "aktion" oder "fehler".
    audit_log: { keyPath: "id", autoIncrement: true, indexes: [["zeitpunkt", "zeitpunkt"], ["bereich", "bereich"], ["typ", "typ"]] }
  };

  // Stores, deren add/put/delete automatisch ins Audit-Log geschrieben
  // werden (siehe LocalDB.add/put/delete unten) - bewusst nur die für
  // Datenverlust anfälligsten Tabellen, nicht pauschal alle ~25 Stores
  // (sonst würde das Log durch harmlose Alltagsänderungen z.B. an
  // Tagesberichten geflutet und die eigentlich interessanten Einträge gingen
  // darin unter).
  const PROTOKOLL_STORES = new Set(["baumlisten", "baumlisten_items"]);

  // Mitgelieferter KG-Katalog (Kanalgrundrohr) - identisch zu dem INSERT in
  // backend/migrations/039_material.sql. Wird beim ersten Start eingespielt,
  // laesst sich in der App um eigene Materialien/Werte erweitern.
  const KG_KATALOG_SEED = [
    { name: "KG-Rohr", variante_label: "Länge", dimensionen: ["DN 110", "DN 125", "DN 160", "DN 200", "DN 250", "DN 315"], varianten: [], einheit: "m", mengen_frei: true, gruppe: "Entwässerung / KG" },
    { name: "KG-Bogen", variante_label: "Winkel", dimensionen: ["DN 110", "DN 125", "DN 160", "DN 200", "DN 250", "DN 315"], varianten: ["15°", "30°", "45°", "67°", "87°"], einheit: "Stück", gruppe: "Entwässerung / KG" },
    { name: "KG-Abzweig", variante_label: "Winkel", dimensionen: ["DN 110", "DN 125", "DN 160", "DN 200", "DN 250"], varianten: ["45°", "87°"], einheit: "Stück", gruppe: "Entwässerung / KG" },
    { name: "KG-Muffe", variante_label: "Ausführung", dimensionen: ["DN 110", "DN 125", "DN 160", "DN 200", "DN 250", "DN 315"], varianten: ["Überschiebmuffe", "Doppelmuffe", "Reduzierung"], einheit: "Stück", gruppe: "Entwässerung / KG" },
    { name: "KG-Reinigungsrohr", variante_label: "Ausführung", dimensionen: ["DN 110", "DN 125", "DN 160", "DN 200"], varianten: ["mit Deckel", "eckig", "rund"], einheit: "Stück", gruppe: "Entwässerung / KG" },
    { name: "KG-Kappe", variante_label: "Ausführung", dimensionen: ["DN 110", "DN 125", "DN 160", "DN 200", "DN 250"], varianten: ["Endkappe"], einheit: "Stück", gruppe: "Entwässerung / KG" }
  ];

  // Materialliste Phase 3 (siehe docs/material-ausbau-plan.md): Erweiterung von
  // "nur KG" auf die ueblichen GaLaBau-/Tiefbau-Materialien, gruppiert wie in
  // backend/migrations/043_material_gruppen_erweiterung.sql. Startwerte - in der
  // App ueber den Katalog-Editor frei anpassbar/erweiterbar.
  const PHASE3_KATALOG_SEED = [
    // Entwässerung / KG (Ergänzung)
    { name: "KG-Übergang", variante_label: "Ausführung", dimensionen: ["DN 110", "DN 125", "DN 160", "DN 200"], varianten: ["Guss", "Steinzeug", "PVC"], einheit: "Stück", gruppe: "Entwässerung / KG" },
    { name: "Drainagerohr", variante_label: "Ausführung", dimensionen: ["DN 100", "DN 125", "DN 160"], varianten: ["mit Filtervlies", "ohne Filtervlies"], einheit: "m", mengen_frei: true, gruppe: "Entwässerung / KG" },
    { name: "Revisions-/Kontrollschacht", variante_label: "Ausführung", dimensionen: ["DN 315", "DN 400", "DN 600"], varianten: ["Schacht", "Aufsatz", "Deckel"], einheit: "Stück", gruppe: "Entwässerung / KG" },
    { name: "Straßenablauf / Sinkkasten", variante_label: "Ausführung", dimensionen: [], varianten: ["Guss", "Kunststoff"], einheit: "Stück", gruppe: "Entwässerung / KG" },
    { name: "KG-Gleitmittel", variante_label: "Ausführung", dimensionen: [], varianten: [], einheit: "Stück (Dose)", gruppe: "Entwässerung / KG" },
    // Bewässerung / Tropfsysteme
    { name: "Tropfschlauch", variante_label: "Tropfer-Abstand", dimensionen: ["16 mm", "17 mm"], varianten: ["20 cm", "30 cm", "50 cm"], einheit: "m", mengen_frei: true, gruppe: "Bewässerung / Tropfsysteme" },
    { name: "PE-Verlegerohr", variante_label: "Ausführung", dimensionen: ["16 mm", "20 mm", "25 mm", "32 mm"], varianten: [], einheit: "m", mengen_frei: true, gruppe: "Bewässerung / Tropfsysteme" },
    { name: "Tropfer (Einzel, druckkompensiert)", variante_label: "Ausführung", dimensionen: ["2 l/h", "4 l/h", "8 l/h"], varianten: [], einheit: "Stück", gruppe: "Bewässerung / Tropfsysteme" },
    { name: "Verbinder / Fitting", variante_label: "Form", dimensionen: ["16 mm", "20 mm", "25 mm", "32 mm"], varianten: ["Kupplung", "T-Stück", "Winkel", "Endkappe", "Reduzierung"], einheit: "Stück", gruppe: "Bewässerung / Tropfsysteme" },
    { name: "Sprühdüse / Versenkregner (Pop-up)", variante_label: "Typ", dimensionen: [], varianten: ["Sprühregner", "Getrieberegner"], einheit: "Stück", gruppe: "Bewässerung / Tropfsysteme" },
    { name: "Magnetventil", variante_label: "Ausführung", dimensionen: ["3/4″", "1″"], varianten: [], einheit: "Stück", gruppe: "Bewässerung / Tropfsysteme" },
    { name: "Bewässerungssteuerung", variante_label: "Typ", dimensionen: [], varianten: ["Batterie", "230 V", "App"], einheit: "Stück", gruppe: "Bewässerung / Tropfsysteme" },
    { name: "Filter / Druckminderer", variante_label: "Ausführung", dimensionen: ["3/4″", "1″"], varianten: [], einheit: "Stück", gruppe: "Bewässerung / Tropfsysteme" },
    { name: "Absperr-/Kugelhahn", variante_label: "Ausführung", dimensionen: ["3/4″", "1″"], varianten: [], einheit: "Stück", gruppe: "Bewässerung / Tropfsysteme" },
    { name: "Anschlussadapter (Gardena-System)", variante_label: "Ausführung", dimensionen: [], varianten: [], einheit: "Stück", gruppe: "Bewässerung / Tropfsysteme" },
    // Wegebau / Pflaster / Beläge
    { name: "Pflasterstein", variante_label: "Farbe/Typ", dimensionen: ["20×10", "10×10"], varianten: [], einheit: "m²", mengen_frei: true, gruppe: "Wegebau / Pflaster / Beläge" },
    { name: "Rand-/Bordstein / Palisade", variante_label: "Ausführung", dimensionen: [], varianten: [], einheit: "m", mengen_frei: true, gruppe: "Wegebau / Pflaster / Beläge" },
    { name: "Schotter / Frostschutz", variante_label: "Ausführung", dimensionen: ["0/32", "0/45"], varianten: [], einheit: "t", mengen_frei: true, gruppe: "Wegebau / Pflaster / Beläge" },
    { name: "Splitt / Brechsand", variante_label: "Ausführung", dimensionen: ["0/5", "2/5", "1/3"], varianten: [], einheit: "t", mengen_frei: true, gruppe: "Wegebau / Pflaster / Beläge" },
    { name: "Pflasterfugensand / Fugenmörtel", variante_label: "Typ", dimensionen: [], varianten: ["Sand", "Dränmörtel"], einheit: "Sack", gruppe: "Wegebau / Pflaster / Beläge" },
    { name: "Trennvlies / Unkrautvlies", variante_label: "Ausführung", dimensionen: ["100 g", "150 g"], varianten: [], einheit: "m²", mengen_frei: true, gruppe: "Wegebau / Pflaster / Beläge" },
    { name: "Rasengitter / Schotterrasen", variante_label: "Ausführung", dimensionen: [], varianten: [], einheit: "m²", mengen_frei: true, gruppe: "Wegebau / Pflaster / Beläge" },
    // Substrat / Pflanzung / Vegetation
    { name: "Mutterboden / Pflanzerde", variante_label: "Ausführung", dimensionen: [], varianten: [], einheit: "m³", mengen_frei: true, gruppe: "Substrat / Pflanzung / Vegetation" },
    { name: "Rindenmulch / Kompost", variante_label: "Ausführung", dimensionen: [], varianten: [], einheit: "m³", mengen_frei: true, gruppe: "Substrat / Pflanzung / Vegetation" },
    { name: "Rollrasen", variante_label: "Ausführung", dimensionen: [], varianten: [], einheit: "m²", mengen_frei: true, gruppe: "Substrat / Pflanzung / Vegetation" },
    { name: "Rasensaat", variante_label: "Mischung", dimensionen: [], varianten: ["Sport", "Schatten", "Zier"], einheit: "kg", mengen_frei: true, gruppe: "Substrat / Pflanzung / Vegetation" },
    { name: "Dünger", variante_label: "Typ", dimensionen: [], varianten: ["Start", "Herbst", "Langzeit"], einheit: "Sack", gruppe: "Substrat / Pflanzung / Vegetation" },
    { name: "Baumpfahl / Anbindematerial", variante_label: "Länge", dimensionen: [], varianten: [], einheit: "Stück", gruppe: "Substrat / Pflanzung / Vegetation" },
    // Einfassung / Kanten / Zaun
    { name: "Rasenkante (Metall/Kunststoff)", variante_label: "Material", dimensionen: [], varianten: ["Metall", "Kunststoff"], einheit: "m", mengen_frei: true, gruppe: "Einfassung / Kanten / Zaun" },
    { name: "Zaunpfosten", variante_label: "Höhe", dimensionen: [], varianten: [], einheit: "Stück", gruppe: "Einfassung / Kanten / Zaun" },
    { name: "Doppelstabmatte", variante_label: "Höhe", dimensionen: [], varianten: [], einheit: "Stück", gruppe: "Einfassung / Kanten / Zaun" },
    { name: "Sichtschutz-Element", variante_label: "Material", dimensionen: [], varianten: ["Holz", "WPC", "Alu"], einheit: "Stück", gruppe: "Einfassung / Kanten / Zaun" },
    // Kleinmaterial / Verbrauch / Elektro
    { name: "Leerrohr / Kabelschutzrohr", variante_label: "Ausführung", dimensionen: ["M20", "M25", "M32", "M50"], varianten: [], einheit: "m", mengen_frei: true, gruppe: "Kleinmaterial / Verbrauch / Elektro" },
    { name: "Erdkabel (NYY)", variante_label: "Querschnitt", dimensionen: [], varianten: ["3×1,5 mm²", "5×2,5 mm²"], einheit: "m", mengen_frei: true, gruppe: "Kleinmaterial / Verbrauch / Elektro" },
    { name: "Kabelbinder / Rohrschelle / Kleinteile", variante_label: "Ausführung", dimensionen: [], varianten: [], einheit: "Stück", gruppe: "Kleinmaterial / Verbrauch / Elektro" },
    { name: "Beton / Trasszement", variante_label: "Typ", dimensionen: [], varianten: ["Fertigbeton", "Trass"], einheit: "Sack", gruppe: "Kleinmaterial / Verbrauch / Elektro" },
    { name: "Schraube/Dübel-Set", variante_label: "Ausführung", dimensionen: [], varianten: [], einheit: "Stück", gruppe: "Kleinmaterial / Verbrauch / Elektro" }
  ];

  // Stores, für die V5 bestehende Zeilen nachrüstet (client_uuid/updated_at/
  // deleted_at) - Umfang von public/js/lan-sync.js Phase 1, siehe dortigen
  // Kommentarkopf. kunden zählt mit, weil notizen.kunde_id sonst beim Sync
  // nicht auflösbar wäre.
  const SYNC_STORES_V5 = ["kunden", "baumlisten", "baumlisten_items", "termine", "notizen", "tagesberichte", "heckenschnitt"];

  // V6 (Phase 2 des WLAN-Syncs): Bau-Bereich, Stammdaten, Nutzerverwaltung,
  // Projekte kommen dazu. bautagesberichte hatte den Store (inkl. eindeutigem
  // client_uuid-Index) schon vorher, nur nie befüllte Werte - läuft hier
  // trotzdem mit, damit bestehende Berichte einen Sync-Schlüssel bekommen.
  const SYNC_STORES_V6 = ["users", "stammdaten", "projekte", "bautagesberichte", "lv_bau_projekte", "lv_bau_listen", "lv_bau_items"];

  // V7: Foto-Metadaten (notiz_bilder/heckenschnitt_bilder) nehmen jetzt auch
  // am WLAN-Sync teil - nur Metadaten (client_uuid/updated_at/deleted_at),
  // nicht der Bild-INHALT selbst (siehe Kommentar bei notiz_bilder oben).
  // Zeitstempel-Fallback bewusst nur "erstellt_am" (kein "aktualisiert_am"/
  // "created_at" wie bei V5/V6 - diese Stores hatten nie ein anderes Feld).
  const SYNC_STORES_V7 = ["notiz_bilder", "heckenschnitt_bilder"];

  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = (event) => {
        const d = req.result;
        for (const [name, def] of Object.entries(STORES)) {
          if (d.objectStoreNames.contains(name)) continue;
          const store = d.createObjectStore(name, {
            keyPath: def.keyPath,
            autoIncrement: !!def.autoIncrement
          });
          (def.indexes || []).forEach(([idxName, keyPath, opts]) => store.createIndex(idxName, keyPath, opts || {}));
        }

        // V5: die Schleife oben legt nur komplett fehlende Stores neu an und
        // rührt bestehende nicht an - für den WLAN-Sync müssen aber gerade
        // die längst vorhandenen Zeilen in SYNC_STORES_V5 nachträglich einen
        // client_uuid-Index bekommen (falls noch nicht vorhanden) und selbst
        // client_uuid/updated_at/deleted_at nachgerüstet bekommen, sonst
        // wären ältere, vor diesem Update angelegte Datensätze für den Sync
        // unsichtbar (kein Schlüssel zum Abgleichen, kein Zeitstempel für die
        // Delta-Berechnung).
        if (event.oldVersion > 0 && event.oldVersion < 5) {
          for (const name of SYNC_STORES_V5) {
            if (!d.objectStoreNames.contains(name)) continue; // sollte nicht vorkommen, sicherheitshalber
            const store = req.transaction.objectStore(name);
            if (!store.indexNames.contains("client_uuid")) {
              store.createIndex("client_uuid", "client_uuid", { unique: false });
            }
            store.openCursor().onsuccess = (ev) => {
              const cursor = ev.target.result;
              if (!cursor) return;
              const row = cursor.value;
              if (!row.client_uuid) {
                row.client_uuid = crypto.randomUUID();
                row.updated_at = row.updated_at || row.aktualisiert_am || row.erstellt_am || new Date().toISOString();
                if (row.deleted_at === undefined) row.deleted_at = null;
                cursor.update(row);
              }
              cursor.continue();
            };
          }
        }

        // V6: gleiche Nachrüstung wie V5, nur für die 7 Phase-2-Stores (siehe
        // SYNC_STORES_V6 oben). Ergänzt den Zeitstempel-Fallback um
        // "created_at" (users/bautagesberichte) - stammdaten hat gar keinen
        // eigenen Zeitstempel, bekommt also schlicht "jetzt" als erstes
        // updated_at, was für eine reine Migrations-Backfill-Zeile
        // unproblematisch ist.
        if (event.oldVersion > 0 && event.oldVersion < 6) {
          for (const name of SYNC_STORES_V6) {
            if (!d.objectStoreNames.contains(name)) continue;
            const store = req.transaction.objectStore(name);
            if (!store.indexNames.contains("client_uuid")) {
              store.createIndex("client_uuid", "client_uuid", { unique: false });
            }
            store.openCursor().onsuccess = (ev) => {
              const cursor = ev.target.result;
              if (!cursor) return;
              const row = cursor.value;
              if (!row.client_uuid) {
                row.client_uuid = crypto.randomUUID();
                row.updated_at = row.updated_at || row.aktualisiert_am || row.erstellt_am || row.created_at || new Date().toISOString();
                if (row.deleted_at === undefined) row.deleted_at = null;
                cursor.update(row);
              }
              cursor.continue();
            };
          }
        }

        // V7: gleiche Nachrüstung wie V5/V6, nur für die beiden Foto-Stores
        // (siehe SYNC_STORES_V7 oben) - deren einziger vorheriger Zeitstempel
        // ist "erstellt_am".
        if (event.oldVersion > 0 && event.oldVersion < 7) {
          for (const name of SYNC_STORES_V7) {
            if (!d.objectStoreNames.contains(name)) continue;
            const store = req.transaction.objectStore(name);
            if (!store.indexNames.contains("client_uuid")) {
              store.createIndex("client_uuid", "client_uuid", { unique: false });
            }
            store.openCursor().onsuccess = (ev) => {
              const cursor = ev.target.result;
              if (!cursor) return;
              const row = cursor.value;
              if (!row.client_uuid) {
                row.client_uuid = crypto.randomUUID();
                row.updated_at = row.updated_at || row.erstellt_am || new Date().toISOString();
                if (row.deleted_at === undefined) row.deleted_at = null;
                cursor.update(row);
              }
              cursor.continue();
            };
          }
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  async function tx(storeNames, mode, fn) {
    const d = await open();
    return new Promise((resolve, reject) => {
      const t = d.transaction(storeNames, mode);
      const stores = Array.isArray(storeNames)
        ? Object.fromEntries(storeNames.map((n) => [n, t.objectStore(n)]))
        : t.objectStore(storeNames);
      let ergebnis;
      Promise.resolve(fn(stores)).then((r) => { ergebnis = r; }, reject);
      t.oncomplete = () => resolve(ergebnis);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error);
    });
  }

  function reqToPromise(req) {
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  // Audit-Log: schreibt NIE über LocalDB.add() (das würde für "audit_log"
  // sonst eine Rekursion in sich selbst provozieren, wäre "audit_log" je in
  // PROTOKOLL_STORES) und darf unter keinen Umständen die eigentliche
  // Aktion zum Scheitern bringen - Fehler beim Protokollieren werden deshalb
  // bewusst verschluckt.
  async function schreibeProtokoll(eintrag) {
    try {
      const benutzer = (window.GOAuth && GOAuth.active && GOAuth.active()) ? GOAuth.active().username : null;
      const zeile = { zeitpunkt: new Date().toISOString(), benutzer, ...eintrag };
      await tx("audit_log", "readwrite", (s) => reqToPromise(s.add(zeile)));
    } catch { /* Protokoll ist best-effort */ }
  }

  // Baut eine kompakte, lesbare Beschreibung + Detail-JSON je nach Store -
  // bewusst schlank gehalten (nur die Felder, die bei einer nachträglichen
  // Fehlersuche wirklich weiterhelfen), nicht die komplette Zeile.
  function protokollDetails(store, zeile) {
    if (store === "baumlisten_items") {
      return {
        beschreibung: `Position #${zeile.id} in Liste #${zeile.liste_id}${zeile.deleted_at ? " (gelöscht)" : ""}`,
        detail: JSON.stringify({ id: zeile.id, liste_id: zeile.liste_id, deleted_at: zeile.deleted_at || null })
      };
    }
    if (store === "baumlisten") {
      return {
        beschreibung: `Liste #${zeile.id} "${zeile.name || ""}"${zeile.deleted_at ? " (gelöscht)" : ""}`,
        detail: JSON.stringify({ id: zeile.id, name: zeile.name || null, deleted_at: zeile.deleted_at || null })
      };
    }
    return { beschreibung: `${store} #${zeile.id}`, detail: JSON.stringify({ id: zeile.id }) };
  }

  const LocalDB = {
    async add(store, obj) {
      const ergebnis = await tx(store, "readwrite", async (s) => {
        const id = await reqToPromise(s.add(obj));
        return { ...obj, [STORES[store].keyPath]: id };
      });
      if (PROTOKOLL_STORES.has(store)) {
        schreibeProtokoll({ typ: "aktion", bereich: store, aktion: "anlegen", ...protokollDetails(store, ergebnis) });
      }
      return ergebnis;
    },
    async put(store, obj) {
      await tx(store, "readwrite", (s) => reqToPromise(s.put(obj)));
      if (PROTOKOLL_STORES.has(store)) {
        schreibeProtokoll({ typ: "aktion", bereich: store, aktion: obj.deleted_at ? "loeschen" : "bearbeiten", ...protokollDetails(store, obj) });
      }
      return obj;
    },
    async get(store, id) {
      return tx(store, "readonly", (s) => reqToPromise(s.get(id)));
    },
    async getAll(store) {
      return tx(store, "readonly", (s) => reqToPromise(s.getAll()));
    },
    async getAllByIndex(store, indexName, value) {
      return tx(store, "readonly", (s) => reqToPromise(s.index(indexName).getAll(value)));
    },
    async delete(store, id) {
      const r = await tx(store, "readwrite", (s) => reqToPromise(s.delete(id)));
      if (PROTOKOLL_STORES.has(store)) {
        schreibeProtokoll({ typ: "aktion", bereich: store, aktion: "hart_geloescht", beschreibung: `${store} #${id} endgültig gelöscht (kein Soft-Delete)`, detail: JSON.stringify({ id }) });
      }
      return r;
    },
    // Für gezielte Protokoll-Einträge ausserhalb von add/put/delete (z.B.
    // Anzahl geladener Positionen, WLAN-Sync-Zusammenfassungen, JS-Fehler -
    // siehe public/js/audit-log.js).
    async protokolliere(eintrag) { return schreibeProtokoll(eintrag); },
    async protokollEintraege(limit) {
      const alle = await tx("audit_log", "readonly", (s) => reqToPromise(s.getAll()));
      return alle.sort((a, b) => (b.zeitpunkt || "").localeCompare(a.zeitpunkt || "")).slice(0, limit || 500);
    },
    async count(store) {
      return tx(store, "readonly", (s) => reqToPromise(s.count()));
    },
    async clear(store) {
      return tx(store, "readwrite", (s) => reqToPromise(s.clear()));
    },

    // Einmalig beim allerersten Start: Stammdaten-Grunddaten importieren, damit
    // Dropdowns nicht leer sind (entspricht Migration 010_stammdaten_seed.sql).
    // local-api.js ruft das vor JEDEM /api-Aufruf auf - ein modulweiter
    // Promise-Lock verhindert, dass mehrere gleichzeitig gestartete Aufrufe
    // die Stammdaten doppelt importieren (Race Condition ohne Lock).
    ensureSeeded() {
      if (!this._seedPromise) {
        this._seedPromise = (async () => {
          const schonGesät = await this.get("meta", "stammdatenSeedV1");
          if (!schonGesät) {
            const vorhanden = await this.count("stammdaten");
            if (vorhanden === 0) {
              const res = await fetch("/js/local-data/stammdaten.seed.json");
              const zeilen = await res.json();
              await tx("stammdaten", "readwrite", (s) => {
                zeilen.forEach((z) => s.add({ typ: z.typ, bereich: z.bereich || "pflege", bezeichnung: z.bezeichnung, aktiv: true }));
              });
            }
            await this.put("meta", { key: "stammdatenSeedV1", value: true });
          }

          // Basis-Rollen (admin/vorarbeiter/mitarbeiter) - Admin bleibt hart in
          // local-api.js verdrahtet (isAdmin()), Vorarbeiter/Mitarbeiter sind
          // dagegen echt editierbar: ihre berechtigungen-Spalte wird fuer die
          // umgestellten Bereiche tatsaechlich gelesen (istVerwalterOderBerechtigung/
          // istAdminOderBerechtigung). Gleiches Muster wie
          // backend/migrations/035_rollen.sql.
          const rollenGesät = await this.get("meta", "rollenSeedV1");
          if (!rollenGesät) {
            const jetzt = new Date().toISOString();
            const basisRollen = [
              { id: "admin", name: "Admin" },
              { id: "vorarbeiter", name: "Vorarbeiter" },
              { id: "mitarbeiter", name: "Mitarbeiter" },
              { id: "vorarbeiter_pflege", name: "Vorarbeiter Pflege" },
              { id: "vorarbeiter_bau", name: "Vorarbeiter Bau" }
            ];
            for (const r of basisRollen) {
              const vorhanden = await this.get("rollen", r.id);
              if (!vorhanden) {
                await this.add("rollen", {
                  id: r.id, name: r.name, eingebaut: true, berechtigungen: {},
                  client_uuid: crypto.randomUUID(), erstellt_am: jetzt, updated_at: jetzt, deleted_at: null
                });
              }
            }
            await this.put("meta", { key: "rollenSeedV1", value: true });
          }

          // Einmaliger Backfill (unabhaengig vom obigen Seed-Guard, laeuft
          // also auch fuer schon laenger bestehende Installationen): bis jetzt
          // wurde Vorarbeiters berechtigungen-Spalte fuer "urlaub" nie
          // gelesen (unconditional durchgelassen, siehe istVerwalterOderBerechtigung
          // vorher) - ohne diesen Backfill wuerde ein Vorarbeiter beim naechsten
          // App-Start sofort seinen Urlaubs-Zugriff verlieren, da die Spalte
          // noch leer ist. Server-Pendant: backend/migrations/038_rollen_vorarbeiter_backfill.sql.
          const vorarbeiterBackfillV1 = await this.get("meta", "rollenVorarbeiterBackfillV1");
          if (!vorarbeiterBackfillV1) {
            const v = await this.get("rollen", "vorarbeiter");
            if (v && !v.deleted_at && (!v.berechtigungen || Object.keys(v.berechtigungen).length === 0)) {
              v.berechtigungen = { urlaub: { ansehen: true, anlegen: true, bearbeiten: true, loeschen: true } };
              v.updated_at = new Date().toISOString();
              await this.put("rollen", v);
            }
            await this.put("meta", { key: "rollenVorarbeiterBackfillV1", value: true });
          }

          // Vorarbeiter Pflege/Bau (Migration 040 serverseitig) nachtraeglich ergaenzen
          // fuer Installationen, die den Basis-Rollen-Seed oben schon vor dieser
          // Aenderung durchlaufen haben (dort wuerden die zwei neuen Zeilen sonst nie
          // entstehen, weil der ganze Block durch rollenSeedV1 uebersprungen wird).
          // Default-Berechtigungen identisch zum Vorarbeiter-Urlaubs-Backfill oben.
          const vorarbeiterTeilrollenV1 = await this.get("meta", "vorarbeiterTeilrollenV1");
          if (!vorarbeiterTeilrollenV1) {
            const jetzt2 = new Date().toISOString();
            const teilrollen = [
              { id: "vorarbeiter_pflege", name: "Vorarbeiter Pflege" },
              { id: "vorarbeiter_bau", name: "Vorarbeiter Bau" }
            ];
            for (const r of teilrollen) {
              const vorhanden = await this.get("rollen", r.id);
              if (!vorhanden) {
                await this.add("rollen", {
                  id: r.id, name: r.name, eingebaut: true,
                  berechtigungen: { urlaub: { ansehen: true, anlegen: true, bearbeiten: true, loeschen: true } },
                  client_uuid: crypto.randomUUID(), erstellt_am: jetzt2, updated_at: jetzt2, deleted_at: null
                });
              }
            }
            await this.put("meta", { key: "vorarbeiterTeilrollenV1", value: true });
          }

          // Rollen vollstaendig matrixgetrieben (nur Admin fest im Code):
          // hinterlegt die bisher effektiven Rechte der Basis-Rollen als
          // Matrix-Baseline, damit sich ihr Verhalten nicht aendert und der
          // Pflege/Bau-Split jetzt ueber die Matrix greift. Server-Pendant:
          // backend/migrations/041_rollen_matrix_defaults.sql. Nur setzen,
          // solange die Rolle noch am alten Default (leer oder nur "urlaub")
          // steht - eine bereits per rollen.html angepasste Matrix bleibt
          // unangetastet.
          const rollenMatrixV1 = await this.get("meta", "rollenMatrixDefaultsV1");
          if (!rollenMatrixV1) {
            const voll = { ansehen: true, anlegen: true, bearbeiten: true, loeschen: true };
            const nurAnsehen = { ansehen: true };
            const pflege = ["tagesberichte", "heckenschnitt", "baumlisten", "projekte", "notizen"];
            const bau = ["bautagesberichte", "lv_bau"];
            const baue = (bereiche, wert) => Object.fromEntries(bereiche.map((b) => [b, { ...wert }]));
            const defaults = {
              vorarbeiter: { ...baue([...pflege, ...bau], voll), urlaub: { ...voll } },
              vorarbeiter_pflege: { ...baue(pflege, voll), urlaub: { ...voll } },
              vorarbeiter_bau: { ...baue(bau, voll), urlaub: { ...voll } },
              mitarbeiter: baue([...pflege, ...bau], nurAnsehen)
            };
            const nochAmAltenDefault = (b) => {
              const keys = Object.keys(b || {});
              return keys.length === 0 || (keys.length === 1 && keys[0] === "urlaub");
            };
            const jetzt3 = new Date().toISOString();
            for (const [id, matrix] of Object.entries(defaults)) {
              const r = await this.get("rollen", id);
              if (r && !r.deleted_at && nochAmAltenDefault(r.berechtigungen)) {
                r.berechtigungen = matrix;
                r.updated_at = jetzt3;
                await this.put("rollen", r);
              }
            }
            await this.put("meta", { key: "rollenMatrixDefaultsV1", value: true });
          }

          // Neue Rolle "Buero": sieht wie bisher der volle "Vorarbeiter" alle
          // Bereiche + Urlaub + firmenweite Statistik. Im Gegenzug werden die
          // Vorarbeiter-Rollen eingeschraenkt - sie sehen ab jetzt nur noch
          // ihre eigenen Arbeitsstunden/Urlaub (der eigene Blick bleibt ueber
          // GET /api/urlaub bzw. die "eigene"-Statistik ungegatet erhalten,
          // nur "alle Mitarbeiter" faellt weg). Nur setzen, solange die
          // jeweilige Vorarbeiter-Matrix noch exakt am bisherigen Default aus
          // dem rollenMatrixDefaultsV1-Block oben steht - eine bereits per
          // rollen.html individuell angepasste Matrix bleibt unangetastet.
          // Server-Pendant: backend/migrations/044_rolle_buero.sql.
          const bueroV1 = await this.get("meta", "rollenBueroV1");
          if (!bueroV1) {
            const voll = { ansehen: true, anlegen: true, bearbeiten: true, loeschen: true };
            const pflege = ["tagesberichte", "heckenschnitt", "baumlisten", "projekte", "notizen"];
            const bau = ["bautagesberichte", "lv_bau"];
            const baue = (bereiche, wert) => Object.fromEntries(bereiche.map((b) => [b, { ...wert }]));
            const istUnveraendert = (b, bereiche) => {
              const erwarteteKeys = [...bereiche, "urlaub"];
              const keys = Object.keys(b || {});
              if (keys.length !== erwarteteKeys.length || !erwarteteKeys.every((k) => keys.includes(k))) return false;
              return erwarteteKeys.every((k) => JSON.stringify(b[k]) === JSON.stringify(voll));
            };
            const jetzt4 = new Date().toISOString();

            const bueroVorhanden = await this.get("rollen", "buero");
            if (!bueroVorhanden) {
              await this.add("rollen", {
                id: "buero", name: "Büro", eingebaut: true,
                berechtigungen: { ...baue([...pflege, ...bau], voll), urlaub: { ...voll }, statistik: { ansehen: true } },
                client_uuid: crypto.randomUUID(), erstellt_am: jetzt4, updated_at: jetzt4, deleted_at: null
              });
            }

            const vorarbeiterRollen = [
              ["vorarbeiter", [...pflege, ...bau]],
              ["vorarbeiter_pflege", pflege],
              ["vorarbeiter_bau", bau]
            ];
            for (const [id, bereicheDerRolle] of vorarbeiterRollen) {
              const r = await this.get("rollen", id);
              if (r && !r.deleted_at && istUnveraendert(r.berechtigungen, bereicheDerRolle)) {
                const neu = { ...r.berechtigungen };
                delete neu.urlaub;
                r.berechtigungen = neu;
                r.updated_at = jetzt4;
                await this.put("rollen", r);
              }
            }
            await this.put("meta", { key: "rollenBueroV1", value: true });
          }

          // Mitgelieferter KG-Katalog fuer den Materialverbrauch (siehe
          // KG_KATALOG_SEED oben). Nur einmalig und nur fuer noch nicht
          // vorhandene Namen - ein vom Nutzer erweiterter/umbenannter Katalog
          // wird dadurch nie ueberschrieben. Server-Pendant: das INSERT ...
          // WHERE NOT EXISTS in backend/migrations/039_material.sql.
          const materialGesät = await this.get("meta", "materialKatalogSeedV1");
          if (!materialGesät) {
            const vorhanden = new Set((await this.getAll("material_katalog")).map((m) => m.name));
            const jetzt = new Date().toISOString();
            for (const eintrag of KG_KATALOG_SEED) {
              if (vorhanden.has(eintrag.name)) continue;
              await this.add("material_katalog", {
                ...eintrag, eingebaut: true,
                client_uuid: crypto.randomUUID(), erstellt_am: jetzt, updated_at: jetzt, deleted_at: null
              });
            }
            await this.put("meta", { key: "materialKatalogSeedV1", value: true });
          }

          // Materialliste Phase 1: KG-Rohr auf freie Meter-Eingabe umstellen
          // (siehe docs/material-ausbau-plan.md). Nur einmalig und nur, wenn
          // die Zeile noch am Alt-Default (Stück-Varianten) haengt - ein vom
          // Nutzer bereits angepasster Katalogeintrag wird nicht ueberschrieben.
          // Server-Pendant: backend/migrations/042_material_mengen_frei.sql.
          const mengenFreiGesetzt = await this.get("meta", "materialMengenFreiV1");
          if (!mengenFreiGesetzt) {
            const kgRohr = (await this.getAll("material_katalog")).find((m) => m.name === "KG-Rohr");
            if (kgRohr && kgRohr.einheit === "Stück" && !kgRohr.mengen_frei) {
              kgRohr.mengen_frei = true;
              kgRohr.einheit = "m";
              kgRohr.varianten = [];
              kgRohr.updated_at = new Date().toISOString();
              await this.put("material_katalog", kgRohr);
            }
            await this.put("meta", { key: "materialMengenFreiV1", value: true });
          }

          // Materialliste Phase 2+3: Gruppen im Katalog + Erweiterung um die
          // ueblichen GaLaBau-/Tiefbau-Materialien (siehe PHASE3_KATALOG_SEED
          // oben und docs/material-ausbau-plan.md). Laeuft unabhaengig vom
          // materialKatalogSeedV1-Flag oben, damit auch bereits laenger
          // installierte Geraete Gruppen + neue Materialien nachtraeglich
          // bekommen. Server-Pendant: backend/migrations/
          // 043_material_gruppen_erweiterung.sql.
          const materialGruppenGesetzt = await this.get("meta", "materialGruppenErweiterungV1");
          if (!materialGruppenGesetzt) {
            // a) Bestehenden Eintraegen ohne Gruppe eine Gruppe nachtragen -
            // die mitgelieferten KG-Namen bekommen ihre feste Gruppe, alles
            // andere (vom Nutzer selbst angelegt) "Sonstiges".
            const kgNamen = new Set(KG_KATALOG_SEED.map((e) => e.name));
            for (const eintrag of await this.getAll("material_katalog")) {
              if (eintrag.gruppe) continue;
              eintrag.gruppe = kgNamen.has(eintrag.name) ? "Entwässerung / KG" : "Sonstiges";
              eintrag.updated_at = new Date().toISOString();
              await this.put("material_katalog", eintrag);
            }
            // b) Neue Materialien ergaenzen - gleiches Dedupe-Muster wie beim
            // KG-Katalog: nur einfuegen, wenn der Name noch nicht existiert.
            const vorhandenNamen = new Set((await this.getAll("material_katalog")).map((m) => m.name));
            const jetzt4 = new Date().toISOString();
            for (const eintrag of PHASE3_KATALOG_SEED) {
              if (vorhandenNamen.has(eintrag.name)) continue;
              await this.add("material_katalog", {
                ...eintrag, eingebaut: true,
                client_uuid: crypto.randomUUID(), erstellt_am: jetzt4, updated_at: jetzt4, deleted_at: null
              });
            }
            await this.put("meta", { key: "materialGruppenErweiterungV1", value: true });
          }

          // Materialverbrauch fuer Pflege: Katalogeintraege bekommen zwei
          // unabhaengige Flags "pflege"/"bau" statt bereichslos fuer alle zu
          // gelten - noetig, damit die Pflege-Materialliste nicht alle
          // Bau-Materialien (KG-Rohr, Pflasterstein, Zaunpfosten, ...) mit
          // anzeigt. Default nach Gruppe: die zwei eindeutig Pflege-relevanten
          // Gruppen bekommen pflege:true/bau:false, alle anderen (inkl.
          // "Sonstiges"/nutzerdefiniert) bau:true/pflege:false - entspricht dem
          // bisherigen Ist-Zustand, in dem ausschliesslich Bau existierte.
          // Nur setzen, wenn beide Felder noch fehlen (Nutzeranpassung ueber
          // materialkatalog.html nie ueberschreiben). Bestehende Materiallisten
          // bekommen aus demselben Grund bereich:"bau" nachgetragen. Server-
          // Pendant: backend/migrations/045_material_pflege_bau.sql.
          const materialPflegeBauGesetzt = await this.get("meta", "materialPflegeBauFlagsV1");
          if (!materialPflegeBauGesetzt) {
            const pflegeGruppen = new Set(["Bewässerung / Tropfsysteme", "Substrat / Pflanzung / Vegetation"]);
            for (const eintrag of await this.getAll("material_katalog")) {
              if (eintrag.pflege !== undefined || eintrag.bau !== undefined) continue;
              const istPflege = pflegeGruppen.has(eintrag.gruppe);
              eintrag.pflege = istPflege;
              eintrag.bau = !istPflege;
              eintrag.updated_at = new Date().toISOString();
              await this.put("material_katalog", eintrag);
            }
            for (const liste of await this.getAll("materiallisten")) {
              if (liste.bereich) continue;
              liste.bereich = "bau";
              liste.updated_at = new Date().toISOString();
              await this.put("materiallisten", liste);
            }
            await this.put("meta", { key: "materialPflegeBauFlagsV1", value: true });
          }
        })();
      }
      return this._seedPromise;
    }
  };

  window.LocalDB = LocalDB;
})();
