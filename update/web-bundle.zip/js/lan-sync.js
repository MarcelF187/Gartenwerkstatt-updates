// WLAN-Peer-Sync zwischen Tablets ohne Server (Hauptgerät/Nebengerät).
//
// Genau ein Tablet wird über public/account.html als "Hauptgerät" markiert
// (localStorage, gerätelokal - keine synchronisierte Einstellung). Alle
// anderen Geräte ("Nebengeräte") gleichen sich per Knopfdruck darüber ab
// (syncMitHauptgeraet weiter unten). Phase 1 deckte Pflege-/Wässerliste,
// Tagesbericht, Heckenschnitt, Termine, Notizen (+ kunden als schlanke
// Abhängigkeit von notizen.kunde_id) ab. Phase 2 (siehe SYNC_STORES) ergänzt
// Bau-Bereich (Bautagesbericht, LV-Bau inkl. Projekte), Stammdaten,
// Nutzerverwaltung und Pflege-Projekte.
//
// Transport: ein eigenes natives Plugin (LanSyncPlugin.java, siehe
// android/app/.../LanSyncPlugin.java) übernimmt Geräte-Erkennung im WLAN
// (NsdManager) und - nur auf dem Hauptgerät - einen selbstgebauten
// Mini-HTTP-Server. Die eigentliche Sync-Anfrage eines Nebengeräts ist ein
// ganz normaler fetch() an die gefundene Peer-IP: local-api.js patcht nur
// relative "/api/..."-Pfade (siehe dortiger Kommentar am fetch-Patch), eine
// absolute URL wie "http://192.168.1.42:47110/sync" läuft daran ungehindert
// vorbei ins echte Netz.
//
// Konfliktregel (siehe Plan .../ticklish-inventing-conway.md): bei einem
// echten Konflikt (Zeile mit bekannter client_uuid existiert auf dem
// Hauptgerät bereits anders) gewinnt IMMER die Version des Hauptgeräts - ein
// Nebengerät kann eine dort schon bekannte Zeile nicht überschreiben, nur
// wirklich neue Zeilen werden übernommen. Das verhindert stillen
// Datenverlust durch unterschiedlich eingestellte Geräte-Uhrzeiten (kein
// simples "neuester Zeitstempel gewinnt").
(function () {
  "use strict";

  const LS_HAUPTGERAET = "go-lan-sync-hauptgeraet";
  const LS_GERAETNAME = "go-lan-sync-geraetname";
  const SERVICE_TYPE_HINWEIS = "_gruoase-sync._tcp.";

  // Reihenfolge ist wichtig: Elternzeilen (z.B. kunden, baumlisten, projekte)
  // müssen vor ihren Kindern (notizen, baumlisten_items, lv_bau_listen)
  // verarbeitet werden, damit eine gerade erst angelegte Elternzeile für ihr
  // Kind in derselben Anfrage schon per client_uuid auflösbar ist. users und
  // stammdaten haben keine Abhängigkeiten, stehen aber trotzdem vorne, weil
  // sie (siehe DEDUPE_SCHLUESSEL unten) mit bereits vorhandenem Altbestand
  // abgeglichen werden und das unabhängig von jeder anderen Zeile ist.
  const SYNC_STORES = [
    "users", "stammdaten", "kunden",
    "projekte", "baumlisten", "baumlisten_items",
    "tagesberichte", "heckenschnitt", "termine", "notizen",
    "bautagesberichte",
    "lv_bau_projekte", "lv_bau_listen", "lv_bau_items"
  ];

  // <lokales FK-Feld> -> <Store, auf den es zeigt>. Auf der Leitung wird jedes
  // dieser Felder nie als rohe Zahl übertragen (unabhängige
  // Auto-Increment-Sequenzen je Gerät), sondern als "<feld ohne _id>_client_uuid".
  const FK_FELDER = {
    baumlisten: { projekt_id: "projekte" },
    baumlisten_items: { liste_id: "baumlisten" },
    notizen: { kunde_id: "kunden", liste_id: "baumlisten", item_id: "baumlisten_items" },
    lv_bau_listen: { projekt_id: "lv_bau_projekte" },
    lv_bau_items: { liste_id: "lv_bau_listen" }
  };

  // Manche Stores hatten schon VOR Phase 2 unabhängig voneinander gepflegte
  // Zeilen auf jedem Gerät (users: Mitarbeiter wurden bisher pro Tablet
  // einzeln angelegt; stammdaten: der Seed-Katalog wird von JEDEM Gerät beim
  // allerersten Start identisch importiert, siehe LocalDB.ensureSeeded). Die
  // lokale DB_VERSION-Migration (siehe local-db.js) läuft dabei IMMER vor
  // jedem Sync (sie passiert schon beim ganz normalen Öffnen der Datenbank),
  // rüstet jeder bereits vorhandenen Zeile aber eine PRO GERÄT zufällige
  // client_uuid nach - ein und derselbe Mitarbeiter/Stammdatensatz hat auf
  // zwei Geräten also von Anfang an zwei unterschiedliche client_uuids, nie
  // "keine". Ein Dedupe rein über "Zeilen ohne client_uuid" würde deshalb nie
  // greifen. Stattdessen zusätzlich zur client_uuid ein inhaltlicher
  // Schlüssel: findet sich keine Zeile mit passender client_uuid, wird unter
  // ALLEN lokalen Zeilen nach inhaltlicher Übereinstimmung gesucht (unabhängig
  // von deren eigener client_uuid). Bei einem Treffer läuft die bestehende
  // "gefunden"-Behandlung unverändert weiter: Hauptgerät behält bei einer
  // eingehenden Anfrage seine eigene Version (Konfliktregel), ein Nebengerät
  // übernimmt bei der Antwort des Hauptgeräts dessen Version inkl. dessen
  // client_uuid in die eigene, bestehende Zeile - ab dem nächsten Sync
  // greift dann für dieselbe Zeile bereits der schnelle client_uuid-Treffer.
  // Zwei nach Phase 2 unabhängig auf zwei Geräten neu angelegte Zeilen mit
  // zufällig gleichem Inhalt werden dadurch bewusst genauso zusammengeführt -
  // bei users wäre ein doppelter Benutzername ohnehin schon für den Login
  // (Suche per .find(), siehe /api/auth/login) nicht sauber unterscheidbar,
  // das Zusammenführen ist hier also die korrekte Auflösung, kein Kompromiss.
  const DEDUPE_SCHLUESSEL = {
    users: (r) => String(r.username || "").trim().toLowerCase(),
    stammdaten: (r) => [r.typ, r.bereich, String(r.bezeichnung || "").trim().toLowerCase()].join("|")
  };

  function wireFeldname(feld) {
    return feld.replace(/_id$/, "_client_uuid");
  }

  // notizen hatte "aktualisiert_am" schon vor dem Sync (siehe local-api.js) -
  // das wird hier 1:1 als dessen "updated_at" behandelt statt ein zweites,
  // separates Feld einzuführen, das sonst auseinanderlaufen könnte.
  function zeitstempelVon(store, row) {
    return store === "notizen" ? row.aktualisiert_am : row.updated_at;
  }

  function plugin() {
    if (!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform())) return null;
    return (window.Capacitor.Plugins && window.Capacitor.Plugins.LanSync) || null;
  }

  function geraeteName() {
    return (localStorage.getItem(LS_GERAETNAME) || "").trim() || "Tablet";
  }
  function istHauptgeraet() {
    return localStorage.getItem(LS_HAUPTGERAET) === "1";
  }

  let berechtigungOk = null;
  async function sicherstellenBerechtigung(LanSync) {
    if (berechtigungOk !== null) return berechtigungOk;
    try {
      const status = await LanSync.checkPermissions();
      if (status.wifi === "granted") { berechtigungOk = true; return true; }
      const angefragt = await LanSync.requestPermissions();
      berechtigungOk = angefragt.wifi === "granted";
    } catch (err) {
      // Methode/Berechtigung auf diesem Geräte-/Plugin-Stand nicht bekannt -
      // nichts erzwingen, NsdManager funktioniert auf älteren Android-
      // Versionen ohnehin ohne diese Berechtigung.
      berechtigungOk = true;
    }
    return berechtigungOk;
  }

  const BANNER_DISMISS_KEY = "go-lan-sync-berechtigung-hinweis-am";
  function zeigeBerechtigungsHinweis() {
    if (document.getElementById("goLanSyncHinweis")) return;
    const heute = new Date().toISOString().slice(0, 10);
    if (localStorage.getItem(BANNER_DISMISS_KEY) === heute) return;
    const banner = document.createElement("div");
    banner.id = "goLanSyncHinweis";
    banner.className = "fixed left-0 right-0 bottom-0 z-[998] bg-amber-50 border-t border-amber-200 text-amber-800 text-sm px-4 py-3 flex items-center justify-between gap-3 flex-wrap";
    banner.innerHTML = `
      <span><i class="fa-solid fa-triangle-exclamation mr-2"></i>Für den Geräte-Abgleich bitte die WLAN-Geräte-Berechtigung für diese App erlauben.</span>
      <span class="flex gap-2">
        <button id="goLanSyncSchliessen" class="px-3 py-1.5 rounded-lg bg-white border border-amber-300 text-xs font-bold hover:bg-amber-100">Später</button>
      </span>`;
    document.body.appendChild(banner);
    document.getElementById("goLanSyncSchliessen").addEventListener("click", () => {
      localStorage.setItem(BANNER_DISMISS_KEY, heute);
      banner.remove();
    });
  }

  // ------------------------------------------------------- FK-Übersetzung
  async function findeLokalDurchClientUuid(store, uuid) {
    if (!uuid) return null;
    const treffer = await window.LocalDB.getAllByIndex(store, "client_uuid", uuid);
    return treffer && treffer.length ? treffer[0] : null;
  }

  // Eingehende Zeile (Wire-Format mit "<feld>_client_uuid"-Strings) in ein
  // lokal speicherbares Objekt übersetzen - fehlt die Elternzeile lokal noch
  // (sollte durch die feste SYNC_STORES-Reihenfolge nicht vorkommen), bleibt
  // das Feld sicherheitshalber null statt eines harten Fehlers.
  async function loeseFksEingehendAuf(store, eingehend) {
    const zeile = { ...eingehend };
    delete zeile.id;
    const felder = FK_FELDER[store];
    if (felder) {
      for (const [feld, elternStore] of Object.entries(felder)) {
        const wireFeld = wireFeldname(feld);
        const uuid = zeile[wireFeld];
        delete zeile[wireFeld];
        const eltern = uuid ? await findeLokalDurchClientUuid(elternStore, uuid) : null;
        zeile[feld] = eltern ? eltern.id : null;
      }
    }
    return zeile;
  }

  // Lokale Zeile (rohe Integer-FKs) fürs Senden ins Wire-Format übersetzen.
  async function baueAusgehendeZeile(store, row) {
    const zeile = { ...row };
    delete zeile.id;
    const felder = FK_FELDER[store];
    if (felder) {
      for (const [feld, elternStore] of Object.entries(felder)) {
        const elternId = row[feld];
        delete zeile[feld];
        const eltern = elternId != null ? await window.LocalDB.get(elternStore, elternId) : null;
        zeile[wireFeldname(feld)] = eltern ? eltern.client_uuid : null;
      }
    }
    return zeile;
  }

  async function baueAusgehendeAenderungen(seit) {
    const changes = {};
    for (const store of SYNC_STORES) {
      const alle = await window.LocalDB.getAll(store);
      // Bewusst KEIN Filter auf deleted_at: eine gelöschte Zeile (Tombstone)
      // muss genau wie jede andere Änderung mit übertragen werden, sonst
      // taucht sie auf dem anderen Gerät beim nächsten Abgleich wieder auf.
      const geaendert = alle.filter((r) => !seit || zeitstempelVon(store, r) > seit);
      if (geaendert.length) changes[store] = await Promise.all(geaendert.map((r) => baueAusgehendeZeile(store, r)));
    }
    return changes;
  }

  // Wendet empfangene Änderungen auf die lokale IndexedDB an.
  //   ueberschreiben=false (Hauptgerät verarbeitet eine eingehende Anfrage):
  //     eine bereits bekannte client_uuid bleibt unangetastet ("Hauptgerät
  //     gewinnt") - nur wirklich neue Zeilen werden übernommen.
  //   ueberschreiben=true (Nebengerät übernimmt die Antwort des Hauptgeräts):
  //     die Antwort IST bereits die aufgelöste, autoritative Version -
  //     jede Zeile wird 1:1 übernommen (neu angelegt oder überschrieben).
  async function wendeAenderungenAn(changes, { ueberschreiben }) {
    const zaehler = { neu: 0, aktualisiert: 0, uebersprungen: 0 };
    for (const store of SYNC_STORES) {
      const rows = Array.isArray(changes && changes[store]) ? changes[store] : [];
      if (!rows.length) continue;
      const dedupeSchluessel = DEDUPE_SCHLUESSEL[store];
      // Lazy geladen und je Store nur einmal - erst wenn wirklich eine Zeile
      // ohne client_uuid-Treffer eine Dedupe-Prüfung braucht. Bewusst ALLE
      // lokalen Zeilen (nicht nur welche ohne eigene client_uuid) - siehe
      // Kommentar bei DEDUPE_SCHLUESSEL oben.
      let lokaleZeilen = null;
      for (const eingehend of rows) {
        let bestehend = await findeLokalDurchClientUuid(store, eingehend.client_uuid);
        if (!bestehend && dedupeSchluessel) {
          if (!lokaleZeilen) lokaleZeilen = await window.LocalDB.getAll(store);
          bestehend = lokaleZeilen.find((r) => dedupeSchluessel(r) === dedupeSchluessel(eingehend)) || null;
        }
        if (bestehend && !ueberschreiben) { zaehler.uebersprungen++; continue; }
        const zeile = await loeseFksEingehendAuf(store, eingehend);
        if (bestehend) {
          await window.LocalDB.put(store, { ...zeile, id: bestehend.id });
          zaehler.aktualisiert++;
        } else {
          await window.LocalDB.add(store, zeile);
          zaehler.neu++;
        }
      }
    }
    return zaehler;
  }

  // ------------------------------------------------------------ Nebengerät
  // Wird von public/account.html per Knopfdruck aufgerufen ("Mit Hauptgerät
  // synchronisieren"). Wirft bei Fehlern (kein Plugin/keine App, kein
  // Hauptgerät gefunden, Netzwerkfehler) - der Aufrufer zeigt die Meldung an.
  async function syncMitHauptgeraet() {
    const LanSync = plugin();
    if (!LanSync) throw new Error("Nur in der installierten App verfügbar.");
    if (!(await sicherstellenBerechtigung(LanSync))) {
      zeigeBerechtigungsHinweis();
      throw new Error("WLAN-Geräte-Berechtigung fehlt.");
    }

    const { geraete } = await LanSync.sucheHauptgeraet({ timeoutMs: 4000 });
    const ziel = (geraete || []).find((g) => g.ip);
    if (!ziel) throw new Error("Kein Hauptgerät im WLAN gefunden.");

    const cursorEintrag = await window.LocalDB.get("meta", "lanSyncCursor");
    const seit = cursorEintrag ? cursorEintrag.value : null;
    const changes = await baueAusgehendeAenderungen(seit);

    const res = await fetch(`http://${ziel.ip}:${ziel.port}/sync`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ deviceId: geraeteName(), since: seit, changes })
    });
    if (!res.ok) throw new Error("Sync fehlgeschlagen (HTTP " + res.status + ").");
    const antwort = await res.json();
    if (!antwort.ok) throw new Error(antwort.error || "Sync fehlgeschlagen.");

    const zaehler = await wendeAenderungenAn(antwort.changes, { ueberschreiben: true });
    await window.LocalDB.put("meta", { key: "lanSyncCursor", value: antwort.serverTime });
    return zaehler;
  }

  // ------------------------------------------------------------ Hauptgerät
  // WICHTIG: starteAlsHauptgeraet() wird an zwei Stellen aufgerufen - einmal
  // automatisch beim Laden JEDER Seite (unten, "fire and forget", niemand
  // wartet dort auf das Ergebnis) und einmal gezielt aus account.html beim
  // Umschalten/Öffnen der Seite (dort WILL man einen echten Fehler sehen,
  // z.B. wenn NsdManager.registerService scheitert oder der Port belegt ist -
  // sonst zeigt die UI faelschlich "Hauptgerät aktiviert", obwohl kein
  // Nebengerät je etwas finden könnte). Deshalb wirft diese Funktion bei
  // einem echten Fehler - der automatische Aufruf unten faengt das selbst ab.
  let serverLaeuft = false;
  let letzterFehler = null;
  async function starteAlsHauptgeraet() {
    const LanSync = plugin();
    if (!LanSync) throw new Error("Nur in der installierten App verfügbar.");
    if (serverLaeuft) return;
    if (!(await sicherstellenBerechtigung(LanSync))) {
      zeigeBerechtigungsHinweis();
      letzterFehler = "WLAN-Geräte-Berechtigung fehlt.";
      throw new Error(letzterFehler);
    }
    try {
      await LanSync.starteHauptgeraetServer({ geraetName: geraeteName() });
    } catch (err) {
      letzterFehler = String((err && err.message) || err);
      console.warn("LAN-Sync: Hauptgerät-Server konnte nicht gestartet werden:", err);
      throw err instanceof Error ? err : new Error(letzterFehler);
    }
    serverLaeuft = true;
    letzterFehler = null;
    LanSync.addListener("anfrageEmpfangen", async (event) => {
      const { anfrageId, since, changes } = event || {};
      let statusCode, bodyJson;
      try {
        await wendeAenderungenAn(changes, { ueberschreiben: false });
        const serverTime = new Date().toISOString();
        const ausgehend = await baueAusgehendeAenderungen(since);
        statusCode = 200;
        bodyJson = JSON.stringify({ ok: true, serverTime, changes: ausgehend });
      } catch (err) {
        statusCode = 500;
        bodyJson = JSON.stringify({ ok: false, error: String((err && err.message) || err) });
      }
      try {
        await LanSync.beantworteAnfrage({ anfrageId, statusCode, bodyJson });
      } catch (err) {
        console.warn("LAN-Sync: Antwort konnte nicht zugestellt werden:", err);
      }
    });
  }

  async function stoppeHauptgeraet() {
    const LanSync = plugin();
    if (!LanSync) return;
    try { await LanSync.stoppeServer(); } catch (err) { /* egal, war ggf. eh nicht aktiv */ }
    serverLaeuft = false;
    letzterFehler = null;
  }

  window.GoLanSync = {
    istHauptgeraet, geraeteName,
    setzeHauptgeraet(an) { localStorage.setItem(LS_HAUPTGERAET, an ? "1" : "0"); },
    setzeGeraeteName(name) { localStorage.setItem(LS_GERAETNAME, String(name || "").trim()); },
    syncMitHauptgeraet,
    starteAlsHauptgeraet, stoppeHauptgeraet,
    // Echter Laufzeit-Status des nativen Servers - NICHT identisch mit
    // istHauptgeraet() (das ist nur die per Umschalter gespeicherte Absicht).
    // account.html nutzt das, um einen fehlgeschlagenen Start sichtbar zu
    // machen statt faelschlich "Server läuft" zu zeigen.
    serverLaeuft: () => serverLaeuft,
    letzterFehler: () => letzterFehler,
    // Nur für automatisierte Tests exponiert (siehe scratchpad-Testskripte):
    // reine, ausschließlich auf der eigenen lokalen IndexedDB arbeitende
    // Funktionen - erlauben, die Merge-/Konfliktlogik ohne echtes WLAN/
    // natives Plugin zu prüfen (zwei Playwright-Kontexte simulieren zwei
    // Geräte und reichen sich den {since,changes}-Payload direkt weiter).
    _test: { baueAusgehendeAenderungen, wendeAenderungenAn }
  };

  // Beim Laden jeder Seite (siehe Script-Einbindung): billiger localStorage-
  // Check, kein spuerbarer Overhead auf Seiten, die den Umschalter nie
  // gesetzt haben. Das Hauptgeraet muss antwortfaehig bleiben, egal auf
  // welcher Seite gerade gearbeitet wird - deshalb kein Bezug auf
  // account.html noetig. Fire-and-forget: der Fehler wurde oben schon
  // geloggt, hier nur noch abfangen, damit keine unbehandelte Promise-
  // Ablehnung entsteht.
  if (istHauptgeraet()) {
    window.addEventListener("DOMContentLoaded", () => { starteAlsHauptgeraet().catch(() => {}); });
  }
})();
