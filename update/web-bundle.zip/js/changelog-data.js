// Gemeinsame Datenquelle für die Changelog-Einträge (neueste zuerst).
// Wird sowohl von public/changelog.html (volle Liste) als auch von
// public/js/update-popup.js ("Was ist neu?"-Popup nach einem Update) genutzt.
window.GO_CHANGELOG = [
  {
    datum: "15.08.2026",
    titel: "WLAN-Synchronisation: Phase 2 (Bau-Bereich, Stammdaten, Nutzer, Projekte)",
    punkte: [
      "Der Geräte-Abgleich unter \"Mein Konto\" umfasst jetzt zusätzlich Bautagesberichte, LV-Bau (inkl. Projekte und Positionen), Pflege-Projekte, Stammdaten (Tätigkeiten/Material/Maschinen) und die Mitarbeiterverwaltung - bisher waren nur Pflegeliste, Tagesbericht, Heckenschnitt, Termine und Notizen dabei.",
      "Mitarbeiter und Stammdaten, die auf beiden Geräten schon unabhängig voneinander bestanden (z.B. der Grund-Katalog aus der Ersteinrichtung), werden beim ersten Abgleich automatisch zusammengeführt statt verdoppelt."
    ]
  },
  {
    datum: "15.08.2026",
    titel: "Heckenschnitt-Excel-Export: Fotos jetzt direkt in der Tabelle",
    punkte: [
      "Der Excel-Export der Heckenschnitt-Rapporte zeigt Vorher-/Nachher-Fotos jetzt als kleine Bilder direkt in der Tabelle (bis zu 3 je Spalte) statt wie bisher nur die Anzahl - beim Öffnen in Excel sofort sichtbar, ohne die Original-Fotos separat suchen zu müssen.",
      "Einträge ohne Fotos bleiben unverändert schlank, es wird nichts unnötig geladen."
    ]
  },
  {
    datum: "15.08.2026",
    titel: "LV-Bau: Zoom-Leiste für die Tabellenansicht",
    punkte: [
      "Die aus der Pflegeliste bekannte Zoom-Leiste (±-Buttons plus feste Stufen von 70% bis 150%) gibt es jetzt auch bei geöffneten LV-Bau-Listen - praktisch bei vielen Spalten oder auf kleinen Bildschirmen.",
      "Die gewählte Stufe wird pro Gerät gemerkt, unabhängig von der Zoom-Einstellung der Pflegeliste."
    ]
  },
  {
    datum: "15.08.2026",
    titel: "LV-Bau: PDF-Import jetzt auch offline möglich",
    punkte: [
      "Der PDF-Import für Leistungsverzeichnisse funktioniert jetzt auch in der Offline-App, nicht mehr nur am PC mit Serveranbindung - Datei auswählen, Positionen werden direkt auf dem Gerät erkannt und in die gewohnte Vorschau zur Kontrolle geladen.",
      "Bei unklarem PDF-Layout kommt weiterhin eine verständliche Meldung mit dem Hinweis, es alternativ als CSV/Excel zu versuchen."
    ]
  },
  {
    datum: "15.08.2026",
    titel: "Bau-Bereich wieder verfügbar",
    punkte: [
      "Bautagesbericht und LV Bau sind jetzt wieder über die Startseite sowie die Navigation in \"Tagesbericht erfassen\" und der Berichte-Übersicht erreichbar - beide Bereiche waren zwischenzeitlich ausgeblendet, die Daten und Funktionen dahinter waren die ganze Zeit unverändert vorhanden."
    ]
  },
  {
    datum: "15.08.2026",
    titel: "Tagesbericht-Übernahme: verkettete Unterpositionen werden mit aufgelistet",
    punkte: [
      "Bei generischen Listen (z.B. Wässerliste) wird beim Übernehmen eines rot markierten Pflegegangs in den Tagesbericht jetzt zusätzlich angezeigt, welche mit der Hauptposition \"verketteten\" Unterpositionen (Symbol: Kette, z.B. einzelne Bäume/Standorte einer Straße) dazugehören - bisher stand dort nur die nackte Hauptposition, ohne erkennbar zu machen, was konkret erledigt wurde.",
      "Betrifft sowohl den echten Server als auch die Offline-App."
    ]
  },
  {
    datum: "15.08.2026",
    titel: "Zwei Tablets ohne Internet abgleichen (WLAN-Synchronisation)",
    punkte: [
      "Neu unter \"Mein Konto\": ein Tablet lässt sich als \"Hauptgerät\" markieren, alle anderen Tablets können sich per Knopfdruck (\"Mit Hauptgerät synchronisieren\") darüber abgleichen - beide Tablets müssen dafür im selben WLAN sein, ein Internetzugang ist nicht nötig.",
      "Übernommen werden Pflege-/Wässerlisten, Tagesberichte, Heckenschnitt-Einträge, Termine und Notizen (Text, noch ohne angehängte Fotos). Bei einem echten Konflikt (dieselbe Zeile auf beiden Geräten unterschiedlich geändert) gewinnt immer die Version des Hauptgeräts, damit nichts unbemerkt verloren geht.",
      "Der Abgleich läuft nur, wenn man ihn aktiv anstößt - keine automatische Hintergrund-Synchronisation. Auf manchen Geräten fragt Android beim ersten Mal nach einer WLAN-Berechtigung, die dafür bestätigt werden muss."
    ]
  },
  {
    datum: "14.08.2026",
    titel: "Wässerliste: Positionen stehen jetzt gruppiert nach Hauptposition",
    punkte: [
      "Zeilen einer generischen Liste (Wässerliste/Dauerpflege) werden jetzt beim Öffnen, Anlegen einer Position und nach dem Verorten automatisch so sortiert, dass alle Zeilen derselben Hauptposition zusammenstehen - Reihenfolge der Gruppen bleibt wie beim ersten Auftreten, Reihenfolge innerhalb einer Gruppe bleibt unverändert.",
      "Vorher konnten nachträglich einzeln angelegte oder per CSV/Excel ergänzte Positionen zwischen fremden Hauptpositionen \"verstreut\" auftauchen, statt bei ihrer eigenen Gruppe zu stehen. Klassische Jahrespflege-Listen sind davon nicht betroffen - deren Trennzeilen hatten schon immer eine feste Reihenfolge."
    ]
  },
  {
    datum: "14.08.2026",
    titel: "Fix: Neue Hauptposition beim Anlegen einer Wässerliste-Position wurde ignoriert",
    punkte: [
      "Beim Anlegen einer neuen Position (per Klick auf der Karte oder über \"+\" in der Tabelle) sprang der Cursor bei bereits vorbefülltem Feld automatisch ins zweite Feld (Bezeichnung) weiter - wollte man statt der zuletzt benutzten Hauptposition (z.B. \"Stockelsdorf\") eine neue nehmen (z.B. \"Stadt Bs\"), landete die Eingabe unbemerkt im falschen Feld und die Position blieb bei der alten Hauptposition hängen.",
      "Der Cursor steht jetzt immer im Hauptpositions-Feld und dessen Vorbelegung ist markiert - ein Tastendruck ersetzt sie sofort bei einer neuen Gruppe, bei gleicher Gruppe reicht weiterhin ein Tab/Klick weiter."
    ]
  },
  {
    datum: "14.08.2026",
    titel: "Notizen zur Jahrespflege: jetzt auch mit Straßenzuordnung",
    punkte: [
      "Beim Anlegen einer Notiz zur ganzen Liste (Jahrespflege) steht jetzt zusätzlich ein Feld \"Straße (optional)\" zur Auswahl - damit lässt sich z.B. festhalten \"Kunde Stadt Bs, Alt Rensefeld: Rasenmähen nicht möglich weil...\", ohne die Straße erst von Hand in den Text schreiben zu müssen.",
      "Der Kundenname bleibt wie bisher automatisch der Auftraggeber der Liste (z.B. \"Stadt Bs\") - die Straße kommt als eigenes, durchsuchbares Feld hinzu und wird in der Notizenliste mit angezeigt.",
      "Ohne Auswahl (\"— Ganze Liste —\") funktioniert es weiterhin genau wie bisher."
    ]
  },
  {
    datum: "14.08.2026",
    titel: "Fix: Zweiter Pflegegang-Termin fehlte bei Tagesbericht-Übernahme",
    punkte: [
      "Wurde zu einem bereits terminierten Pflegegang ein zweiter (\"weiterer\") Termin für heute hinzugefügt, fand die Tagesbericht-Übernahme (\"rot markierte Pflegegänge für heute\") die Position trotzdem nicht - geprüft wurde bisher nur das erste, primäre Datum des Durchgangs, nicht die zusätzlichen Termine.",
      "Betrifft sowohl den echten Server als auch die Offline-App (IndexedDB)."
    ]
  },
  {
    datum: "14.08.2026",
    titel: "Zwei Fehler behoben: Mitarbeiter im Tagesbericht + zweites Pflegegang-Datum",
    punkte: [
      "Tagesbericht: Wurden Mitarbeiter (oder Material/Maschinen) eingetragen und dann die Seite gewechselt, fehlte beim Zurückkommen immer der zuletzt hinzugefügte Eintrag - der Entwurf wurde nur bei Tastatureingaben zwischengespeichert, nicht beim Klick auf \"Hinzufügen\". Jetzt wird nach jeder Änderung sofort gespeichert.",
      "Pflegeliste: Bei älteren, noch nicht auf das aktuelle Format migrierten Positionen wurde ein zweites Datum (\"Weiteren Termin hinzufügen\") beim Speichern lautlos verworfen bzw. hat das ursprüngliche Datum überschrieben, statt es zu ergänzen. Betroffene Einträge repariert sich jetzt beim nächsten Bearbeiten automatisch selbst."
    ]
  },
  {
    datum: "14.08.2026",
    titel: "Pflegeliste: Aktionen-Leiste einklappbar",
    punkte: [
      "Die Buttons in der geöffneten Liste (Exportieren, Umbenennen, Notizen, Löschen usw.) sind jetzt hinter \"⋯ Aktionen\" versteckt, statt die Kopfzeile dauerhaft zuzustellen - nur \"Zurück\" bleibt immer sichtbar.",
      "Der Auf-/Zugeklappt-Zustand wird gerätweit gemerkt: wer die Leiste öfter braucht, muss sie nicht bei jeder Liste neu aufklappen."
    ]
  },
  {
    datum: "14.08.2026",
    titel: "Pflegelisten lassen sich mit Notizen verknüpfen",
    punkte: [
      "Neuer Button \"📝 Notizen\" in jeder geöffneten Liste: Jahrespflege-Listen verknüpfen sich als Ganzes mit einem Kunden (der \"Kunde\" ist hier der Auftraggeber der Liste, z.B. \"Stadt Bs\"), bei Wässerliste/Kunden-Dauerpflege gibt es zusätzlich ein eigenes Notiz-Symbol je Position.",
      "Der Kundenname wird beim Öffnen automatisch vorgeschlagen (Auftraggeber der Liste bzw. Kunde/Hauptposition der Position) und muss meist nicht von Hand eingetippt werden - existiert der Kunde in Notizen schon, wird er wiederverwendet, sonst automatisch neu angelegt.",
      "Die neuen Notizen erscheinen ganz normal auch in der Notizen-Übersicht (public/notizen.html) beim jeweiligen Kunden, inklusive Excel-/Word-Export - die Verknüpfung ist rein zusätzlich, nichts an der bestehenden Notizen-Verwaltung ändert sich."
    ]
  },
  {
    datum: "14.08.2026",
    titel: "Neue Listenart: Kunden-Dauerpflege mit Kalender-Verknüpfung",
    punkte: [
      "Beim Anlegen einer Liste steht jetzt neben Pflegeliste und Wässerliste eine dritte Art zur Auswahl: \"Kunden-Dauerpflege\" - für Kunden mit festem Intervall statt fester Monatsspalten (Spalten: Kunde, Adresse, Leistung, Intervall in Wochen, Notiz).",
      "Pro Kunde lässt sich per Klick auf \"🔁 Verknüpfen\" ein Startdatum festlegen - daraus entsteht automatisch ein wiederkehrender Kalendertermin im gewünschten Rhythmus (z.B. \"Löwe\" alle 4 Wochen), der sich im Kalender wie jeder andere Serientermin von selbst fortschreibt.",
      "Die Spalte \"Kalender\" zeigt direkt in der Liste, alle wie viele Wochen ein Kunde eingeplant ist und wann der nächste Termin ansteht - über \"Verknüpfung lösen\" lässt sich die Kalender-Anbindung jederzeit wieder entfernen, ohne die Position selbst zu löschen."
    ]
  },
  {
    datum: "12.08.2026",
    titel: "Pflege-/Wässerlisten lassen sich umbenennen",
    punkte: [
      "Neuer Stift-Button auf jeder Listen-Kachel sowie in der geöffneten Liste selbst - Name direkt anpassen, ohne die Liste neu anzulegen.",
      "Projekt-Zuordnung, Auftraggeber und Beschreibung der Liste bleiben beim Umbenennen unverändert erhalten."
    ]
  },
  {
    datum: "12.08.2026",
    titel: "Alle vier Anleitungen komplett aktualisiert",
    punkte: [
      "Kurzanleitung, Ausführliche Anleitung, Technische Anleitung und Code-Statistik wurden komplett neu erstellt - mit frischen Screenshots aus der aktuellen Version und allen neuen Funktionen (Kalender-Einladungen, Geräte-Kalender-Sync, Wässerliste, Berichte-Gruppierung u.v.m.).",
      "Alle vier Dokumente tragen jetzt den Vermerk \"Entwicklung und Wartung: Marcel_F_\"."
    ]
  },
  {
    datum: "12.08.2026",
    titel: "Tagesbericht-Übernahme: \"Gewässert\" steht jetzt bei Wässerliste-Positionen dabei",
    punkte: [
      "Werden abgehakte Positionen aus einer Wässerliste in den Tagesbericht übernommen, steht jetzt \"Gewässert: <Position>\" in der Tätigkeitenliste, statt nur der nackten Position.",
      "So ist im Tagesbericht auch ohne Rückfrage erkennbar, welche Tätigkeit an der Position ausgeführt wurde - bei der klassischen Pflegeliste ändert sich nichts."
    ]
  },
  {
    datum: "12.08.2026",
    titel: "Berichte-Übersicht: Baustellen-Gruppe dauerhaft umbenennen",
    punkte: [
      "In einem geöffneten Kunden-Ordner gibt es jetzt für Vorarbeiter/Admins den Button \"Umbenennen\": trägt für ALLE Berichte dieser Baustelle (über alle Monate hinweg, egal welche Schreibweise) einen einheitlichen Namen fest in die gespeicherten Berichte ein.",
      "Damit lässt sich z.B. \"Stadt Bs\"/\"stadt bs\"/\"Stadt Bs Wässern\" dauerhaft auf eine Schreibweise vereinheitlichen, statt sich nur auf die automatische Gruppierung in der Übersicht zu verlassen."
    ]
  },
  {
    datum: "12.08.2026",
    titel: "Berichte-Übersicht: Zusammengesetzte Baustellennamen werden erkannt",
    punkte: [
      "Baustellennamen, die mit einem kürzeren, bereits bekannten Namen beginnen, werden jetzt automatisch derselben Gruppe zugeordnet: \"Stadt Bs Wässern\" landet z.B. zusammen mit \"Stadt Bs\" in einem gemeinsamen Kunden-Ordner.",
      "Es wird dabei immer ganzwortweise verglichen, damit z.B. \"Stadt Bshaltestelle\" NICHT fälschlich mit \"Stadt Bs\" zusammengefasst wird."
    ]
  },
  {
    datum: "11.08.2026",
    titel: "Berichte-Übersicht: Baustellen unabhängig von Groß-/Kleinschreibung gruppiert",
    punkte: [
      "\"Stadt Bs\", \"stadt bs\" und \"STADT BS\" landen jetzt als eine gemeinsame Baustelle in der Kunden-Ordneransicht und im Filter-Dropdown, statt in mehrere getrennte Einträge zu zerfallen.",
      "Angezeigt wird dabei die in den Berichten am häufigsten vorkommende Schreibweise; die einzelnen Berichte selbst zeigen weiterhin ihre jeweils tatsächlich gespeicherte Schreibweise."
    ]
  },
  {
    datum: "11.08.2026",
    titel: "Pflegeliste: Suche nach Straßenname findet jetzt auch die Positionen darunter",
    punkte: [
      "Tippt man einen Straßennamen in die Suche, werden jetzt nicht mehr nur die Überschriftzeile, sondern auch alle dazugehörigen Positionen darunter angezeigt.",
      "Bisher stand der Straßenname nur auf der Trennzeile selbst, die einzelnen Positionen (deren eigenes Stadtteil-Feld meist leer ist) fielen aus der Trefferliste raus."
    ]
  },
  {
    datum: "11.08.2026",
    titel: "Kalender: automatische Übernahme aus dem Geräte-Kalender",
    punkte: [
      "Neuer Knopf \"Gerätekalender\" verbindet die App mit dem Kalender des Tablets (Google, Outlook, ...) - einmal die gewünschten Kalender auswählen, danach werden neue/geänderte Termine automatisch beim Öffnen der Kalenderseite übernommen.",
      "Braucht nur die einmalige Android-Kalender-Berechtigung, kein eigenes Konto oder API-Key in der App.",
      "Reiner Lesezugriff: Änderungen in unserer App werden nicht in den Geräte-Kalender zurückgeschrieben, gelöschte Termine im Geräte-Kalender werden hier nicht automatisch als abgesagt markiert."
    ]
  },
  {
    datum: "10.08.2026",
    titel: "Kalender: Straßenname statt Stadtteil bei fälligen Pflegegängen",
    punkte: [
      "Fällige Pflegegänge zeigen im Kalender jetzt den Straßennamen statt des Stadtteils - sowohl in der Tagesübersicht als auch beim Anlegen eines Termins und im Excel-Export.",
      "Funktioniert für klassische Pflegelisten (Straße aus der Trennzeile) und generische Listen wie die Wässerliste (Straße aus der Adress-Spalte)."
    ]
  },
  {
    datum: "10.08.2026",
    titel: "Kalender: Einladung direkt aus der Email-App teilen",
    punkte: [
      "Eine Kalendereinladung (aus Gmail, Outlook, ...) lässt sich jetzt per \"Teilen\" oder \"Öffnen mit\" direkt an diese App schicken - der Termin mit Organisator erscheint sofort im Kalender, ganz ohne Konto- oder API-Einrichtung.",
      "Erkennt auch Aktualisierungen (neue Uhrzeit) und Absagen derselben Einladung; eine schon gegebene Zusage/Absage bleibt dabei erhalten."
    ]
  },
  {
    datum: "10.08.2026",
    titel: "Kalender: automatischer Import von Email-Kalendereinladungen",
    punkte: [
      "Der Server kann jetzt optional ein E-Mail-Postfach per IMAP auf Kalendereinladungen prüfen und daraus automatisch Termine mit Organisator anlegen (inkl. Aktualisierung bei geänderter Uhrzeit und Absage bei Terminabsage).",
      "Läuft nur, wenn die Postfach-Zugangsdaten als Server-Konfiguration hinterlegt sind - ohne das bleibt alles wie bisher."
    ]
  },
  {
    datum: "10.08.2026",
    titel: "Kalender: vorbereitet für externe Kalendereinladungen",
    punkte: [
      "Neues Adressfeld für Termine, getrennt vom Kundennamen - wird im Kalender-Export (.ics) jetzt als Ort verwendet.",
      "Termine können jetzt einen Organisator (Name + E-Mail) tragen; ist einer hinterlegt, zeigt der Termin-Dialog eine Zusagen/Vielleicht/Absagen-Leiste wie bei einer Outlook/Google-Einladung.",
      "Grundlage für ein späteres automatisches Einlesen von Kalendereinladungen aus dem E-Mail-Postfach - der Import selbst ist noch nicht angeschlossen."
    ]
  },
  {
    datum: "10.08.2026",
    titel: "Pflegeliste: Abrechnung-Button für Admins",
    punkte: [
      "Neuer Knopf \"Abrechnung erledigt\" in der Listenansicht setzt alle rot markierten (manuell nachgetragenen) Termine der Liste auf einmal zurück, statt jeden einzeln abhaken zu müssen.",
      "Nur für Administratoren sichtbar - Vorarbeiter und Mitarbeiter sehen den Knopf nicht."
    ]
  },
  {
    datum: "31.07.2026",
    titel: "Tagesbericht: Übernahme aus der Pflegeliste kürzer + Stunden immer sichtbar",
    punkte: [
      "Die Bezeichnung beim Übernehmen rot markierter Termine ist jetzt kurz gehalten (max. 40 Zeichen): Positionsnummer + Straßenname reichen zur Zuordnung, die lange Leistungsbeschreibung steht nicht mehr mit in der Bezeichnung.",
      "Der Straßenname wird jetzt korrekt aus der zugehörigen Trennzeile ermittelt (war bei einzelnen Positionen zuvor leer).",
      "Die Stundenanzeige zeigt jetzt immer eine Zahl (auch \"0 Std.\") statt \"-\", damit eine fehlende Stundenangabe nicht übersehen wird."
    ]
  },
  {
    datum: "31.07.2026",
    titel: "Berichte-Übersicht: PDF direkt ansehen",
    punkte: [
      "Neuer Knopf \"Ansehen\" pro Bericht zeigt das PDF direkt in der Übersicht an, ohne erst den Teilen/Speichern-Dialog öffnen zu müssen.",
      "In der Vorschau lässt sich das PDF bei Bedarf trotzdem noch teilen/herunterladen."
    ]
  },
  {
    datum: "31.07.2026",
    titel: "Prioritätsliste: Straßenname auch bei einzeln priorisierten Positionen",
    punkte: [
      "Wird eine einzelne Position (ohne die zugehörige Straßen-Überschrift) als Priorität markiert, zeigt die Prioritätsliste jetzt zusätzlich den Straßennamen/Stadtteil der vorangehenden Trennzeile an.",
      "Bisher blieb in diesem Fall nur die nackte Positionsnummer übrig, was vor Ort schwer zuzuordnen war."
    ]
  },
  {
    datum: "30.07.2026",
    titel: "Anleitungen: Technische Anleitung + Code-Statistik ergänzt",
    punkte: [
      "Zwei neue Dokumente auf der Anleitungen-Seite: eine technische Anleitung (Architektur-Hintergrund) und eine Code-Statistik (Umfang der App in Zahlen).",
      "Beide waren bisher nur als einzeln verschickte PDFs unterwegs, nie Teil der App selbst - jetzt richtig eingebaut, damit sie über das normale Update ankommen."
    ]
  },
  {
    datum: "30.07.2026",
    titel: "Fix: Wässerliste-Übernahme in den Tagesbericht war leer",
    punkte: [
      "Rot markierte Termine aus einer Wässerliste (oder anderen generischen Listen) ließen sich zwar in den Tagesbericht übernehmen, die Bezeichnung blieb dabei aber leer - übrig blieb nur ein Satzzeichen ohne Inhalt.",
      "Grund: Die Übernahme kannte nur das klassische Pflegeliste-Layout (Auftragsnummer/Liegenschaft/Beschreibung), bei einer Wässerliste stehen die Angaben aber im neuen Info-Feld (Hauptposition/Bezeichnung/Adresse/Notiz).",
      "Jetzt wird bei generischen Listen die Hauptposition als Bezeichnung übernommen und die Stundenangabe aus der Notiz gelesen."
    ]
  },
  {
    datum: "30.07.2026",
    titel: "Wässerliste: Excel/CSV-Export und Geocoding-Treffgenauigkeit verbessert",
    punkte: [
      "Export (CSV + Excel) hat jetzt eine eigene Spalte \"Nur Position\" - sie überschreibt beim erneuten Import die automatische Erkennung, falls einzelne Zeilen manuell umgestellt wurden.",
      "\"Adressen verorten\" bevorzugt jetzt Treffer in der Nähe bereits verorteter Positionen derselben Liste - mehrdeutige Ortsnamen (z.B. \"Reinfeld\", das es in Deutschland mehrfach gibt) landen dadurch zuverlässiger in der richtigen Region statt zufällig irgendwo im Land.",
      "Fix: Bei einer Hauptposition, deren Adresse identisch mit dem eingegebenen Ort ist (z.B. \"Reinfeld\"), wurde bisher eine sinnlos verdoppelte Suchanfrage (\"Reinfeld, Reinfeld\") an den Kartendienst geschickt."
    ]
  },
  {
    datum: "30.07.2026",
    titel: "Wässerliste: Termin nur einmal pro Hauptposition statt pro Unterzeile",
    punkte: [
      "Einzelne Unterpositionen (z.B. jeder einzelne Baum/jede Straße innerhalb einer Hauptposition wie \"Stockelsdorf\") lassen sich jetzt als \"nur Position\" markieren (Kettensymbol in der Tabelle) - sie dienen dann nur noch der Orts-Markierung auf der Karte, ohne eigene Pflegegang-Termine.",
      "Der Fortschrittsbalken und die Listenübersicht zählen nur noch die tatsächlich terminierten Zeilen, nicht mehr jede einzelne Unterposition.",
      "Beim Import wird das automatisch erkannt: die erste Zeile einer mehrfach vorkommenden Hauptposition bleibt Termin-Trägerin, alle weiteren Zeilen derselben Gruppe werden automatisch als \"nur Position\" markiert - manuell über das Kettensymbol jederzeit änderbar."
    ]
  },
  {
    datum: "30.07.2026",
    titel: "Wässerliste: \"Adressen verorten\" mit Ort pro Hauptposition",
    punkte: [
      "Beim automatischen Verorten wird jetzt für jede Hauptposition einzeln nach dem passenden Ort gefragt, statt für die ganze Liste nur einen einzigen Ort abzufragen - wichtig, wenn eine Liste mehrere Orte mischt (z.B. Straßen in Stockelsdorf neben eigenständigen Orten wie Reinfeld).",
      "Die Eingabe ist pro Hauptposition schon mit dem Gruppennamen vorbefüllt und wird für den nächsten Durchlauf gemerkt.",
      "Eine Hauptposition ohne Eingabe wird beim Verorten einfach übersprungen, statt den ganzen Lauf abzubrechen."
    ]
  },
  {
    datum: "30.07.2026",
    titel: "Wässerliste: Farbpalette auf 16 Hauptpositionen erweitert",
    punkte: [
      "Die Farbgruppierung von Hauptpositionen unterstützt jetzt 16 statt 8 unterscheidbare Farben (Tabelle + Karte) - wichtig, sobald eine Liste mehr als 8 einzelne Hauptpositionen enthält, damit sich keine zwei Gruppen dieselbe Farbe teilen."
    ]
  },
  {
    datum: "29.07.2026",
    titel: "Wässerliste: vorbereitete Positionen per Klick verorten",
    punkte: [
      "Positionen ohne Koordinate (z.B. vorab per Import angelegt) haben jetzt in der Tabelle ein Karten-Symbol - antippen, dann auf der Karte klicken, um genau diese Position zu setzen.",
      "Anders als \"Punkt hinzufügen\": es wird kein neuer Eintrag angelegt, sondern nur die Koordinate der bestehenden Zeile ergänzt."
    ]
  },
  {
    datum: "29.07.2026",
    titel: "Wässerliste: Position direkt in der Tabelle anlegen/bearbeiten",
    punkte: [
      "Neuer Knopf \"Position hinzufügen\" in der Tabellenansicht - legt eine Position ganz ohne Kartenklick an, inklusive neuem Feld \"Adresse\".",
      "Mit gesetzter Adresse funktioniert jetzt auch \"Adressen verorten\" (automatisches Geocoding) für die Wässerliste - Alternative zum manuellen Anklicken der Karte.",
      "Bestehende Positionen lassen sich über das Stift-Symbol in der Tabelle nachträglich bearbeiten."
    ]
  },
  {
    datum: "29.07.2026",
    titel: "Wässerliste: Hauptpositionen farblich gruppieren",
    punkte: [
      "Neues erstes Feld \"Hauptposition\" (z.B. \"Stodo Bäume\", \"Stadtgrabenbrücke\"): mehrere Einzelpunkte derselben Hauptposition bekommen automatisch dieselbe Farbe - in der Tabelle und auf der Karte.",
      "Beim Anlegen mehrerer Punkte per Klick auf der Karte wird die zuletzt eingetragene Hauptposition vorausgefüllt, damit man z.B. 20 Bäume derselben Straße nicht jedes Mal neu betiteln muss.",
      "Über der Karte zeigt eine Legende, welche Farbe zu welcher Hauptposition gehört."
    ]
  },
  {
    datum: "29.07.2026",
    titel: "Pflegeliste: Neue Wässerliste + Punkte direkt auf der Karte anlegen",
    punkte: [
      "Beim Anlegen einer neuen Liste gibt es jetzt die Option \"Neue Wässerliste (ohne Datei)\" - eine leere Liste mit den Spalten Januar bis Dezember, ganz ohne Excel-Import.",
      "In der Kartenansicht mit \"Punkt hinzufügen\" direkt auf die Karte klicken, um dort eine neue Position einzutragen - ideal für Dauerpflege-Stellen mit mehreren Wässer-/Gieß-Punkten.",
      "Ebenfalls neu: eine Mehrfachauswahl über der Karte blendet zusätzlich gewählte Listen farblich unterschieden ein, um mehrere Stellen auf einen Blick zu vergleichen."
    ]
  },
  {
    datum: "29.07.2026",
    titel: "Startseite: Knopf \"Nach Updates suchen\"",
    punkte: [
      "Ein Hot-Update aktiviert sich erst beim nächsten vollständigen Schließen und Neuöffnen der App - bloßes Minimieren reicht auf Android oft nicht.",
      "Der neue Knopf unter der Versionsnummer prüft sofort auf ein Update und zeigt an, ob schon eines geladen wurde und die App dafür neu gestartet werden muss."
    ]
  },
  {
    datum: "29.07.2026",
    titel: "Prioritätsliste: Lesbarkeit im hellen Modus verbessert",
    punkte: [
      "Die Gruppen-Überschriften sowie die Pflegegang-Häkchen (offen/erledigt) waren im hellen Modus kaum lesbar, weil ihre Textfarbe für den dunklen Modus gewählt war.",
      "Jetzt werden dort dunklere, kontrastreiche Farbtöne verwendet - betrifft auch die Pflegeliste, die dieselben Farben verwendet."
    ]
  },
  {
    datum: "29.07.2026",
    titel: "Kalender: Termine mit Wiederholung + Erinnerungen",
    punkte: [
      "Beim Anlegen eines Termins lässt sich jetzt eine Wiederholung wählen (täglich, alle 2/3 Tage, wöchentlich, alle 2/4 Wochen) - eine Terminreihe läuft unbegrenzt weiter, bis man den ursprünglichen Termin (erkennbar am Wiederhol-Symbol) manuell löscht.",
      "Der jeweils nächste Termin der Reihe wird automatisch angelegt und bekommt - falls gewünscht - dieselbe Erinnerung wie der Ursprungstermin."
    ]
  },
  {
    datum: "29.07.2026",
    titel: "Tagesbericht-PDF: Tabelle füllt jetzt die ganze Seite",
    punkte: [
      "Die erzeugte PDF-Datei ließ bisher oft ein großes leeres Stück am unteren Seitenrand frei.",
      "Die Zeilenhöhe wird jetzt so berechnet, dass Tabelle und Unterschriftzeile exakt bis zum unteren Rand einer DIN-A4-Seite reichen - ohne freien Platz."
    ]
  },
  {
    datum: "29.07.2026",
    titel: "Tagesbericht: Pause von 0 Std. wird jetzt korrekt angezeigt",
    punkte: [
      "In der Mitarbeiter-Tabelle und der Bericht-Vorschau stand die Pause bisher leer, wenn sie 0 Std. betrug - das sah nach einer vergessenen Eingabe aus.",
      "Jetzt steht dort immer die \"0\", genau wie in der erzeugten PDF-Datei."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Pflegeliste: Zoom für die Tabellenansicht",
    punkte: [
      "Über der Tabelle gibt es jetzt eine Zoom-Leiste: mit \"+\"/\"−\" frei in 5%-Schritten anpassen, oder direkt eine von 6 festen Stufen (70-150%) antippen.",
      "So lässt sich je nach Bedarf entweder viel auf einen Blick sehen (herausgezoomt) oder besser lesen (hereingezoomt) - die Einstellung wird pro Gerät gemerkt."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Startseite: Kacheln nach Kategorien sortiert",
    punkte: [
      "Die Startseite ist jetzt in Bereiche gegliedert: Erfassen, Planung & Pflege, Auswertung, Kunden, Konto & Hilfe (sowie Verwaltung für Admins).",
      "Damit ist auf einen Blick klarer, welche Funktionen zusammengehören - die einzelnen Kacheln und ihre Links bleiben unverändert."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Prioritätsliste: Termine direkt eintragen + Karte zeigt Priorität",
    punkte: [
      "In der Prioritätsliste lassen sich Pflegegang-Termine jetzt genauso setzen, ändern und löschen wie in der normalen Pflegeliste - beide Ansichten zeigen sofort denselben Stand.",
      "Die Pflege-Karte markiert priorisierte Positionen jetzt mit einem Stern-Symbol, damit auf einen Blick erkennbar ist, welche Punkte gerade Priorität haben."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Neu: Prioritätsliste in der Pflegeliste",
    punkte: [
      "In der Pflegeliste lässt sich jede Straßen-/Stadtteil-Position (bzw. einzelne Positionen) jetzt mit einem Stern markieren (Vorarbeiter/Admin).",
      "Alle markierten Positionen sammeln sich auf der neuen Startseiten-Kachel \"Prioritätsliste\" - bei einer markierten Straße samt aller Unterpositionen.",
      "Die Prioritätsliste zeigt keine Kopie, sondern dieselben Daten: ein abgehakter Pflegegang dort ist auch in der normalen Pflegeliste sofort erledigt (und umgekehrt)."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Vorher-/Nachher-Fotos beim Heckenschnitt",
    punkte: [
      "Bei einem Heckenschnitt-Eintrag lassen sich jetzt Vorher- und Nachher-Fotos anhängen - direkt bei der Neuanlage.",
      "Fotos werden beim Hochladen automatisch verkleinert. Nachträglich ändern (Fotos entfernen oder ergänzen) können Vorarbeiter und Admins über den Bearbeiten-Button."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Neu: Ausführliche Anleitung",
    punkte: [
      "Unter \"Anleitung\" gibt es jetzt zwei Dokumente zur Auswahl: die bisherige Kurzanleitung und eine neue, ausführliche Anleitung.",
      "Die ausführliche Anleitung geht auf jeden Bereich der App im Detail ein und erklärt zusätzlich, wie die einzelnen Bereiche zusammenhängen (z. B. Kalender, Tagesbericht, Pflegeliste und Statistik)."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Anleitung öffnet sich jetzt direkt in der App",
    punkte: [
      "Die Kachel \"Anleitung\" zeigt die Schritt-für-Schritt-Anleitung jetzt direkt zum Durchblättern in der App an, statt zuerst über den Teilen-Dialog gehen zu müssen.",
      "Über das Teilen-Symbol oben lässt sie sich weiterhin z. B. per WhatsApp oder E-Mail weitergeben."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Anleitung direkt in der App verlinkt",
    punkte: [
      "Auf der Startseite gibt es jetzt die Kachel \"Anleitung\" - öffnet die Schritt-für-Schritt-Anleitung als PDF über den Teilen-Dialog, z. B. um sie direkt anzusehen oder an Kollegen weiterzuschicken.",
      "Die Anleitung ist Teil der App und funktioniert dadurch auch ohne Internetverbindung."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Fotos an Notizen: Löschen/Hinzufügen jetzt an Bearbeiten-Modus gekoppelt",
    punkte: [
      "Fotos einer Notiz lassen sich nur noch entfernen oder ergänzen, wenn die Notiz gerade über den Stift (\"Bearbeiten\") geöffnet ist - in der normalen Ansicht sind sie nur noch zu sehen.",
      "Verhindert versehentliches Löschen von Fotos beim schnellen Durchblättern der Notizen."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Pausen werden beim Tagesbericht aus dem Termin automatisch berücksichtigt",
    punkte: [
      "Wird aus einem Kalendertermin ein Tagesbericht erstellt, rechnet die App die feste Frühstückspause (9:30-10:00) und Mittagspause (12:30-13:00) automatisch in die Pausenzeit ein, wenn der Termin-Zeitraum sie überschneidet.",
      "Beispiel: Ein Termin bis 11 Uhr trägt automatisch 0,5 Std. Pause ein, statt dass das manuell nachgetragen werden muss."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Mehrere Fotos auf einmal zu Notizen hinzufügen",
    punkte: [
      "Bei einer Notiz lassen sich jetzt mehrere Fotos in einem Schritt auswählen und anhängen, statt jedes einzeln.",
      "Das Löschen-Symbol an einem Foto ist jetzt immer sichtbar (vorher nur bei Maus-Hover) - dadurch auf dem Tablet per Fingertipp nutzbar."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Notizen als Excel oder Word exportieren",
    punkte: [
      "Bei einem Kunden lassen sich alle Notizen jetzt per Knopfdruck als Excel-Tabelle oder als Word-Dokument exportieren und über den Teilen-Dialog verschicken.",
      "Der Word-Export enthält auch die angehängten Fotos direkt im Dokument."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Fotos an Notizen anhängen",
    punkte: [
      "Bei jeder Notiz lassen sich jetzt Fotos anhängen - z. B. ein Bild der Hecke, damit klar ist, was gemeint ist.",
      "Fotos werden beim Hochladen automatisch verkleinert, damit sie nicht unnötig viel Speicherplatz auf dem Gerät bzw. Server belegen."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Neu: Notizen je Kunde",
    punkte: [
      "Neuer Bereich \"Notizen\" auf der Startseite: Kunden anlegen und dazu beliebig viele Anmerkungen sammeln, z. B. wiederkehrende Arbeiten oder Besonderheiten.",
      "Notizen lassen sich jederzeit bearbeiten oder löschen, ein Kunde zeigt immer alle bisherigen Notizen samt Datum und Ersteller."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Termin-Erinnerungen laufen jetzt auch im Hintergrund zuverlässig",
    punkte: [
      "Erinnerungen wurden bisher teils nur zugestellt, wenn die App gerade geöffnet war - jetzt läuft die Zustellung auch bei geschlossener App bzw. im Ruhezustand des Geräts zuverlässig.",
      "Muss das Gerät dafür einmalig \"Alarme & Erinnerungen\" freigeben, zeigt die App unten einen Hinweis mit direktem Link zu den Einstellungen."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "\"Was ist neu?\"-Popup nach einem Update",
    punkte: [
      "Nach einem Update zeigt die App beim nächsten Öffnen automatisch an, was sich geändert hat - die komplette Liste bleibt weiterhin über \"Neuigkeiten\" auf der Startseite erreichbar."
    ]
  },
  {
    datum: "28.07.2026",
    titel: "Erinnerung an Termine per Benachrichtigung",
    punkte: [
      "Bei jedem Kalender-Termin lässt sich jetzt eine Erinnerung einstellen: keine, zum Termin-Beginn, 15 Min., 30 Min., 1 Std. oder 1 Tag vorher.",
      "Zur eingestellten Zeit erscheint eine normale Geräte-Benachrichtigung, auch wenn die App gerade nicht geöffnet ist.",
      "Wird ein Termin abgesagt, erledigt oder gelöscht, verschwindet die zugehörige Erinnerung automatisch wieder."
    ]
  },
  {
    datum: "27.07.2026",
    titel: "Updates jetzt automatisch im Hintergrund",
    punkte: [
      "Die App prüft jetzt bei bestehender Internetverbindung selbstständig auf neue Versionen und lädt sie im Hintergrund - ganz ohne die App neu herunterzuladen oder zu installieren.",
      "Ein Update wird beim nächsten Start bzw. beim nächsten Minimieren der App aktiv, sodass eine gerade laufende Eingabe nie unterbrochen wird.",
      "Ohne Internet läuft die App wie gewohnt vollständig offline mit dem zuletzt geladenen Stand weiter."
    ]
  },
  {
    datum: "27.07.2026",
    titel: "Heckenart aus Auswahlliste statt eintippen",
    punkte: [
      "Bei einem neuen Heckenschnitt-Eintrag lässt sich die Heckenart jetzt aus einer Liste der bereits erfassten Heckenarten auswählen, statt sie jedes Mal neu einzutippen.",
      "Eine neue Heckenart lässt sich weiterhin über \"+ Neue Heckenart eingeben...\" anlegen und steht danach automatisch in der Liste zur Auswahl."
    ]
  },
  {
    datum: "27.07.2026",
    titel: "Excel- und CSV-Export repariert",
    punkte: [
      "Der Export-Button (Excel/CSV) in Tagesbericht, Bautagesbericht, Heckenschnitt, Kalender und Pflegeliste hat bisher in der App-Version keine Datei erzeugt.",
      "Alle Export-Buttons nutzen jetzt denselben zuverlässigen Weg wie schon der PDF-Export: Die Datei lässt sich direkt über den Teilen-Dialog von Android öffnen (z. B. mit Excel/Sheets) oder z. B. per WhatsApp/E-Mail/Drive weitergeben."
    ]
  },
  {
    datum: "27.07.2026",
    titel: "Kalender und Tagesbericht besser verbunden",
    punkte: [
      "Wenn du aus dem Kalender heraus einen Tagesbericht erstellst, werden Baustelle und Datum jetzt zuverlässig übernommen (vorher blieben die Felder manchmal leer).",
      "Einem Termin lassen sich jetzt mehrere Mitarbeiter gleichzeitig zuweisen, nicht mehr nur einer.",
      "Diese Mitarbeiter werden beim Erstellen des Tagesberichts automatisch mit den Termin-Zeiten in die Mitarbeitererfassung übernommen - manuelles Eintragen entfällt."
    ]
  },
  {
    datum: "24.07.2026",
    titel: "Pflegetermine gezielt ändern oder löschen",
    punkte: [
      "In der Pflegeliste kannst du bei jedem Termin über das Stift-Symbol das Datum ändern.",
      "Über das Papierkorb-Symbol lässt sich ein einzelner Termin gezielt entfernen."
    ]
  },
  {
    datum: "24.07.2026",
    titel: "PDF speichern und ansehen funktioniert wieder",
    punkte: [
      "Tagesberichte lassen sich als PDF wieder speichern, ansehen und über andere Apps (z. B. WhatsApp, E-Mail) teilen."
    ]
  },
  {
    datum: "24.07.2026",
    titel: "Mitarbeiter-Auswahl im Tagesbericht",
    punkte: [
      "Statt den Namen jedes Mal einzutippen, gibt es jetzt eine Auswahlliste mit allen Mitarbeitern.",
      "Neue Namen werden beim ersten Eintragen automatisch gemerkt und stehen danach immer zur Auswahl."
    ]
  },
  {
    datum: "24.07.2026",
    titel: "Updates ohne Datenverlust",
    punkte: [
      "Neue Versionen der App lassen sich jetzt installieren, ohne dass vorhandene Berichte und Listen verloren gehen."
    ]
  },
  {
    datum: "24.07.2026",
    titel: "Eigenes Firmen-Logo",
    punkte: [
      "Das App-Symbol auf dem Gerät zeigt jetzt das echte Grüne-Oase-Logo."
    ]
  },
  {
    datum: "24.07.2026",
    titel: "Adressen automatisch auf der Karte finden",
    punkte: [
      "Neue Adressen werden automatisch auf der Karte platziert, sobald das Gerät Internetempfang hat."
    ]
  },
  {
    datum: "24.07.2026",
    titel: "Anmelde-Fehler behoben",
    punkte: [
      "Ein Fehler, durch den die Startseite nach dem Öffnen leer blieb, wurde behoben."
    ]
  },
  {
    datum: "24.07.2026",
    titel: "Die App läuft jetzt ganz ohne Internet",
    punkte: [
      "Alle Berichte, Listen und Termine werden direkt auf dem Gerät gespeichert.",
      "Die App funktioniert dadurch auch komplett ohne Internetverbindung."
    ]
  }
];
