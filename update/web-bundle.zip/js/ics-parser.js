// Browser-Portierung von backend/utils/icsParser.js (reines JS, keine
// Node-Abhängigkeiten - deshalb 1:1 übernehmbar). Wird von ics-empfang.js
// genutzt, um eine per "Teilen"/"Öffnen mit" empfangene Kalendereinladung
// direkt auf dem Gerät auszuwerten, ganz ohne Server/API.
(function () {
  "use strict";

  function entfalte(text) {
    return String(text || "").replace(/\r\n/g, "\n").split("\n").reduce((zeilen, zeile) => {
      if (zeile.startsWith(" ") && zeilen.length) zeilen[zeilen.length - 1] += zeile.slice(1);
      else zeilen.push(zeile);
      return zeilen;
    }, []);
  }

  function entschluesseln(wert) {
    return String(wert || "")
      .replace(/\\n/gi, "\n")
      .replace(/\\,/g, ",")
      .replace(/\\;/g, ";")
      .replace(/\\\\/g, "\\");
  }

  // Benannte HTML-Entities, die in Word-Beschreibungen tatsächlich vorkommen
  // (deutsche Umlaute, typografische Zeichen). Keine vollständige HTML-Liste -
  // alles Unbekannte bleibt unverändert stehen, statt zu verstümmeln.
  const NAMENS_ENTITIES = {
    szlig: "ß", auml: "ä", ouml: "ö", uuml: "ü", Auml: "Ä", Ouml: "Ö", Uuml: "Ü",
    ndash: "–", mdash: "—", hellip: "…", bull: "•", middot: "·", minus: "−",
    laquo: "«", raquo: "»", bdquo: "„", ldquo: "“", rdquo: "”", sbquo: "‚",
    lsquo: "‘", rsquo: "’", deg: "°", sup2: "²", sup3: "³", frac12: "½",
    frac14: "¼", times: "×", plusmn: "±", permil: "‰", euro: "€", copy: "©",
    reg: "®", trade: "™", dagger: "†", shy: ""
  };

  // Manche Kalendereinladungen (typisch Outlook/Word) liefern in DESCRIPTION ein
  // komplettes HTML-Dokument statt Text - inkl. <head>, Word-Namensräumen und
  // bedingten Kommentaren. Ungefiltert landet dieser Quelltext 1:1 im
  // Beschreibungsfeld des Termins und ist dort schlicht unlesbar. Deshalb hier
  // zurück in reinen Text verwandeln - bewusst nur mit regulären Ausdrücken und
  // ohne DOM/Bibliothek, damit diese Datei weiterhin unverändert im Browser wie
  // in Node läuft.
  function alsKlartext(wert) {
    const roh = String(wert || "");
    if (!/<[a-z!/]/i.test(roh)) return roh; // sieht nicht nach HTML aus -> unverändert lassen
    const zeichen = (nr) => (nr > 0 && nr <= 0x10ffff ? String.fromCodePoint(nr) : "");
    return roh
      .replace(/<!--[\s\S]*?-->/g, " ")                        // Kommentare inkl. <!--[if mso]>…<![endif]-->
      .replace(/<(script|style|head)\b[\s\S]*?<\/\1\s*>/gi, " ") // CSS/JS/Kopfdaten komplett verwerfen
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<\/(p|div|tr|li|h[1-6])\s*>/gi, "\n")
      .replace(/<[^>]*>/g, "")                                  // alle übrigen Tags
      .replace(/&nbsp;/gi, " ")
      .replace(/&#(\d+);/g, (_, n) => zeichen(Number(n)))
      .replace(/&#x([0-9a-f]+);/gi, (_, n) => zeichen(parseInt(n, 16)))
      .replace(/&([A-Za-z]{2,8});/g, (treffer, name) => NAMENS_ENTITIES[name] ?? treffer)
      .replace(/&quot;/gi, '"')
      .replace(/&apos;/gi, "'")
      .replace(/&lt;/gi, "<")
      .replace(/&gt;/gi, ">")
      .replace(/&amp;/gi, "&")                                  // zuletzt, sonst werden Doppel-Maskierungen falsch aufgelöst
      .replace(/[ \t ]+/g, " ")
      .replace(/ ?\n ?/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function parseZeile(zeile) {
    const doppelpunkt = zeile.indexOf(":");
    if (doppelpunkt === -1) return null;
    const kopf = zeile.slice(0, doppelpunkt);
    const wert = zeile.slice(doppelpunkt + 1);
    const [name, ...paramTeile] = kopf.split(";");
    const params = {};
    for (const teil of paramTeile) {
      const [k, v] = teil.split("=");
      if (k) params[k.toUpperCase()] = v;
    }
    return { name: name.toUpperCase(), params, wert };
  }

  function parseIcsZeit(wert, isDate) {
    const m = String(wert || "").match(/^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2}))?Z?$/);
    if (!m) return null;
    const [, jahr, monat, tag, std, min] = m;
    const datum = `${jahr}-${monat}-${tag}`;
    if (isDate || std === undefined) return { datum, zeit: null };
    return { datum, zeit: `${std}:${min}` };
  }

  function parseIcs(icsText) {
    const zeilen = entfalte(icsText).map(parseZeile).filter(Boolean);
    const methodZeile = zeilen.find((z) => z.name === "METHOD");
    const method = methodZeile ? methodZeile.wert.trim().toUpperCase() : "PUBLISH";

    const termine = [];
    let aktuell = null;
    let unterkomponente = null;
    for (const z of zeilen) {
      if (z.name === "BEGIN" && z.wert === "VEVENT") { aktuell = {}; unterkomponente = null; continue; }
      if (z.name === "END" && z.wert === "VEVENT") { if (aktuell) termine.push(aktuell); aktuell = null; unterkomponente = null; continue; }
      if (!aktuell) continue;
      if (z.name === "BEGIN") { unterkomponente = z.wert; continue; }
      if (z.name === "END" && z.wert === unterkomponente) { unterkomponente = null; continue; }
      if (unterkomponente) continue;

      switch (z.name) {
        case "SUMMARY": aktuell.titel = entschluesseln(z.wert); break;
        case "LOCATION": aktuell.adresse = entschluesseln(z.wert); break;
        case "DESCRIPTION": aktuell.beschreibung = alsKlartext(entschluesseln(z.wert)); break;
        case "UID": aktuell.icalUid = z.wert.trim(); break;
        case "SEQUENCE": aktuell.icalSequence = Number(z.wert.trim()) || 0; break;
        case "STATUS": aktuell.icsStatus = z.wert.trim().toUpperCase(); break;
        case "DTSTART": aktuell.start = parseIcsZeit(z.wert.trim(), z.params.VALUE === "DATE"); break;
        case "DTEND": aktuell.ende = parseIcsZeit(z.wert.trim(), z.params.VALUE === "DATE"); break;
        case "ORGANIZER":
          aktuell.organisatorEmail = z.wert.replace(/^mailto:/i, "").trim();
          aktuell.organisatorName = z.params.CN ? z.params.CN.replace(/^"|"$/g, "") : null;
          break;
      }
    }

    return termine.map((t) => ({
      method,
      titel: t.titel || "(ohne Titel)",
      adresse: t.adresse || null,
      beschreibung: t.beschreibung || null,
      datum: t.start?.datum || null,
      von: t.start?.zeit || null,
      bis: t.ende?.zeit || null,
      icalUid: t.icalUid || null,
      icalSequence: Number.isInteger(t.icalSequence) ? t.icalSequence : 0,
      organisatorName: t.organisatorName || null,
      organisatorEmail: t.organisatorEmail || null,
      abgesagt: t.icsStatus === "CANCELLED" || method === "CANCEL"
    })).filter((t) => t.datum && t.icalUid);
  }

  window.IcsParser = { parseIcs, alsKlartext };
})();
