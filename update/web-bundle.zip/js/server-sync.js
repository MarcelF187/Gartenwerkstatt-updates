// Mehrgeräte-Sync über den echten Server (go-dashboard.de), zusätzlich zum
// bestehenden WLAN-Peer-Sync (lan-sync.js). Läuft NUR nativ (installierte
// APK) - im Browser/PWA-Modus spricht local-api.js gar nicht erst mit
// IndexedDB, sondern direkt mit dem echten Server (siehe offline.js).
//
// Bewusst ein EIGENER, unabhängiger Codepfad statt eines Refactors von
// lan-sync.js (siehe Begründung im Plan "Server-Sync für die Gartenwerkstatt-
// App"): lan-sync.js ist im Feldeinsatz, ein Umbau jetzt wäre unnötiges
// Risiko. SYNC_STORES/FK_FELDER/wireFeldname sind deshalb 1:1 dupliziert -
// bei einer Änderung an einer Stelle IMMER auch lan-sync.js UND
// backend/routes/sync.routes.js (Server-Repo) nachziehen.
//
// Unterschied zur WLAN-Konfliktregel: lan-sync.js lässt bei einem Konflikt
// immer das Hauptgerät gewinnen (asymmetrische Stern-Topologie). Der Server
// hat keine "Hauptgerät"-Rolle bei vielen unabhängigen Geräten - hier gilt
// stattdessen Last-Write-Wins über updated_at (mit Marcel abgestimmt,
// Risiko durch falsch eingestellte Geräteuhr bewusst in Kauf genommen).
(function () {
  "use strict";

  const LS_TOKEN = "go-server-sync-token";
  const LS_LAST_CHECK = "go-serversync-last-check";
  const CHECK_INTERVAL_MS = 5 * 60 * 1000; // wie hot-update.js
  const SERVER_URL = "https://go-dashboard.de";

  const SYNC_STORES = [
    "rollen", "users", "urlaub", "stammdaten", "kunden",
    "projekte", "baumlisten", "baumlisten_items",
    "tagesberichte", "heckenschnitt", "heckenschnitt_bilder", "termine", "notizen", "notiz_bilder",
    "bautagesberichte",
    "lv_bau_projekte", "lv_bau_listen", "lv_bau_items",
    "bauplaene", "bauplan_ebenen",
    "material_katalog", "materiallisten", "material_eintraege"
  ];

  // stammdaten/material_katalog werden auf JEDEM Gerät beim allerersten
  // Start identisch geseedet (siehe LocalDB.ensureSeeded) - mit je eigener,
  // zufälliger client_uuid pro Gerät. Ein Push würde bei jedem Gerät neue
  // Server-Duplikate des immer gleichen Katalogs erzeugen (der Server-
  // Sync-Endpunkt macht anders als lan-sync.js KEINEN Inhalts-Dedup-
  // Fallback, siehe Plan). Deshalb bewusst nur PULLEN, nie PUSHEN - Admin-
  // Änderungen am Katalog über die Web-Oberfläche kommen so trotzdem auf
  // den Geräten an, ohne dass jedes Gerät seinen eigenen Seed-Stand hochlädt.
  const NUR_PULL_STORES = new Set(["stammdaten", "material_katalog"]);

  const BILDER_STORES = ["notiz_bilder", "heckenschnitt_bilder", "bauplaene"];

  const FK_FELDER = {
    baumlisten: { projekt_id: "projekte" },
    baumlisten_items: { liste_id: "baumlisten" },
    notizen: { kunde_id: "kunden", liste_id: "baumlisten", item_id: "baumlisten_items" },
    notiz_bilder: { notiz_id: "notizen" },
    heckenschnitt_bilder: { eintrag_id: "heckenschnitt" },
    lv_bau_listen: { projekt_id: "lv_bau_projekte" },
    lv_bau_items: { liste_id: "lv_bau_listen" },
    urlaub: { mitarbeiter_id: "users", erstellt_von: "users" },
    bauplaene: { projekt_id: "lv_bau_projekte", erstellt_von: "users" },
    bauplan_ebenen: { bauplan_id: "bauplaene", erstellt_von: "users" },
    materiallisten: { projekt_id: "lv_bau_projekte", erstellt_von: "users" },
    material_eintraege: { liste_id: "materiallisten" },
    termine: { serie_id: "termine", liste_id: "baumlisten", item_id: "baumlisten_items" }
  };

  // Fällt der client_uuid-Treffer aus (siehe wendeAenderungenAn unten), wird
  // hierüber nach einer inhaltlich identischen, unabhängig auf DIESEM Gerät
  // entstandenen Zeile gesucht, statt sie blind als neue Zeile anzulegen -
  // 1:1 aus lan-sync.js übernommen (dort ausführlich begründet: zwei Geräte
  // legen z.B. beim Ersteinrichten unabhängig voneinander denselben Nutzer
  // oder denselben Katalog-Stammdatensatz mit je eigener client_uuid an).
  // Ohne das schlägt ein add() bei "users" hart mit einem ConstraintError am
  // eindeutigen "username"-Index fehl, sobald ein zweites Gerät per
  // Internet-Sync einen andernorts bereits lokal existierenden Nutzer
  // hereinbekommt (am 11.09. genau so von einem Nutzer gemeldet).
  const DEDUPE_SCHLUESSEL = {
    users: (r) => String(r.username || "").trim().toLowerCase(),
    stammdaten: (r) => [r.typ, r.bereich, String(r.bezeichnung || "").trim().toLowerCase()].join("|"),
    projekte: (r) => String(r.name || "").trim().toLowerCase(),
    baumlisten: (r) => `${r.projekt_id == null ? "" : r.projekt_id}|${String(r.name || "").trim().toLowerCase()}`,
    termine: (r) => {
      if (r.serie_id) return `serie:${r.serie_id}:${r.datum}`;
      if (r.item_id && r.quelle === "pflege_vorschlag") return `vorschlag:${r.item_id}:${r.datum}`;
      return `eigenstaendig:${r.client_uuid}`;
    },
    baumlisten_items: (r) => `${r.liste_id}|${String(r.auftragsnummer || "").trim().toLowerCase()}`,
    material_katalog: (r) => String(r.name || "").trim().toLowerCase(),
    materiallisten: (r) => `${r.bereich || "bau"}|${r.projekt_id == null ? "" : r.projekt_id}|${String(r.name || "").trim().toLowerCase()}`
  };

  const ID_IST_SYNC_SCHLUESSEL = ["rollen"];

  function wireFeldname(feld) {
    return feld.replace(/_id$/, "_client_uuid");
  }

  function zeitstempelVon(store, row) {
    return store === "notizen" ? row.aktualisiert_am : row.updated_at;
  }

  function plattformIstNativ() {
    return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  }

  function token() {
    return (localStorage.getItem(LS_TOKEN) || "").trim();
  }

  // -------------------------------------------------------------- FK-Übersetzung
  async function findeLokalDurchClientUuid(store, uuid) {
    if (!uuid) return null;
    const treffer = await window.LocalDB.getAllByIndex(store, "client_uuid", uuid);
    return treffer && treffer.length ? treffer[0] : null;
  }

  async function loeseFksEingehendAuf(store, eingehend) {
    const zeile = { ...eingehend };
    if (!ID_IST_SYNC_SCHLUESSEL.includes(store)) delete zeile.id;
    const felder = FK_FELDER[store];
    if (felder) {
      for (const [feld, elternStore] of Object.entries(felder)) {
        const wireFeld = wireFeldname(feld);
        const uuid = zeile[wireFeld];
        delete zeile[wireFeld];
        const eltern = uuid ? await findeLokalDurchClientUuid(elternStore, uuid) : null;
        zeile[feld] = eltern ? eltern.id : null;
      }
    }
    return zeile;
  }

  async function baueAusgehendeZeile(store, row) {
    const zeile = { ...row };
    if (!ID_IST_SYNC_SCHLUESSEL.includes(store)) delete zeile.id;
    if (BILDER_STORES.includes(store)) delete zeile.blob;
    const felder = FK_FELDER[store];
    if (felder) {
      for (const [feld, elternStore] of Object.entries(felder)) {
        const elternId = row[feld];
        delete zeile[feld];
        const eltern = elternId != null ? await window.LocalDB.get(elternStore, elternId) : null;
        zeile[wireFeldname(feld)] = eltern ? eltern.client_uuid : null;
      }
    }
    // Wire-Vertrag zum Server: IMMER "updated_at", unabhängig vom lokalen
    // Feldnamen (notizen führt seine Aktualisierungs-Spalte lokal als
    // "aktualisiert_am", siehe zeitstempelVon oben). Der Server liest beim
    // Push ausnahmslos wireRow.updated_at für die LWW-Prüfung - ohne diese
    // Umbenennung würde für notizen serverseitig auf "jetzt" statt der
    // echten Bearbeitungszeit zurückgefallen, was Last-Write-Wins für diese
    // Tabelle praktisch aushebeln würde.
    if (store === "notizen") {
      zeile.updated_at = row.aktualisiert_am;
      delete zeile.aktualisiert_am;
    }
    return zeile;
  }

  // Ab wann ein Tombstone als "sicher überall angekommen" gilt und deshalb
  // nicht mehr aktiv mitgesendet werden muss - siehe ausführlichen Kommentar
  // bei TOMBSTONE_AUFBEWAHRUNG_MS in local-db.js (dort auch die endgültige
  // Entfernung aus der lokalen DB) sowie derselbe Schutz in lan-sync.js. Ohne
  // diese Grenze bekäme ein Gerät, das sich erstmals per Internet abgleicht,
  // den kompletten historischen Papierkorb als "neu" - genau der am 24.08.
  // beobachtete "Haufen Listen, die nicht angezeigt werden"-Vorfall.
  function istZuAlterTombstone(row) {
    if (!row.deleted_at) return false;
    // Bewusst deleted_at selbst statt zeitstempelVon()/updated_at - deckungsgleich
    // mit LocalDB.raeumeAlteTombstonesAuf() (local-db.js), die dieselbe Zeile
    // anhand von deleted_at endgültig entfernt, sobald diese Grenze erreicht ist.
    return Date.now() - new Date(row.deleted_at).getTime() > 90 * 24 * 60 * 60 * 1000;
  }

  async function baueAusgehendeAenderungen(seit) {
    const changes = {};
    for (const store of SYNC_STORES) {
      if (NUR_PULL_STORES.has(store)) continue;
      const alle = await window.LocalDB.getAll(store);
      const geaendert = alle.filter((r) => (!seit || zeitstempelVon(store, r) > seit) && !istZuAlterTombstone(r));
      if (geaendert.length) changes[store] = await Promise.all(geaendert.map((r) => baueAusgehendeZeile(store, r)));
    }
    return changes;
  }

  // Last-Write-Wins über updated_at (Wire-Feld, für notizen bereits vom
  // Server auf "updated_at" vereinheitlicht - siehe backend/routes/
  // sync.routes.js baueAusgehendeZeile). Anders als lan-sync.js also KEIN
  // ueberschreiben-Flag, sondern ein Zeitstempel-Vergleich je Zeile.
  async function wendeAenderungenAn(changes) {
    const zaehler = { neu: 0, aktualisiert: 0, uebersprungen: 0 };
    for (const store of SYNC_STORES) {
      const rows = Array.isArray(changes && changes[store]) ? changes[store] : [];
      if (!rows.length) continue;
      const dedupeSchluessel = DEDUPE_SCHLUESSEL[store];
      // Lazy und nur einmal je Store geladen - siehe DEDUPE_SCHLUESSEL oben.
      let lokaleZeilen = null;
      for (const eingehend of rows) {
        let bestehend = ID_IST_SYNC_SCHLUESSEL.includes(store)
          ? await window.LocalDB.get(store, eingehend.id)
          : await findeLokalDurchClientUuid(store, eingehend.client_uuid);
        const zeile = await loeseFksEingehendAuf(store, eingehend);
        if (!bestehend && dedupeSchluessel) {
          // Bewusst OHNE bereits gelöschte (deleted_at gesetzte) lokale Zeilen:
          // dieser Store behält gelöschte Zeilen bis zu 90 Tage als Tombstone
          // (siehe TOMBSTONE_AUFBEWAHRUNG_MS/istZuAlterTombstone lokal wie in
          // local-db.js) - ohne diesen Ausschluss matcht z.B. ein längst
          // gelöschtes, gleichnamiges Projekt/Stammdatum eine tatsächlich NEUE,
          // andere eingehende Zeile mit demselben Namen und lässt sie fälschlich
          // als "bereits vorhanden" überspringen (am 11.09. beobachtet: mehrere
          // Bereiche gleichzeitig bekamen nach dem Server-Sync nur einen
          // Bruchteil der erwarteten Daten).
          if (!lokaleZeilen) lokaleZeilen = (await window.LocalDB.getAll(store)).filter((r) => !r.deleted_at);
          bestehend = lokaleZeilen.find((r) => dedupeSchluessel(r) === dedupeSchluessel(zeile)) || null;
        }
        // zeitstempelVon() erwartet lokale Feldnamen (aktualisiert_am bei
        // notizen) - die aufgelöste Zeile trägt aber noch "updated_at" vom
        // Server. Für notizen deshalb explizit umbenennen.
        if (store === "notizen") {
          zeile.aktualisiert_am = zeile.updated_at;
          delete zeile.updated_at;
        }
        if (bestehend) {
          const bestehenderZeitstempel = zeitstempelVon(store, bestehend);
          const eingehenderZeitstempel = zeitstempelVon(store, zeile);
          if (bestehenderZeitstempel && eingehenderZeitstempel && eingehenderZeitstempel <= bestehenderZeitstempel) {
            zaehler.uebersprungen++;
            continue;
          }
          await window.LocalDB.put(store, { ...zeile, id: bestehend.id });
          zaehler.aktualisiert++;
        } else {
          await window.LocalDB.add(store, zeile);
          zaehler.neu++;
        }
      }
    }
    return zaehler;
  }

  // ------------------------------------------------------------------ Fotos
  function blobZuArrayBuffer(blob) {
    return new Response(blob).arrayBuffer();
  }

  async function ladeNeueFotosHoch(seit) {
    for (const store of BILDER_STORES) {
      if (store === "bauplaene") continue; // bauplaene-Bilder laufen bewusst nicht über den Server-Sync (nur WLAN) - großer Dateien, seltener Anwendungsfall
      const alle = await window.LocalDB.getAll(store);
      const kandidaten = alle.filter((r) => r.blob && !r.deleted_at && (!seit || zeitstempelVon(store, r) > seit));
      for (const row of kandidaten) {
        try {
          const bytes = await blobZuArrayBuffer(row.blob);
          await fetch(`${SERVER_URL}/api/sync/foto/${store}/${row.client_uuid}`, {
            method: "POST",
            headers: { Authorization: `Bearer ${token()}`, "Content-Type": "application/octet-stream" },
            body: bytes
          });
        } catch (e) {
          // Einzelnes Foto darf den restlichen Sync nicht abbrechen - wird
          // beim nächsten Lauf automatisch erneut versucht.
        }
      }
    }
  }

  async function ladeFehlendeFotosHerunter() {
    for (const store of BILDER_STORES) {
      if (store === "bauplaene") continue;
      const alle = await window.LocalDB.getAll(store);
      const kandidaten = alle.filter((r) => !r.blob && !r.deleted_at && r.client_uuid);
      for (const row of kandidaten) {
        try {
          const res = await fetch(`${SERVER_URL}/api/sync/foto/${store}/${row.client_uuid}`, {
            headers: { Authorization: `Bearer ${token()}` }
          });
          if (!res.ok) continue;
          const blob = await res.blob();
          await window.LocalDB.put(store, { ...row, blob });
        } catch (e) {
          // wird beim nächsten Lauf erneut versucht.
        }
      }
    }
  }

  // ------------------------------------------------------------------- Kern
  async function serverSyncDurchfuehren() {
    const t = token();
    if (!t) return { ok: false, grund: "kein_token" };

    const cursor = await window.LocalDB.get("meta", "serverSyncCursor");
    const seit = cursor ? cursor.value : null;

    const changes = await baueAusgehendeAenderungen(seit);
    const res = await fetch(`${SERVER_URL}/api/sync`, {
      method: "POST",
      headers: { Authorization: `Bearer ${t}`, "Content-Type": "application/json" },
      body: JSON.stringify({ since: seit, changes })
    });
    if (!res.ok) return { ok: false, grund: `http_${res.status}` };

    const antwort = await res.json();
    if (!antwort.ok) return { ok: false, grund: antwort.error || "unbekannt" };

    const zaehler = await wendeAenderungenAn(antwort.changes);
    // Push-Zusammenfassung (was der SERVER beim Speichern der von diesem
    // Gerät GESENDETEN Zeilen gezählt hat, siehe push_details/sync_log im
    // Server-Repo backend/routes/sync.routes.js) - bisher hat die App nur
    // "zaehler" (den PULL, also was vom Server ankam) angezeigt. Bei einem
    // frischen/leeren Server ist der Pull erwartungsgemäß 0/0/0, obwohl beim
    // PUSH einzelne Zeilen serverseitig an einer Constraint gescheitert sein
    // können (der Server überspringt dank Savepoint pro Zeile nur DIESE
    // Zeile, meldet den Fehler aber bisher nirgends ans Gerät zurück) - genau
    // das hat am 11.09. den Eindruck "nur ein Viertel kam an" erzeugt, ohne
    // dass die App das je sichtbar gemacht hätte.
    const pushZaehler = { neu: 0, aktualisiert: 0, uebersprungen: 0, fehler: 0 };
    for (const store of Object.values(antwort.push || {})) {
      pushZaehler.neu += store.neu || 0;
      pushZaehler.aktualisiert += store.aktualisiert || 0;
      pushZaehler.uebersprungen += store.uebersprungen || 0;
      pushZaehler.fehler += store.fehler || 0;
    }
    await window.LocalDB.put("meta", { key: "serverSyncCursor", value: antwort.serverTime });

    // Fotos NACH der Metadaten-Runde: neu ankommende notiz_bilder/
    // heckenschnitt_bilder-Zeilen haben erst jetzt einen dateiname, aber noch
    // keinen Blob (Herunterladen), eigene Blobs müssen erst jetzt hoch.
    await ladeNeueFotosHoch(seit);
    await ladeFehlendeFotosHerunter();

    if (window.GOAudit) {
      window.GOAudit.aktion("server_sync", "aenderungen_angewendet",
        `Server-Sync: gesendet ${pushZaehler.neu} neu, ${pushZaehler.aktualisiert} aktualisiert, ${pushZaehler.fehler} Fehler - empfangen ${zaehler.neu} neu, ${zaehler.aktualisiert} aktualisiert, ${zaehler.uebersprungen} übersprungen`,
        { push: pushZaehler, pull: zaehler, pushDetails: antwort.push || {} });
    }

    return { ok: true, zaehler, pushZaehler, pushDetails: antwort.push || {} };
  }

  let laeuftGerade = false;
  async function pruefeUndSynchronisiere({ ignoriereIntervall } = {}) {
    if (!plattformIstNativ()) return;
    if (laeuftGerade) return;
    if (!ignoriereIntervall) {
      const letzterCheck = Number(localStorage.getItem(LS_LAST_CHECK) || 0);
      if (Date.now() - letzterCheck < CHECK_INTERVAL_MS) return;
    }
    localStorage.setItem(LS_LAST_CHECK, String(Date.now()));

    laeuftGerade = true;
    try {
      return await serverSyncDurchfuehren();
    } catch (e) {
      // Echte Fehlermeldung statt eines generischen "netzwerk"-Labels -
      // sonst nicht unterscheidbar, ob es wirklich am Netz liegt oder an
      // einem Bug (IndexedDB, FK-Auflösung, o.ä.).
      return { ok: false, grund: (e && (e.message || e.toString())) || "unbekannter Fehler" };
    } finally {
      laeuftGerade = false;
    }
  }

  // Doppelter Einstieg wie bei hot-update.js: automatisch beim Laden
  // (gedrosselt), zusätzlich manuell (z.B. Button in account.html) über
  // dieselbe Kernfunktion mit ignoriereIntervall=true.
  window.GOServerSync = {
    jetzt: () => pruefeUndSynchronisiere({ ignoriereIntervall: true }),
    hatToken: () => !!token(),
    setzeToken: (t) => localStorage.setItem(LS_TOKEN, String(t || "").trim()),
    letzterSyncZeitpunkt: async () => {
      const c = await window.LocalDB.get("meta", "serverSyncCursor");
      return c ? c.value : null;
    },
    // Löscht den lokalen Sync-Cursor, OHNE irgendwelche lokalen Daten
    // anzufassen: baueAusgehendeAenderungen() sendet ab dem nächsten Lauf
    // dadurch wieder ALLE lokalen Zeilen (seit=null), nicht nur die seit dem
    // letzten Cursor geänderten. Nötig, wenn der Server-Stand hinter diesem
    // Gerät zurückfällt (z.B. nach einem Server-seitigen Reset/Restore) - der
    // Cursor allein kann das nicht erkennen, er kennt nur "wann habe ich
    // zuletzt erfolgreich synchronisiert", nicht ob der Server seitdem Daten
    // verloren hat.
    vollstaendigNeuSynchronisieren: async () => {
      await window.LocalDB.delete("meta", "serverSyncCursor");
      return pruefeUndSynchronisiere({ ignoriereIntervall: true });
    }
  };

  if (document.readyState === "complete") {
    pruefeUndSynchronisiere();
  } else {
    window.addEventListener("load", () => pruefeUndSynchronisiere());
  }
})();
