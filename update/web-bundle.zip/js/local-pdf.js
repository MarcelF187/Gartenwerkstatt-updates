// Client-seitige PDF-Erzeugung für die server-lose App.
//
// Ersetzt den früheren Server-Rendering-Weg (htmlToPdf.js/pdf-service).
//
// Frühere Versionen bauten das Layout als HTML und rasterisierten es über
// html2canvas zu einem Bild, das dann ins PDF eingebettet wurde. Das hat sich
// auf dem Android-Gerät als unzuverlässig erwiesen: html2canvas rendert auf
// diesem WebView Text innerhalb von Zellen teils gedreht bzw. nicht vertikal
// zentriert, und rundet Spaltenbreiten leicht unterschiedlich (sichtbarer
// Versatz der Rahmenlinien) - alles Rendering-Eigenheiten des jeweiligen
// WebViews, die sich in dieser Entwicklungsumgebung nicht nachstellen ließen.
//
// Deshalb zeichnet dieses Modul die Berichte jetzt direkt mit jsPDFs eigenen
// Vektor-Befehlen (rect/text/addImage) - reine JavaScript-Arithmetik, die auf
// jedem Gerät identisch läuft, weil dabei nirgends die CSS-Layout-Engine des
// Browsers oder html2canvas beteiligt ist. Nebeneffekt: deutlich kleinere
// Dateien (echter Vektor-Text statt Raster-Bild) und gestochen scharfe
// Darstellung in jeder Zoomstufe.
(function () {
  "use strict";

  function txt(v) {
    return String(v ?? "").trim();
  }
  function dash(v) {
    const s = txt(v);
    return s === "" ? "-" : s;
  }
  function sanitizeFilenamePart(v) {
    return String(v ?? "").trim().replace(/[\\/:*?"<>|]/g, "").replace(/\s+/g, "_");
  }
  function pad(arr, min) {
    const a = [...(arr || [])];
    while (a.length < min) a.push(null);
    return a;
  }

  // ------------------------------------------------------- Logo als Bild
  // jsPDF kann kein SVG einbetten - das Logo liegt deshalb zusätzlich als
  // einmalig vorgerenderte JPEG-Datei vor (public/logos/GrueneOase_pdf_logo.jpg,
  // auf Weiß geflattet statt PNG mit Alphakanal - jsPDF bettet PNG-Transparenz
  // unkomprimiert ein, das wäre >10x größer als nötig).
  let logoPromise = null;
  function blobZuDatenUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(String(reader.result));
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
  }
  function ladeLogoDatenUrl() {
    if (!logoPromise) {
      logoPromise = fetch("/logos/GrueneOase_pdf_logo.jpg")
        .then((res) => res.blob())
        .then(blobZuDatenUrl)
        .catch(() => null);
    }
    return logoPromise;
  }

  // ---------------------------------------------------- jsPDF-Tabellen-Helfer
  const SPALTEN = [34, 16, 16, 17, 17]; // % - 5 Basisspalten, wie in der Excel-Vorlage
  const RAND_MM = 8;
  const ZEILE_MM = 4.5;
  const TITEL_ZEILE_MM = 16.5;
  const UNTERSCHRIFT_ZEILE_MM = 12;
  const SCHRIFT_NORMAL = 9;
  const SCHRIFT_BIG = 11;
  const SCHRIFT_TITEL = 15;
  const ZELLEN_PADDING_MM = 1.3;

  function spaltenX(startX, breite) {
    const xs = [startX];
    for (const p of SPALTEN) xs.push(xs[xs.length - 1] + (breite * p) / 100);
    return xs; // 6 Grenzen für 5 Spalten
  }

  function kuerzeText(doc, text, maxBreiteMm) {
    if (!text) return "";
    if (doc.getTextWidth(text) <= maxBreiteMm) return text;
    let t = text;
    while (t.length > 1 && doc.getTextWidth(t + "…") > maxBreiteMm) t = t.slice(0, -1);
    return t + "…";
  }

  function zeichneZelle(doc, x, y, w, h, text, o = {}) {
    doc.rect(x, y, w, h);
    const inhalt = txt(text);
    if (!inhalt) return;
    doc.setFont(undefined, o.fett ? "bold" : "normal");
    doc.setFontSize(o.groesse || SCHRIFT_NORMAL);
    const maxBreite = w - ZELLEN_PADDING_MM * 2;
    const gekuerzt = kuerzeText(doc, inhalt, maxBreite);
    const align = o.align || "left";
    const textX = align === "center" ? x + w / 2 : x + ZELLEN_PADDING_MM;
    doc.text(gekuerzt, textX, y + h / 2, { align, baseline: "middle" });
  }

  // Zeichnet eine Bild-Zelle (Logo/Unterschrift) zentriert innerhalb des
  // gegebenen Rahmens, mit korrektem Seitenverhältnis.
  function zeichneBildZelle(doc, x, y, w, h, datenUrl, maxBildHoeheMm) {
    doc.rect(x, y, w, h);
    if (!datenUrl) return;
    let eigenschaften;
    try {
      eigenschaften = doc.getImageProperties(datenUrl);
    } catch {
      return;
    }
    const seitenverhaeltnis = eigenschaften.width / eigenschaften.height;
    let bildH = Math.min(maxBildHoeheMm, h - 2);
    let bildW = bildH * seitenverhaeltnis;
    const maxBildBreiteMm = w - 2;
    if (bildW > maxBildBreiteMm) {
      bildW = maxBildBreiteMm;
      bildH = bildW / seitenverhaeltnis;
    }
    doc.addImage(datenUrl, eigenschaften.fileType || "PNG", x + (w - bildW) / 2, y + (h - bildH) / 2, bildW, bildH);
  }

  // ---------------------------------------------- Tagesbericht/Bautagesbericht
  // Gemeinsames Layout (Excel-Vorlage "Tagesbericht") - Titelzeile ist der
  // einzige Unterschied zwischen Pflege- und Bau-Variante.
  async function zeichneTagesbericht(doc, data, titel) {
    const d = data || {};
    const breiteSeite = doc.internal.pageSize.getWidth();
    const hoeheSeite = doc.internal.pageSize.getHeight();
    const startX = RAND_MM;
    const breite = breiteSeite - RAND_MM * 2;
    const xs = spaltenX(startX, breite);
    let y = RAND_MM;

    doc.setDrawColor(0);
    doc.setLineWidth(0.2);
    doc.setTextColor(0);

    // Zeilenhöhe wird dynamisch berechnet statt fest auf ZEILE_MM zu stehen:
    // die Anzahl der Zeilen (Kopfzeilen + Mitarbeiter/Tätigkeiten/Material/
    // Maschinen + Vermerke) steht vorher schon fest, damit die Tabelle exakt
    // bis zum unteren Rand reicht statt darüber hinweg ein Stück frei zu
    // lassen - Rückmeldung aus dem Büro war, dass der ausgedruckte Bericht
    // sonst nicht wie ein richtig ausgefülltes Formular aussieht. Nur wenn
    // tatsächlich mehr Zeilen als üblich gebraucht werden (z.B. sehr viele
    // Mitarbeiter), bleibt es bei der ursprünglichen Mindesthöhe und der
    // Bericht wächst wie gehabt auf eine zweite Seite.
    const bemerkungZeilenN = Math.max(1, txt(d.bemerkungen).split("\n").length);
    const kopfzeilenN = 8; // Baustelle, Wetter, Name-Header, Tätigkeiten-Header, Materiallieferung-Header, Materialabfuhr-Header, Maschinen-Header, Vermerke-Header
    const gesamtZeilenN =
      kopfzeilenN +
      pad(d.mitarbeiter, 6).length +
      pad(d.taetigkeiten, 6).length +
      pad(d.materialLieferung, 5).length +
      pad(d.materialAbfuhr, 4).length +
      pad(d.maschinen, 2).length +
      bemerkungZeilenN +
      2; // Leerzeilen nach den Vermerken
    const verfuegbareHoeheFuerZeilen = hoeheSeite - RAND_MM * 2 - TITEL_ZEILE_MM - UNTERSCHRIFT_ZEILE_MM;
    const zeileMm = Math.max(ZEILE_MM, verfuegbareHoeheFuerZeilen / gesamtZeilenN);

    // Toleranz gegen Fließkomma-Rundungsfehler: zeileMm ist so berechnet,
    // dass die letzte Zeile exakt auf der unteren Randlinie endet - nach
    // gut 30 Additionen könnte das rechnerisch hauchdünn (< 0,01mm) darüber
    // liegen und faelschlich einen Seitenumbruch fuer die letzte Zeile
    // (Unterschrift) auslösen.
    const RUNDUNGSTOLERANZ_MM = 0.1;

    function neueSeiteFallsNoetig(hoehe) {
      if (y + hoehe > hoeheSeite - RAND_MM + RUNDUNGSTOLERANZ_MM) {
        doc.addPage();
        y = RAND_MM;
      }
    }

    function zeile(zellen, hoehe) {
      const h = hoehe || zeileMm;
      neueSeiteFallsNoetig(h);
      let colIdx = 0;
      for (const z of zellen) {
        const x0 = xs[colIdx];
        const x1 = xs[colIdx + z.span];
        zeichneZelle(doc, x0, y, x1 - x0, h, z.text, z.o);
        colIdx += z.span;
      }
      y += h;
    }

    const leer = { span: 1, text: "" };
    const l = (t) => ({ span: 1, text: t, o: { fett: true } });
    const lc = (t) => ({ span: 1, text: t, o: { fett: true, align: "center" } });
    const v = (t, span = 1) => ({ span, text: t });

    // Titelzeile mit Logo
    neueSeiteFallsNoetig(TITEL_ZEILE_MM);
    zeichneZelle(doc, xs[0], y, xs[3] - xs[0], TITEL_ZEILE_MM, titel, { fett: true, groesse: SCHRIFT_TITEL });
    const logoDatenUrl = await ladeLogoDatenUrl();
    zeichneBildZelle(doc, xs[3], y, xs[5] - xs[3], TITEL_ZEILE_MM, logoDatenUrl, 14);
    y += TITEL_ZEILE_MM;

    zeile([l("Baustelle:"), v(d.baustelle, 2), l("Datum:"), v(d.datum)]);
    zeile([l("Wetter:"), v(d.wetter, 2), l("Temperatur:"), v(d.temperatur || "")]);
    zeile([l("Name:"), lc("Beginn"), lc("Ende"), lc("Pause"), lc("Arbeitszeit")]);

    for (const m of pad(d.mitarbeiter, 6)) {
      zeile([v(m ? m.name : ""), v(m ? m.start : ""), v(m ? m.ende : ""), v(m ? m.pause : ""), v(m ? m.gesamt : "")]);
    }

    zeile([{ span: 5, text: "Ausgeführte Tätigkeiten:", o: { fett: true } }]);
    for (const t of pad(d.taetigkeiten, 6)) {
      let text = "";
      if (t) {
        const parts = [];
        if (t.menge) parts.push(`${t.menge} ${t.einheit || "m²"}`);
        if (t.stunden) parts.push(`${t.stunden} Std.`);
        text = `${t.bezeichnung || ""}${parts.length ? ` (${parts.join(", ")})` : ""}`;
      }
      zeile([{ span: 5, text }]);
    }

    const materialZeile = (m) => [v(m ? m.bezeichnung : ""), v(m ? m.menge : ""), v(m ? m.einheit : ""), v(m ? m.lieferschein : ""), v(m ? m.lieferant : "")];
    zeile([l("Materiallieferung:"), lc("Menge"), lc("Einheit"), lc("Liefersch.-Nr."), lc("Lieferant")]);
    for (const m of pad(d.materialLieferung, 5)) zeile(materialZeile(m));

    zeile([l("Materialabfuhr:"), leer, leer, leer, leer]);
    for (const m of pad(d.materialAbfuhr, 4)) zeile(materialZeile(m));

    zeile([{ span: 4, text: "Maschineneinsatz:", o: { fett: true } }, l("Std.")]);
    for (const m of pad(d.maschinen, 2)) {
      zeile([v(m ? m.bezeichnung : ""), leer, leer, leer, v(m ? `${m.dauer} ${m.einheit}` : "")]);
    }

    zeile([l("Besondere Vermerke:"), leer, leer, leer, leer]);
    // Erste Zeile trägt die Bemerkungen (wächst bei mehrzeiligem Text über die
    // Standardzeilenhöhe hinaus), danach 3 leere Zusatzzeilen wie im Original.
    const bemerkungZeilen = txt(d.bemerkungen).split("\n");
    const bemerkungHoehe = Math.max(zeileMm, bemerkungZeilen.length * zeileMm);
    neueSeiteFallsNoetig(bemerkungHoehe);
    doc.rect(xs[0], y, xs[5] - xs[0], bemerkungHoehe);
    doc.setFont(undefined, "normal");
    doc.setFontSize(SCHRIFT_NORMAL);
    bemerkungZeilen.forEach((zeileText, i) => {
      const gekuerzt = kuerzeText(doc, zeileText, xs[5] - xs[0] - ZELLEN_PADDING_MM * 2);
      if (gekuerzt) doc.text(gekuerzt, xs[0] + ZELLEN_PADDING_MM, y + (i + 0.5) * zeileMm, { baseline: "middle" });
    });
    y += bemerkungHoehe;
    zeile([{ span: 5, text: "" }]);
    zeile([{ span: 5, text: "" }]);

    // Unterschriftzeile
    neueSeiteFallsNoetig(UNTERSCHRIFT_ZEILE_MM);
    zeichneZelle(doc, xs[0], y, xs[1] - xs[0], UNTERSCHRIFT_ZEILE_MM, "Vorarbeiter:", { fett: true, groesse: SCHRIFT_BIG });
    zeichneBildZelle(doc, xs[1], y, xs[2] - xs[1], UNTERSCHRIFT_ZEILE_MM, d.unterschrift || null, UNTERSCHRIFT_ZEILE_MM - 2);
    zeichneZelle(doc, xs[2], y, xs[3] - xs[2], UNTERSCHRIFT_ZEILE_MM, "Auftraggeber:", { fett: true, groesse: SCHRIFT_BIG });
    doc.rect(xs[3], y, xs[5] - xs[3], UNTERSCHRIFT_ZEILE_MM);
    y += UNTERSCHRIFT_ZEILE_MM;
  }

  function tagesberichtDateiname(berichtNr, dateiFallback) {
    return `${sanitizeFilenamePart(berichtNr) || dateiFallback}.pdf`;
  }

  // -------------------------------------------------------- Rote Termine
  async function zeichneRoteTermine(doc, liste, columns, rows) {
    const heute = new Date().toLocaleDateString("de-DE");
    const breiteSeite = doc.internal.pageSize.getWidth();
    const hoeheSeite = doc.internal.pageSize.getHeight();
    const startX = RAND_MM;
    const breite = breiteSeite - RAND_MM * 2;
    let y = RAND_MM;

    doc.setDrawColor(0);
    doc.setLineWidth(0.2);
    doc.setTextColor(0);

    // Kopfbereich: Liste/Auftraggeber links, Firmenname + Meta rechts
    doc.setFont(undefined, "bold");
    doc.setFontSize(13);
    doc.text("Rote Termine – Abrechnung (noch offen)", startX, y + 4);
    doc.setFont(undefined, "bold");
    doc.setFontSize(14);
    doc.setTextColor(6, 95, 70);
    doc.text("Grüne Oase GaLaBau", startX + breite, y + 4, { align: "right" });
    doc.setTextColor(0);
    y += 8;

    doc.setFontSize(SCHRIFT_NORMAL);
    doc.setFont(undefined, "bold");
    doc.text("Liste:", startX, y);
    const listeLabelBreite = doc.getTextWidth("Liste:");
    doc.setFont(undefined, "normal");
    doc.text(dash(liste.name), startX + listeLabelBreite + 1.5, y);
    y += 5;
    if (liste.auftraggeber) {
      doc.setFont(undefined, "bold");
      doc.text("Auftraggeber:", startX, y);
      const auftraggeberLabelBreite = doc.getTextWidth("Auftraggeber:");
      doc.setFont(undefined, "normal");
      doc.text(dash(liste.auftraggeber), startX + auftraggeberLabelBreite + 1.5, y);
      y += 5;
    }
    doc.setLineWidth(0.2);
    doc.line(startX + breite * 0.6, y - 9, startX + breite, y - 9);
    doc.setFont(undefined, "bold");
    doc.text(`Erstellt am: ${heute}`, startX + breite, y - 5, { align: "right" });
    doc.text(`Anzahl Termine: ${rows.length}`, startX + breite, y, { align: "right" });
    y += 6;

    const anzahlSpalten = columns.length;
    const spaltenBreite = breite / anzahlSpalten;
    const xs = Array.from({ length: anzahlSpalten + 1 }, (_, i) => startX + i * spaltenBreite);

    function neueSeiteFallsNoetig(hoehe) {
      if (y + hoehe > hoeheSeite - RAND_MM) {
        doc.addPage();
        y = RAND_MM;
      }
    }

    function tabellenZeile(werte, o = {}) {
      const h = ZEILE_MM;
      neueSeiteFallsNoetig(h);
      if (o.hintergrund) {
        doc.setFillColor(...o.hintergrund);
        doc.rect(xs[0], y, xs[anzahlSpalten] - xs[0], h, "F");
      }
      for (let i = 0; i < werte.length; i++) {
        zeichneZelle(doc, xs[i], y, xs[i + 1] - xs[i], h, werte[i], { fett: o.fett, groesse: SCHRIFT_NORMAL - 1 });
      }
      y += h;
    }

    tabellenZeile(columns, { hintergrund: [241, 245, 249], fett: true });
    if (rows.length) {
      for (const r of rows) tabellenZeile(columns.map((c) => dash(r[c])));
    } else {
      neueSeiteFallsNoetig(ZEILE_MM);
      doc.rect(xs[0], y, xs[anzahlSpalten] - xs[0], ZEILE_MM);
      doc.setFont(undefined, "normal");
      doc.setFontSize(SCHRIFT_NORMAL - 1);
      doc.text("Keine offenen roten Termine vorhanden", startX + breite / 2, y + ZEILE_MM / 2, { align: "center", baseline: "middle" });
      y += ZEILE_MM;
    }
  }

  function roteTermineDateiname(liste) {
    return `Rote_Termine_${(liste.name || "Liste").replace(/[^\w-]+/g, "_")}.pdf`;
  }

  // ---------------------------------------------------------- PDF-Rendering
  async function warteAufJsPdf() {
    let versuche = 0;
    while (!window.jspdf && versuche < 100) {
      await new Promise((r) => setTimeout(r, 50));
      versuche++;
    }
    if (!window.jspdf) throw new Error("jsPDF nicht geladen");
  }

  // ---------------------------------------------------- Speichern/Teilen
  // Das eigentliche Speichern/Teilen (nativer App-Share vs. Browser-Download)
  // lebt jetzt gemeinsam für alle Export-Typen (PDF, Excel, CSV, ...) in
  // share.js - lokal nur noch dünne Weiterreichung für bestehende Aufrufer.
  const { speichereUndTeile, speichereUndTeileMehrere, istNativeApp } = window.Share;

  async function tagesberichtDokument(data, titel) {
    await warteAufJsPdf();
    const doc = new window.jspdf.jsPDF({ unit: "mm", format: "a4", orientation: "portrait" });
    await zeichneTagesbericht(doc, data, titel);
    return doc;
  }

  async function roteTermineDokument(liste, columns, rows) {
    await warteAufJsPdf();
    const doc = new window.jspdf.jsPDF({ unit: "mm", format: "a4", orientation: "landscape" });
    await zeichneRoteTermine(doc, liste, columns, rows);
    return doc;
  }

  window.LocalPdf = {
    async tagesbericht(data, opts) {
      const doc = await tagesberichtDokument(data, "Tagesbericht Grünpflege");
      const filename = tagesberichtDateiname(opts?.berichtNr, "Pflegebericht_Entwurf");
      await speichereUndTeile(doc.output("blob"), filename);
    },
    async bautagesbericht(data, opts) {
      const doc = await tagesberichtDokument(data, "Tagesbericht Bau");
      const filename = tagesberichtDateiname(opts?.berichtNr, "Bautagesbericht_Entwurf");
      await speichereUndTeile(doc.output("blob"), filename);
    },
    async roteTermine(liste, columns, rows) {
      const doc = await roteTermineDokument(liste, columns, rows);
      await speichereUndTeile(doc.output("blob"), roteTermineDateiname(liste));
    },
    // Blob-Varianten für Bulk-Export/Teilen (admin/berichte.html) - liefern
    // die Datei statt sie sofort selbst zu speichern/teilen.
    async tagesberichtBlob(data, opts) {
      const doc = await tagesberichtDokument(data, "Tagesbericht Grünpflege");
      return { blob: doc.output("blob"), filename: tagesberichtDateiname(opts?.berichtNr, "Pflegebericht_Entwurf") };
    },
    async bautagesberichtBlob(data, opts) {
      const doc = await tagesberichtDokument(data, "Tagesbericht Bau");
      return { blob: doc.output("blob"), filename: tagesberichtDateiname(opts?.berichtNr, "Bautagesbericht_Entwurf") };
    },
    // Für admin/berichte.html: eine bzw. mehrere fertige {blob, filename} nativ
    // speichern/teilen oder im Browser herunterladen.
    speichereUndTeile,
    speichereUndTeileMehrere,
    istNativeApp
  };
})();
