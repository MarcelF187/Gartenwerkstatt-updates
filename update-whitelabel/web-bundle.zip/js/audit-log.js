// Audit-Log: fängt unerwartete JS-Fehler global ab und protokolliert sie
// zusammen mit den gezielten Aktions-Einträgen aus local-db.js (siehe dort
// PROTOKOLL_STORES/LocalDB.protokolliere) in den lokalen "audit_log"-Store.
// Ziel: Vorfälle wie "Pflegeliste plötzlich leer" im Nachhinein zeitlich
// einordnen können, auch wenn niemand im Moment des Auftretens etwas
// bemerkt hat - siehe public/protokoll.html für die Ansicht.
(function () {
  "use strict";

  function D() { return window.LocalDB; }

  async function fehler(bereich, beschreibung, detail) {
    try {
      if (!D() || !D().protokolliere) return;
      await D().protokolliere({
        typ: "fehler", bereich: bereich || "js",
        aktion: "unerwarteter_fehler",
        beschreibung: String(beschreibung || "").slice(0, 500),
        detail: typeof detail === "string" ? detail.slice(0, 4000) : JSON.stringify(detail || {}).slice(0, 4000)
      });
    } catch { /* Protokoll ist best-effort - darf nichts weiter stören */ }
  }

  async function aktion(bereich, aktionName, beschreibung, detail) {
    try {
      if (!D() || !D().protokolliere) return;
      await D().protokolliere({
        typ: "aktion", bereich: bereich || "js", aktion: aktionName,
        beschreibung: String(beschreibung || "").slice(0, 500),
        detail: typeof detail === "string" ? detail.slice(0, 4000) : JSON.stringify(detail || {}).slice(0, 4000)
      });
    } catch { /* best-effort */ }
  }

  window.GOAudit = { fehler, aktion };

  window.addEventListener("error", (e) => {
    fehler("js", e.message || "Unbekannter Fehler", {
      quelle: e.filename || null, zeile: e.lineno || null, spalte: e.colno || null,
      stack: e.error && e.error.stack ? String(e.error.stack).slice(0, 2000) : null,
      seite: location.pathname
    });
  });

  window.addEventListener("unhandledrejection", (e) => {
    const grund = e.reason;
    fehler("js", (grund && grund.message) ? grund.message : String(grund), {
      stack: grund && grund.stack ? String(grund.stack).slice(0, 2000) : null,
      seite: location.pathname
    });
  });
})();
