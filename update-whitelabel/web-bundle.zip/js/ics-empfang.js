// Empfang von Kalendereinladungen (.ics) direkt in der App - ganz ohne
// Server, API-Key oder Konto-Einrichtung: der Nutzer teilt eine Einladung
// aus seiner Email-App (Gmail, Outlook, ...) per "Teilen"/"Öffnen mit" an
// diese App. Android reicht die Datei über einen Intent an MainActivity.java
// weiter, die den Inhalt am nativen "IcsEmpfang"-Plugin bereithält
// (siehe android/.../IcsEmpfangPlugin.java) - dieses Skript holt ihn ab.
//
// Zwei Auslöser, weil eine Einladung sowohl bei kaltem App-Start (Intent kam
// vor dem ersten Laden dieser Seite) als auch bei bereits laufender App
// (Activity kommt per onNewIntent in den Vordergrund, während irgendeine
// andere Seite offen ist) ankommen kann:
//   - "load": deckt den kalten Start ab.
//   - "visibilitychange" (Seite wird wieder sichtbar): deckt den Fall ab,
//     dass die App schon offen war und per Teilen erneut in den Vordergrund
//     geholt wurde.
(function () {
  "use strict";

  function nativePlugin() {
    if (!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform())) return null;
    return (window.Capacitor.Plugins && window.Capacitor.Plugins.IcsEmpfang) || null;
  }

  function zeigeMeldung(text, ok) {
    const el = document.createElement("div");
    el.textContent = text;
    el.style.cssText = `position:fixed;left:50%;bottom:24px;transform:translateX(-50%);
      z-index:99999;padding:12px 18px;border-radius:12px;font:14px/1.4 system-ui,sans-serif;
      max-width:90vw;text-align:center;box-shadow:0 4px 16px rgba(0,0,0,.25);
      background:${ok ? "#166534" : "#991b1b"};color:#fff;`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 4000);
  }

  async function uebernehmeTermin(e) {
    const res = await fetch("/api/termine/aus-einladung", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(e)
    });
    return res.json();
  }

  async function verarbeite(icsText) {
    let eintraege;
    try {
      eintraege = window.IcsParser.parseIcs(icsText);
    } catch (err) {
      zeigeMeldung("Einladung konnte nicht gelesen werden.", false);
      return;
    }
    if (!eintraege.length) {
      zeigeMeldung("Keine gültige Kalendereinladung gefunden.", false);
      return;
    }
    for (const e of eintraege) {
      try {
        await uebernehmeTermin(e);
      } catch (err) {
        console.error("ics-empfang: Termin konnte nicht übernommen werden:", err);
      }
    }
    const erster = eintraege[0];
    if (erster.abgesagt) {
      zeigeMeldung(`Termin abgesagt: ${erster.titel}`, true);
    } else {
      zeigeMeldung(`✅ Termin übernommen: ${erster.titel}`, true);
    }
  }

  async function pruefeEingang() {
    const plugin = nativePlugin();
    if (!plugin) return;
    try {
      const { text } = await plugin.getPending();
      if (text) await verarbeite(text);
    } catch (err) {
      console.error("ics-empfang: Abruf fehlgeschlagen:", err);
    }
  }

  window.addEventListener("load", pruefeEingang);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) pruefeEingang(); });
})();
