// Sicherung (Export/Import) der gesamten lokalen Datenbank - server-lose App.
//
// Nutzt bewusst die bereits vorhandene Serialisierungs-/Merge-Engine aus
// public/js/lan-sync.js (window.GoLanSync.exportiereAlleDaten/
// importiereAlleDaten), statt eine eigene zu bauen: dieselbe Logik übersetzt
// dort schon lokale IDs <-> client_uuid-Fremdschlüssel für den WLAN-Abgleich.
// Ein Export mit seit=null liefert einen vollständigen Dump; ein Import auf
// eine leere/neue Datenbank verhält sich dadurch wie ein sauberer Restore.
(function () {
  "use strict";

  const FORMAT = "go-backup-v1";

  function jetztAlsDateiname() {
    const d = new Date();
    const p2 = (n) => String(n).padStart(2, "0");
    return `sicherung_${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}.json`;
  }

  // Baut die Sicherungsdatei: alle Sync-Stores (über lan-sync.js) plus die
  // Bild-Blobs der drei Foto-Stores (Notizen/Heckenschnitt/Baupläne), als
  // Base64 eingebettet - dieselbe Kodierung, die lan-sync.js für den
  // WLAN-Fototransport bereits verwendet.
  async function exportiere() {
    const LanSync = window.GoLanSync;
    const changes = await LanSync.exportiereAlleDaten();
    const bilder = {};
    for (const store of LanSync.BILDER_STORES) {
      const zeilen = await window.LocalDB.getAll(store);
      const eintraege = {};
      for (const z of zeilen) {
        if (!z.blob || !z.client_uuid) continue;
        eintraege[z.client_uuid] = await LanSync.blobZuBase64(z.blob);
      }
      if (Object.keys(eintraege).length) bilder[store] = eintraege;
    }
    const payload = { format: FORMAT, erstellt_am: new Date().toISOString(), changes, bilder };
    const blob = new Blob([JSON.stringify(payload)], { type: "application/json" });
    await window.Share.speichereUndTeile(blob, jetztAlsDateiname());
    return payload;
  }

  // Zeilenzahlen je Store für den Bestätigungsdialog vor dem eigentlichen
  // Import - reine Anzeige, verändert noch nichts.
  function zusammenfassung(payload) {
    const zeilen = {};
    for (const [store, arr] of Object.entries(payload.changes || {})) {
      if (Array.isArray(arr) && arr.length) zeilen[store] = arr.length;
    }
    let fotos = 0;
    for (const eintraege of Object.values(payload.bilder || {})) fotos += Object.keys(eintraege).length;
    return { zeilen, fotos };
  }

  // Spielt eine zuvor exportierte Sicherung ein. Bei einer bereits lokal
  // bekannten Zeile gewinnt die NEUERE Version (Zeitstempel-Vergleich, siehe
  // istEingehendAktueller()/ueberschreiben:true in lan-sync.js) - eine alte
  // Sicherung kann seither lokal aktuellere Daten also nicht mehr
  // zurücksetzen. Lokale Zeilen, die NICHT in der Sicherung stehen, werden
  // ohnehin nicht gelöscht.
  async function importiere(payload) {
    if (!payload || payload.format !== FORMAT) throw new Error("ungueltiges_format");
    const LanSync = window.GoLanSync;
    await LanSync.importiereAlleDaten(payload.changes || {});
    for (const [store, eintraege] of Object.entries(payload.bilder || {})) {
      for (const [uuid, base64] of Object.entries(eintraege)) {
        await LanSync.speichereEmpfangenesFoto(store, uuid, base64);
      }
    }
  }

  window.GoBackup = { exportiere, importiere, zusammenfassung };
})();
