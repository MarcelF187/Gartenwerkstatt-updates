// Lokale Sicherung der Geräte-Datenbank (Export/Import als eine Datei) -
// server-lose App, also lebt jede Zeile Nutzdaten NUR in der IndexedDB dieses
// Tablets. Bei Verlust/Reset des Geräts geht ohne diese Funktion alles
// verloren, das noch nicht per WLAN-Sync (siehe lan-sync.js) auf einem
// anderen Gerät gespiegelt wurde.
//
// Baut bewusst auf lan-sync.js auf statt eigene Serialisierung zu schreiben:
// exportiereAlleDaten()/importiereAlleDaten() dort sind reine Aliase auf die
// Funktionen, die den WLAN-Peer-Sync antreiben (baueAusgehendeAenderungen/
// wendeAenderungenAn) - dieselbe Logik, nur als Datei statt über HTTP an ein
// zweites Gerät geschickt.
(function () {
  "use strict";

  const FORMAT = "go-backup-v1";

  function dateiname() {
    const j = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    return `sicherung_${j.getFullYear()}-${pad(j.getMonth() + 1)}-${pad(j.getDate())}_${pad(j.getHours())}${pad(j.getMinutes())}.json`;
  }

  // Baut die komplette Sicherungsdatei: alle Stores aus lan-sync.js
  // (exportiereAlleDaten) plus die Foto-Inhalte der drei Blob-Stores separat
  // als Base64 - im "changes"-Teil stehen die Blob-Store-Zeilen selbst zwar
  // schon drin (Metadaten wie notiz_id/datei_typ), aber ohne den Blob, da
  // Blobs beim normalen WLAN-Sync-Transport ueber einen eigenen HTTP-Weg pro
  // Foto laufen (siehe ladeNeueFotosHoch in lan-sync.js) statt im JSON zu
  // stecken - fuer eine einzelne Sicherungsdatei werden sie hier stattdessen
  // direkt eingebettet.
  async function exportiere() {
    const LanSync = window.GoLanSync;
    if (!LanSync || !LanSync.exportiereAlleDaten) {
      throw new Error("Sicherung ist in dieser Version nicht verfügbar");
    }
    const changes = await LanSync.exportiereAlleDaten();

    const bilder = {};
    for (const store of LanSync.BILDER_STORES) {
      const rows = await window.LocalDB.getAll(store);
      const eintraege = {};
      for (const row of rows) {
        if (!row.blob || row.deleted_at || !row.client_uuid) continue;
        eintraege[row.client_uuid] = await LanSync.blobZuBase64(row.blob);
      }
      if (Object.keys(eintraege).length) bilder[store] = eintraege;
    }

    const payload = { format: FORMAT, erstellt_am: new Date().toISOString(), changes, bilder };
    const blob = new Blob([JSON.stringify(payload)], { type: "application/json" });
    await window.Share.speichereUndTeile(blob, dateiname());
    return payload;
  }

  // Kurzfassung fuer den Bestätigungsdialog vor dem eigentlichen Import -
  // wie viele Zeilen je Store und wie viele Fotos stecken in der Datei.
  function zusammenfassung(payload) {
    const zeilen = Object.entries(payload.changes || {})
      .filter(([, arr]) => Array.isArray(arr) && arr.length)
      .map(([store, arr]) => `${store}: ${arr.length}`);
    const fotos = Object.values(payload.bilder || {}).reduce((sum, obj) => sum + Object.keys(obj).length, 0);
    if (fotos) zeilen.push(`Fotos: ${fotos}`);
    return zeilen.join(", ") || "keine Daten";
  }

  // Übernimmt zuerst alle Store-Zeilen (legt dabei auch die Blob-Store-Zeilen
  // OHNE Foto-Inhalt an), haengt danach je Blob-Store-Zeile den Foto-Inhalt
  // per client_uuid an - exakt derselbe zweistufige Ablauf (erst Metadaten,
  // dann Blob), den lan-sync.js beim WLAN-Sync fuer denselben Zweck nutzt.
  async function importiere(payload) {
    if (!payload || payload.format !== FORMAT) {
      throw new Error("Das ist keine gültige Sicherungsdatei dieser App");
    }
    const LanSync = window.GoLanSync;
    if (!LanSync || !LanSync.importiereAlleDaten) {
      throw new Error("Sicherung ist in dieser Version nicht verfügbar");
    }
    await LanSync.importiereAlleDaten(payload.changes || {});

    for (const [store, eintraege] of Object.entries(payload.bilder || {})) {
      for (const [uuid, base64] of Object.entries(eintraege)) {
        await LanSync.speichereEmpfangenesFoto(store, uuid, base64);
      }
    }
  }

  window.GoBackup = { exportiere, importiere, zusammenfassung, FORMAT };
})();
