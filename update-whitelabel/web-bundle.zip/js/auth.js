// Offline-fähiger Benutzer-Kontext (Phase 2).
//
// - Merkt sich nach jedem Online-Login die auf dem Gerät bekannten Nutzer
//   (Name, Rolle, ID – KEIN Passwort) in localStorage.
// - Offline bleibt die App als zuletzt aktiver Nutzer angemeldet (kein Sprung
//   zur Login-Seite), weil der Service Worker die Seiten ohnehin aus dem Cache
//   liefert.
// - Erlaubt einen Offline-Benutzerwechsel zwischen den bekannten Nutzern, damit
//   die Erfassung dem richtigen Mitarbeiter zugeordnet wird (2 Leute, 1 Tablet).
//
// Der tatsächlich aktive Nutzer ist über window.GOAuth.active() abrufbar und
// wird in Phase 4 als Autor an offline erfasste Datensätze gehängt.
(function () {
  const LS_KNOWN = "go-known-users";
  const LS_ACTIVE = "go-active-user";

  const readKnown = () => { try { return JSON.parse(localStorage.getItem(LS_KNOWN) || "{}"); } catch { return {}; } };
  const writeKnown = (m) => localStorage.setItem(LS_KNOWN, JSON.stringify(m));

  const GOAuth = {
    remember(user) {
      if (!user || !user.username) return;
      const m = readKnown();
      m[user.username] = {
        username: user.username, role: user.role, id: user.id,
        email: user.email || null, gemerktAm: Date.now()
      };
      writeKnown(m);
      localStorage.setItem(LS_ACTIVE, user.username);
    },
    known() {
      return Object.values(readKnown()).sort((a, b) => a.username.localeCompare(b.username, "de"));
    },
    active() {
      const u = localStorage.getItem(LS_ACTIVE);
      const m = readKnown();
      return (u && m[u]) ? m[u] : (this.known()[0] || null);
    },
    setActive(username) {
      const m = readKnown();
      if (!m[username]) return false;
      localStorage.setItem(LS_ACTIVE, username);
      return true;
    },
    vergessen(username) {
      const m = readKnown();
      delete m[username];
      writeKnown(m);
      if (localStorage.getItem(LS_ACTIVE) === username) {
        const rest = Object.keys(m)[0];
        if (rest) localStorage.setItem(LS_ACTIVE, rest); else localStorage.removeItem(LS_ACTIVE);
      }
    },
    // Prüft den Anmeldestatus, offline-tolerant:
    //   online + angemeldet -> merkt den Nutzer, gibt ihn zurück
    //   online + 401        -> nicht angemeldet
    //   offline             -> zuletzt aktiver, lokal gemerkter Nutzer
    async refresh() {
      try {
        const res = await fetch("/api/auth/me", { credentials: "include", headers: { "Content-Type": "application/json" } });
        if (res.status === 401) return { authenticated: false, offline: false };
        const d = await res.json();
        if (d.authenticated && d.user) {
          this.remember(d.user);
          // Angemeldet -> Service Worker alle Seiten frisch (mit echtem Inhalt)
          // cachen lassen, damit sie offline zuverlässig öffnen. Über die
          // fertige Registrierung, nicht über controller (der kann anfangs
          // noch fehlen).
          if (navigator.serviceWorker) {
            navigator.serviceWorker.ready.then((reg) => {
              const worker = reg.active || navigator.serviceWorker.controller;
              if (worker) worker.postMessage({ type: "precache-pages" });
            }).catch(() => {});
          }
          return { authenticated: true, offline: false, user: d.user };
        }
        return { authenticated: false, offline: false, requires2FA: d.requires2FA };
      } catch {
        const u = this.active();
        return u ? { authenticated: true, offline: true, user: u } : { authenticated: false, offline: true };
      }
    }
  };
  window.GOAuth = GOAuth;

  // Auf Login-/2FA-Seiten kein Kontext-Chip
  const seite = location.pathname.replace(/\/$/, "");
  const aufAuthSeite = seite === "/login" || seite === "/login.html" || seite === "/2fa.html";

  function chipZeichnen(zustand) {
    if (aufAuthSeite) return;
    const user = GOAuth.active();
    let chip = document.getElementById("goUserChip");
    if (!chip) {
      chip = document.createElement("div");
      chip.id = "goUserChip";
      chip.style.cssText = "position:fixed;left:10px;bottom:10px;z-index:9999;display:flex;align-items:center;gap:8px;" +
        "background:#0f172a;color:#fff;border-radius:999px;padding:6px 12px;font:600 12px/1 -apple-system,sans-serif;" +
        "box-shadow:0 4px 14px rgba(0,0,0,.3);cursor:pointer;user-select:none";
      chip.onclick = menuOeffnen;
      document.body.appendChild(chip);
    }
    const offline = zustand ? zustand.offline : !navigator.onLine;
    const punkt = `<span style="width:8px;height:8px;border-radius:50%;background:${offline ? "#f59e0b" : "#22c55e"};display:inline-block"></span>`;
    const badge = ausstehend > 0
      ? `<span style="background:#f59e0b;color:#0f172a;border-radius:999px;padding:1px 7px;font-size:11px;font-weight:800">${ausstehend} ⏳</span>`
      : "";
    chip.innerHTML = `${punkt}<span>${user ? escape(user.username) : "nicht angemeldet"}</span>` +
      `<span style="opacity:.6">${offline ? "offline" : "online"}</span>` +
      badge +
      (GOAuth.known().length > 1 ? `<span style="opacity:.6">▾</span>` : "");
  }

  // Anzahl noch nicht synchronisierter Einträge (aus offline.js)
  let ausstehend = 0;

  function escape(s) { const d = document.createElement("div"); d.textContent = s || ""; return d.innerHTML; }

  function menuOeffnen(e) {
    e && e.stopPropagation();
    document.getElementById("goUserMenu")?.remove();
    const known = GOAuth.known();
    const aktiv = GOAuth.active();
    const menu = document.createElement("div");
    menu.id = "goUserMenu";
    menu.style.cssText = "position:fixed;left:10px;bottom:52px;z-index:10000;background:#fff;color:#0f172a;border-radius:12px;" +
      "box-shadow:0 8px 30px rgba(0,0,0,.25);padding:8px;min-width:200px;font:500 13px/1.3 -apple-system,sans-serif";
    let html = `<div style="font-size:11px;color:#64748b;text-transform:uppercase;padding:4px 8px">Angemeldet als</div>`;
    for (const u of known) {
      const ist = aktiv && u.username === aktiv.username;
      html += `<button data-user="${escape(u.username)}" style="display:flex;align-items:center;gap:8px;width:100%;text-align:left;` +
        `padding:8px;border:0;background:${ist ? "#f1f5f9" : "transparent"};border-radius:8px;cursor:pointer;font:inherit;color:inherit">` +
        `<span style="width:26px;height:26px;border-radius:50%;background:#64748b;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700">${escape(u.username[0].toUpperCase())}</span>` +
        `<span style="flex:1"><span style="font-weight:700">${escape(u.username)}</span><br><span style="font-size:11px;color:#64748b">${escape(u.role || "")}</span></span>` +
        `${ist ? '<span style="color:#475569">✓</span>' : ""}</button>`;
    }
    if (ausstehend > 0) {
      html += `<div style="border-top:1px solid #e2e8f0;margin-top:6px;padding-top:6px">` +
        `<button id="goSyncBtn" style="display:flex;align-items:center;gap:8px;width:100%;text-align:left;padding:8px;border:0;` +
        `background:#fffbeb;border-radius:8px;cursor:pointer;font:inherit;color:#92400e;font-weight:700">` +
        `<span>⏳</span><span>${ausstehend} nicht synchronisiert – jetzt hochladen</span></button></div>`;
    }
    html += `<div style="border-top:1px solid #e2e8f0;margin-top:6px;padding-top:6px">` +
      `<a href="/login" style="display:block;padding:8px;color:#0369a1;text-decoration:none;font-weight:600">Anderer Nutzer (online anmelden)</a></div>`;
    menu.innerHTML = html;
    const syncBtn = menu.querySelector("#goSyncBtn");
    if (syncBtn) syncBtn.onclick = async () => {
      syncBtn.textContent = "Wird hochgeladen...";
      const r = await window.GOffline.sync();
      menu.remove();
      chipZeichnen();
      alert(r.offen === 0 ? `${r.gesendet} Einträge hochgeladen.` : `${r.gesendet} hochgeladen, ${r.offen} noch offen (kein Netz?).`);
    };
    document.body.appendChild(menu);
    menu.querySelectorAll("button[data-user]").forEach((b) => b.onclick = () => {
      GOAuth.setActive(b.dataset.user);
      menu.remove();
      chipZeichnen();
      // Seite neu laden, damit Formulare/Ansicht den neuen Nutzer übernehmen
      location.reload();
    });
    const schliessen = (ev) => { if (!menu.contains(ev.target) && ev.target.id !== "goUserChip") { menu.remove(); document.removeEventListener("click", schliessen); } };
    setTimeout(() => document.addEventListener("click", schliessen), 0);
  }

  // Beim Laden Status prüfen und Chip zeichnen
  window.addEventListener("DOMContentLoaded", async () => {
    const zustand = await GOAuth.refresh();

    // In der Online-App hat bisher der Server nicht angemeldete Aufrufe schon
    // vor dem Ausliefern der Seite auf /login umgeleitet (Auth-Gate in
    // server.js). In der server-losen App gibt es diese Weiche nicht mehr -
    // ohne aktiven Nutzer bleibt die Seite sonst leer (keine Kacheln/Daten,
    // aber auch kein Hinweis warum). Deshalb hier zentral nachholen.
    if (!zustand.authenticated && !aufAuthSeite) {
      const nextUrl = encodeURIComponent(location.pathname + location.search);
      location.replace(`/login.html?next=${nextUrl}`);
      return;
    }

    chipZeichnen(zustand);
    // Falls die Seite ein leeres #userBadge hat (offline), mit dem aktiven
    // Nutzer füllen, damit der Name auch im Kopf sichtbar ist.
    const badge = document.getElementById("userBadge");
    if (badge && !badge.textContent.trim() && GOAuth.active()) {
      badge.textContent = GOAuth.active().username;
    }
  });
  window.addEventListener("online", () => chipZeichnen({ offline: false }));
  window.addEventListener("offline", () => chipZeichnen({ offline: true }));

  // Ausstehend-Zähler aus der Offline-Warteschlange live im Chip spiegeln
  function ausstehendKoppeln() {
    if (!window.GOffline) { setTimeout(ausstehendKoppeln, 300); return; }
    window.GOffline.onChange((n) => { ausstehend = n; chipZeichnen(); });
    window.GOffline.anzahlAusstehend().then((n) => { ausstehend = n; chipZeichnen(); });
  }
  window.addEventListener("DOMContentLoaded", ausstehendKoppeln);
})();
