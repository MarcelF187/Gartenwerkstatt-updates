// Automatischer Import aus dem Geräte-Kalender (Android CalendarContract,
// siehe KalenderLesenPlugin.java) - liest Termine aus allen auf dem Tablet
// synchronisierten Kalendern (Google, Outlook, ...) direkt, ganz ohne
// eigenes Konto/API in dieser App: nur eine einmalige Android-Berechtigung.
//
// Bewusste Grenzen:
//   - Reiner Lesezugriff, keine Rückschreibung in den Geräte-Kalender.
//   - Immer "letzter Stand gewinnt" (kein SEQUENCE-Vergleich wie bei der
//     E-Mail-Einladung) - der Geräte-Kalender kennt sowas nicht, jeder
//     Sync überschreibt Titel/Zeit/Ort/Beschreibung mit dem aktuellen Stand.
//   - Gelöschte Termine im Geräte-Kalender werden hier NICHT automatisch als
//     "abgesagt" markiert (verschwinden einfach aus der Abfrage, ohne
//     erkennbares Signal) - bewusste Einschränkung für den ersten Wurf.
(function () {
  "use strict";

  const AUSGEWAEHLTE_KALENDER_KEY = "go-geraetekalender-ids";

  function plugin() {
    if (!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform())) return null;
    return (window.Capacitor.Plugins && window.Capacitor.Plugins.KalenderLesen) || null;
  }

  function ausgewaehlteIds() {
    try { return JSON.parse(localStorage.getItem(AUSGEWAEHLTE_KALENDER_KEY) || "[]"); } catch { return []; }
  }

  async function pruefeUndFrageBerechtigung(p) {
    const status = await p.checkPermissions();
    if (status.calendar === "granted") return true;
    const angefragt = await p.requestPermissions({ permissions: ["calendar"] });
    return angefragt.calendar === "granted";
  }

  async function kalenderAuswaehlen() {
    const p = plugin();
    if (!p) { alert("Nur in der installierten App verfügbar."); return; }
    const ok = await pruefeUndFrageBerechtigung(p);
    if (!ok) { alert("Ohne Kalender-Berechtigung kann nichts übernommen werden."); return; }

    const { kalender } = await p.listeKalender();
    if (!kalender || !kalender.length) { alert("Keine Kalender auf diesem Gerät gefunden."); return; }

    const bisher = new Set(ausgewaehlteIds());
    const namen = kalender.map((k, i) => `${i + 1}. ${k.name} (${k.konto})${bisher.has(k.id) ? " ✓" : ""}`).join("\n");
    const vorauswahl = kalender.map((k, i) => bisher.has(k.id) ? i + 1 : null).filter(Boolean).join(",");
    const auswahl = prompt(`Welche Kalender sollen übernommen werden? Nummern durch Komma getrennt:\n${namen}`, vorauswahl);
    if (auswahl === null) return;

    const indices = auswahl.split(",").map((s) => parseInt(s.trim(), 10) - 1).filter((i) => i >= 0 && i < kalender.length);
    const ids = indices.map((i) => kalender[i].id);
    localStorage.setItem(AUSGEWAEHLTE_KALENDER_KEY, JSON.stringify(ids));

    const ergebnis = await synchronisieren();
    alert(ids.length
      ? `${ids.length} Kalender ausgewählt. ${ergebnis.anzahl || 0} Termin(e) übernommen.`
      : "Keine Kalender ausgewählt - Übernahme deaktiviert.");
  }

  async function synchronisieren() {
    const p = plugin();
    if (!p) return { status: "nicht_installierte_app" };
    const ids = ausgewaehlteIds();
    if (!ids.length) return { status: "keine_auswahl" };

    const status = await p.checkPermissions();
    if (status.calendar !== "granted") return { status: "keine_berechtigung" };

    let termine = [];
    try {
      const antwort = await p.leseTermine({ kalenderIds: ids });
      termine = antwort.termine || [];
    } catch (err) {
      console.error("Gerätekalender-Sync: Lesen fehlgeschlagen:", err);
      return { status: "fehler" };
    }

    let anzahl = 0;
    for (const t of termine) {
      if (!t.titel || !t.datum) continue;
      try {
        await fetch("/api/termine/aus-einladung", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            titel: t.titel,
            adresse: t.ort || null,
            beschreibung: t.beschreibung || null,
            datum: t.datum,
            von: t.allDay ? null : t.von,
            bis: t.allDay ? null : t.bis,
            icalUid: `geraet-${t.eventId}`,
            icalSequence: 0,
            erzwingeUpdate: true,
            quelle: "geraetekalender"
          })
        });
        anzahl++;
      } catch (err) {
        console.error("Gerätekalender-Sync: Termin konnte nicht übernommen werden:", err);
      }
    }
    return { status: "ok", anzahl };
  }

  window.GOGeraeteKalender = {
    verfuegbar: () => !!plugin(),
    hatAuswahl: () => ausgewaehlteIds().length > 0,
    kalenderAuswaehlen,
    synchronisieren
  };

  // Automatisch beim Laden der Kalenderseite, sobald einmal Kalender
  // ausgewählt wurden - kein manueller Knopf nötig für die laufende Nutzung.
  // Auch die Sichtbarkeit des Knopfs selbst wird hier gesetzt (nicht im
  // Inline-Skript der Seite): das läuft synchron beim Parsen und damit VOR
  // diesem "defer"-Skript, window.GOGeraeteKalender wäre dort noch nicht da.
  window.addEventListener("load", () => {
    const btn = document.getElementById("btnGeraeteKalender");
    if (btn && plugin()) btn.style.display = "inline-block";
    if (ausgewaehlteIds().length) {
      synchronisieren()
        .then((r) => { if (r.anzahl && typeof ladeAlles === "function") ladeAlles(); })
        .catch(() => {});
    }
  });
})();
