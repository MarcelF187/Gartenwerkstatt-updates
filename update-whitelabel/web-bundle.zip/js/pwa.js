// Macht das Tool installierbar (PWA). Wird auf jeder Seite eingebunden und
// ergänzt zentral: Manifest-Verweis, Icons/Meta-Angaben für iOS und Android
// sowie die Registrierung des Service Workers. So muss nichts pro Seite doppelt
// gepflegt werden.
(function () {
  const kopf = document.head;

  function meta(attr, name, content) {
    if (document.querySelector(`meta[${attr}="${name}"]`)) return;
    const m = document.createElement("meta");
    m.setAttribute(attr, name);
    m.setAttribute("content", content);
    kopf.appendChild(m);
  }
  function link(rel, href, extra) {
    const l = document.createElement("link");
    l.rel = rel; l.href = href;
    if (extra) Object.entries(extra).forEach(([k, v]) => l.setAttribute(k, v));
    kopf.appendChild(l);
  }

  if (!document.querySelector('link[rel="manifest"]')) link("manifest", "/manifest.webmanifest");

  // Farbe der Statusleiste / Titelzeile im installierten Zustand
  meta("name", "theme-color", "#64748b");

  // iOS: erlaubt den Vollbild-App-Modus und setzt das Homescreen-Icon
  meta("name", "apple-mobile-web-app-capable", "yes");
  meta("name", "apple-mobile-web-app-status-bar-style", "black-translucent");
  meta("name", "apple-mobile-web-app-title", "Ihre Firma");
  meta("name", "mobile-web-app-capable", "yes");
  link("apple-touch-icon", "/logos/icon-192.png");

  // Service Worker registrieren (nur in sicherem Kontext: https oder localhost)
  if ("serviceWorker" in navigator && window.isSecureContext) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("/service-worker.js").catch((err) =>
        console.warn("Service Worker konnte nicht registriert werden:", err.message)
      );
    });
  }
})();
