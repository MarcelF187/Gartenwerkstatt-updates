// WLAN-Peer-Sync zwischen Tablets ohne Server (Hauptgerät/Nebengerät).
//
// Genau ein Tablet wird über public/account.html als "Hauptgerät" markiert
// (localStorage, gerätelokal - keine synchronisierte Einstellung). Alle
// anderen Geräte ("Nebengeräte") gleichen sich per Knopfdruck darüber ab
// (syncMitHauptgeraet weiter unten). Phase 1 deckte Pflege-/Wässerliste,
// Tagesbericht, Heckenschnitt, Termine, Notizen (+ kunden als schlanke
// Abhängigkeit von notizen.kunde_id) ab. Phase 2 (siehe SYNC_STORES) ergänzt
// Bau-Bereich (Bautagesbericht, LV-Bau inkl. Projekte), Stammdaten,
// Nutzerverwaltung und Pflege-Projekte.
//
// Transport: ein eigenes natives Plugin (LanSyncPlugin.java, siehe
// android/app/.../LanSyncPlugin.java) übernimmt Geräte-Erkennung im WLAN
// (NsdManager) und - nur auf dem Hauptgerät - einen selbstgebauten
// Mini-HTTP-Server. Die eigentliche Sync-Anfrage eines Nebengeräts ist ein
// ganz normaler fetch() an die gefundene Peer-IP: local-api.js patcht nur
// relative "/api/..."-Pfade (siehe dortiger Kommentar am fetch-Patch), eine
// absolute URL wie "http://192.168.1.42:47110/sync" läuft daran ungehindert
// vorbei ins echte Netz.
//
// Konfliktregel (siehe Plan .../ticklish-inventing-conway.md): bei einem
// echten Konflikt (Zeile mit bekannter client_uuid existiert auf dem
// Hauptgerät bereits anders) gewinnt IMMER die Version des Hauptgeräts - ein
// Nebengerät kann eine dort schon bekannte Zeile nicht überschreiben, nur
// wirklich neue Zeilen werden übernommen. Das verhindert stillen
// Datenverlust durch unterschiedlich eingestellte Geräte-Uhrzeiten (kein
// simples "neuester Zeitstempel gewinnt").
(function () {
  "use strict";

  const LS_HAUPTGERAET = "go-lan-sync-hauptgeraet";
  const LS_GERAETNAME = "go-lan-sync-geraetname";
  const SERVICE_TYPE_HINWEIS = "_gruoase-sync._tcp.";

  // Reihenfolge ist wichtig: Elternzeilen (z.B. kunden, baumlisten, projekte)
  // müssen vor ihren Kindern (notizen, baumlisten_items, lv_bau_listen)
  // verarbeitet werden, damit eine gerade erst angelegte Elternzeile für ihr
  // Kind in derselben Anfrage schon per client_uuid auflösbar ist. users und
  // stammdaten haben keine Abhängigkeiten, stehen aber trotzdem vorne, weil
  // sie (siehe DEDUPE_SCHLUESSEL unten) mit bereits vorhandenem Altbestand
  // abgeglichen werden und das unabhängig von jeder anderen Zeile ist.
  // notiz_bilder/heckenschnitt_bilder stehen bewusst direkt HINTER ihrer
  // Elternzeile (notizen/heckenschnitt) - siehe FK_FELDER. Es wandern hier
  // nur Foto-METADATEN (client_uuid/typ/deleted_at usw.), nicht der Bild-
  // Inhalt selbst (siehe baueAusgehendeZeile weiter unten, das "blob" gezielt
  // ausklammert) - der läuft über einen eigenen Übertragungsschritt je Foto,
  // siehe ladeNeueFotosHoch/ladeFehlendeFotosHerunter weiter unten.
  const SYNC_STORES = [
    "rollen", "users", "urlaub", "stammdaten", "kunden",
    "projekte", "baumlisten", "baumlisten_items",
    "tagesberichte", "heckenschnitt", "heckenschnitt_bilder", "termine", "notizen", "notiz_bilder",
    "bautagesberichte",
    "lv_bau_projekte", "lv_bau_listen", "lv_bau_items",
    "bauplaene", "bauplan_ebenen",
    "material_katalog", "materiallisten", "material_eintraege"
  ];

  // Stores, deren "blob"-Feld (rohe Bilddaten) NIE Teil des normalen
  // JSON-Sync-Payloads werden darf - zu groß für einen einzelnen Request,
  // siehe Kommentar oben und baueAusgehendeZeile/wendeAenderungenAn.
  const BILDER_STORES = ["notiz_bilder", "heckenschnitt_bilder", "bauplaene"];

  // <lokales FK-Feld> -> <Store, auf den es zeigt>. Auf der Leitung wird jedes
  // dieser Felder nie als rohe Zahl übertragen (unabhängige
  // Auto-Increment-Sequenzen je Gerät), sondern als "<feld ohne _id>_client_uuid".
  const FK_FELDER = {
    baumlisten: { projekt_id: "projekte" },
    baumlisten_items: { liste_id: "baumlisten" },
    notizen: { kunde_id: "kunden", liste_id: "baumlisten", item_id: "baumlisten_items" },
    notiz_bilder: { notiz_id: "notizen" },
    heckenschnitt_bilder: { eintrag_id: "heckenschnitt" },
    lv_bau_listen: { projekt_id: "lv_bau_projekte" },
    lv_bau_items: { liste_id: "lv_bau_listen" },
    urlaub: { mitarbeiter_id: "users", erstellt_von: "users" },
    bauplaene: { projekt_id: "lv_bau_projekte", erstellt_von: "users" },
    bauplan_ebenen: { bauplan_id: "bauplaene", erstellt_von: "users" },
    materiallisten: { projekt_id: "lv_bau_projekte", erstellt_von: "users" },
    material_eintraege: { liste_id: "materiallisten" },
    // Selbstreferenzierend: ein per Serien-Generierung (kalender.html)
    // erzeugter Folgetermin zeigt auf seine "Wurzel" (den ursprünglichen
    // wiederkehrenden Termin) - ohne Übersetzung würde die rohe, geräte-
    // eigene id des Senders ankommen und auf dem Empfänger ins Leere (oder
    // auf einen völlig falschen Termin) zeigen.
    //
    // liste_id/item_id (Bezug zur Pflegeliste, siehe terminAusFaelligkeit()
    // in kalender.html) fehlten hier ursprünglich - genau wie bei serie_id
    // sind das geräte-lokale Auto-Increment-Werte, die ohne Übersetzung nach
    // einem Sync auf ein völlig falsches (oder gar kein) Item des
    // Empfängergeräts zeigten. Sichtbare Folge: GET /api/termine/faellig
    // erkennt anhand von item_id, ob für eine fällige Position bereits ein
    // Termin existiert (bestehendeSet, siehe dort) - mit einer verfälschten
    // item_id griff diese Sperre auf dem Empfängergerät nie, die längst
    // vertermine Position erschien dort weiter (bzw. erneut) als fällig, ein
    // erneuter Klick auf "Termin anlegen" erzeugte einen waschechten
    // zweiten/dritten Termin für dieselbe Position - genau das vom Nutzer
    // gemeldete Symptom nach einem WLAN-Sync. Gleiches Muster wie bereits bei
    // notizen.item_id/liste_id oben.
    termine: { serie_id: "termine", liste_id: "baumlisten", item_id: "baumlisten_items" }
  };

  // Manche Stores hatten schon VOR Phase 2 unabhängig voneinander gepflegte
  // Zeilen auf jedem Gerät (users: Mitarbeiter wurden bisher pro Tablet
  // einzeln angelegt; stammdaten: der Seed-Katalog wird von JEDEM Gerät beim
  // allerersten Start identisch importiert, siehe LocalDB.ensureSeeded). Die
  // lokale DB_VERSION-Migration (siehe local-db.js) läuft dabei IMMER vor
  // jedem Sync (sie passiert schon beim ganz normalen Öffnen der Datenbank),
  // rüstet jeder bereits vorhandenen Zeile aber eine PRO GERÄT zufällige
  // client_uuid nach - ein und derselbe Mitarbeiter/Stammdatensatz hat auf
  // zwei Geräten also von Anfang an zwei unterschiedliche client_uuids, nie
  // "keine". Ein Dedupe rein über "Zeilen ohne client_uuid" würde deshalb nie
  // greifen. Stattdessen zusätzlich zur client_uuid ein inhaltlicher
  // Schlüssel: findet sich keine Zeile mit passender client_uuid, wird unter
  // ALLEN lokalen Zeilen nach inhaltlicher Übereinstimmung gesucht (unabhängig
  // von deren eigener client_uuid). Bei einem Treffer läuft die bestehende
  // "gefunden"-Behandlung unverändert weiter: Hauptgerät behält bei einer
  // eingehenden Anfrage seine eigene Version (Konfliktregel), ein Nebengerät
  // übernimmt bei der Antwort des Hauptgeräts dessen Version inkl. dessen
  // client_uuid in die eigene, bestehende Zeile - ab dem nächsten Sync
  // greift dann für dieselbe Zeile bereits der schnelle client_uuid-Treffer.
  // Zwei nach Phase 2 unabhängig auf zwei Geräten neu angelegte Zeilen mit
  // zufällig gleichem Inhalt werden dadurch bewusst genauso zusammengeführt -
  // bei users wäre ein doppelter Benutzername ohnehin schon für den Login
  // (Suche per .find(), siehe /api/auth/login) nicht sauber unterscheidbar,
  // das Zusammenführen ist hier also die korrekte Auflösung, kein Kompromiss.
  // termine: die rollierende Serien-Generierung (kalender.html,
  // pruefeSerienGenerierung) legt fällige Folgetermine einer wiederkehrenden
  // Serie an - der "heute schon erledigt"-Merker dafür ist rein pro Gerät
  // (localStorage), nicht Teil des Syncs. Zwei Geräte, die beide vor einem
  // Abgleich online waren, erzeugen für dieselbe fällige Serie deshalb leicht
  // je einen eigenen Folgetermin mit je eigener, zufälliger client_uuid - der
  // schnelle client_uuid-Treffer allein würde diese nie zusammenführen. Hier
  // greift derselbe Dedupe-Mechanismus wie bei users/stammdaten: fehlt ein
  // client_uuid-Treffer, wird zusätzlich nach identischem (serie_id, datum)
  // gesucht. Genau dasselbe Problem gibt es fuer per "Termin anlegen" aus
  // einem fälligen Pflegegang erzeugte Termine (quelle='pflege_vorschlag',
  // siehe terminAusFaelligkeit() in kalender.html): klickt jemand auf zwei
  // Geräten unabhängig voneinander (vor einem Sync) auf denselben fälligen
  // Vorschlag, entstehen zwei Termine mit unterschiedlicher client_uuid, aber
  // demselben item_id+datum - ohne diesen Fallback blieben nach dem Sync
  // beide bestehen (echte Dopplung im Kalender). item_id ist an dieser Stelle
  // bereits die lokal aufgelöste id (siehe FK_FELDER.termine oben, laeuft VOR
  // diesem Schluessel). Alle übrigen (wirklich eigenständigen, manuell
  // angelegten) Termine bekommen weiterhin ihre eigene client_uuid als
  // Schlüssel zurück - die ist praktisch nie mit einer anderen Zeile
  // identisch, das deaktiviert den Inhalts-Dedupe für sie faktisch (zwei
  // zufällig gleich betitelte Einzeltermine sollen NICHT zusammengeführt
  // werden).
  // projekte/baumlisten: fehlten hier ursprünglich - mit gravierender Folge.
  // Importieren zwei Geräte dieselbe Pflegeliste unabhängig voneinander (oder
  // legen dasselbe Projekt an), bekommen beide Zeilen je eine eigene, zufällige
  // client_uuid. Ohne Inhalts-Schlüssel fand der Sync keinen Treffer und legte
  // die fremde Liste als ZWEITE Liste an. Schlimmer noch: der Schlüssel für
  // baumlisten_items unten enthält liste_id - zeigen die Positionen beider
  // Geräte auf zwei verschiedene Listen-Kopien, kann er per Definition nie
  // greifen, und JEDE Position wurde bei jedem Abgleich erneut angelegt (2x,
  // 3x, ... - genau das vom Nutzer gemeldete Bild). Erst wenn die Listen
  // konvergieren, kann auch der Positions-Abgleich funktionieren.
  // projekt_id ist hier bereits die lokal aufgelöste id (siehe
  // loeseFksEingehendAuf, läuft VOR diesem Schlüssel) - zwei gleichnamige
  // Listen in UNTERSCHIEDLICHEN Projekten bleiben dadurch bewusst getrennt.
  const DEDUPE_SCHLUESSEL = {
    users: (r) => String(r.username || "").trim().toLowerCase(),
    stammdaten: (r) => [r.typ, r.bereich, String(r.bezeichnung || "").trim().toLowerCase()].join("|"),
    projekte: (r) => String(r.name || "").trim().toLowerCase(),
    baumlisten: (r) => `${r.projekt_id == null ? "" : r.projekt_id}|${String(r.name || "").trim().toLowerCase()}`,
    termine: (r) => {
      if (r.serie_id) return `serie:${r.serie_id}:${r.datum}`;
      if (r.item_id && r.quelle === "pflege_vorschlag") return `vorschlag:${r.item_id}:${r.datum}`;
      return `eigenstaendig:${r.client_uuid}`;
    },
    // baumlisten_items: verhindert die Neu-Dopplung derselben Pflegeliste bei
    // einem ersten Sync zwischen zwei Geräten, die unabhängig voneinander per
    // CSV/Excel importiert wurde (siehe bereinigePflegelistenDuplikate oben,
    // die dieselbe Dopplung im Nachhinein für bereits so entstandene
    // Duplikate aufräumt). dedupeSchluessel() läuft in wendeAenderungenAn()
    // erst NACH loeseFksEingehendAuf() - liste_id ist an dieser Stelle also
    // bereits auf die lokale id aufgelöst, genau wie bei jeder bestehenden
    // lokalen Zeile, mit der hier verglichen wird.
    baumlisten_items: (r) => `${r.liste_id}|${String(r.auftragsnummer || "").trim().toLowerCase()}`,
    // Materialverbrauch: gleiche Schutzlogik wie bei projekte/baumlisten oben -
    // der Katalog wird auf JEDEM Geraet identisch geseedet (siehe
    // KG_KATALOG_SEED in local-db.js), hat dort also je eigene client_uuids.
    // Ohne Namens-Abgleich wuerde jeder Sync den kompletten KG-Katalog ein
    // zweites Mal anlegen. Listen ebenso ueber Projekt + Name.
    material_katalog: (r) => String(r.name || "").trim().toLowerCase(),
    materiallisten: (r) => `${r.projekt_id == null ? "" : r.projekt_id}|${String(r.name || "").trim().toLowerCase()}`
  };

  // Stores, deren "id" (siehe local-db.js) selbst schon der stabile,
  // geräteübergreifend gültige Schlüssel ist (kein pro-Gerät unabhängiges
  // Auto-Increment) - aktuell nur "rollen" (ein einmalig vergebener Slug,
  // wird direkt als users.role gespeichert). Anders als bei jedem anderen
  // Store darf "id" hier NICHT aus dem Wire-Format entfernt werden (siehe
  // baueAusgehendeZeile/loeseFksEingehendAuf) und der Merge erfolgt direkt
  // über "id" statt über eine client_uuid-Index-Suche (siehe
  // wendeAenderungenAn) - der Store hat kein Auto-Increment, ein add() ohne
  // "id" würde sonst hart fehlschlagen.
  const ID_IST_SYNC_SCHLUESSEL = ["rollen"];

  // Anzeige-Namen für die Eingangs-Benachrichtigung auf dem Hauptgerät (siehe
  // benachrichtigeUeberEingehendeAenderungen unten) - [Einzahl, Mehrzahl].
  // baumlisten_items/lv_bau_items sind absichtlich NICHT dabei: die stecken
  // implizit schon in "neue Pflegeliste"/"neue LV-Bau-Liste", eine zusätzliche
  // rohe Positionszahl wäre für eine KURZE Auflistung eher Rauschen als Nutzen.
  const STORE_LABEL = {
    tagesberichte: ["Tagesbericht", "Tagesberichte"],
    bautagesberichte: ["Bautagesbericht", "Bautagesberichte"],
    heckenschnitt: ["Heckenschnitt-Eintrag", "Heckenschnitt-Einträge"],
    termine: ["Termin", "Termine"],
    notizen: ["Notiz", "Notizen"],
    baumlisten: ["Pflegeliste", "Pflegelisten"],
    lv_bau_listen: ["LV-Bau-Liste", "LV-Bau-Listen"],
    projekte: ["Pflege-Projekt", "Pflege-Projekte"],
    lv_bau_projekte: ["LV-Bau-Projekt", "LV-Bau-Projekte"],
    users: ["Mitarbeiter", "Mitarbeiter"],
    rollen: ["Rolle", "Rollen"],
    urlaub: ["Urlaubseintrag", "Urlaubseinträge"],
    stammdaten: ["Stammdatum", "Stammdaten"],
    kunden: ["Kunde", "Kunden"],
    notiz_bilder: ["Foto (Notiz)", "Fotos (Notizen)"],
    heckenschnitt_bilder: ["Foto (Heckenschnitt)", "Fotos (Heckenschnitt)"],
    materiallisten: ["Materialliste", "Materiallisten"],
    material_katalog: ["Material-Katalogeintrag", "Material-Katalogeintraege"]
  };
  // Anzeigereihenfolge nach Alltagsrelevanz - bewusst NICHT identisch mit der
  // Abhängigkeitsreihenfolge in SYNC_STORES (die ist für den Merge-Ablauf
  // wichtig, nicht dafür, was für den Nutzer zuerst interessant ist).
  // baumlisten_items/lv_bau_items bewusst nicht dabei (siehe Kommentar bei
  // STORE_LABEL oben) - die Fotos stehen trotzdem mit drin: anders als eine
  // rohe Positionszahl ist "3 neue Fotos" für sich genommen aussagekräftig.
  const STORE_ANZEIGE_REIHENFOLGE = [
    "tagesberichte", "bautagesberichte", "heckenschnitt", "termine", "notizen",
    "baumlisten", "lv_bau_listen", "projekte", "lv_bau_projekte", "users", "rollen", "urlaub", "stammdaten", "kunden",
    "notiz_bilder", "heckenschnitt_bilder", "materiallisten", "material_katalog"
  ];

  function wireFeldname(feld) {
    return feld.replace(/_id$/, "_client_uuid");
  }

  // notizen hatte "aktualisiert_am" schon vor dem Sync (siehe local-api.js) -
  // das wird hier 1:1 als dessen "updated_at" behandelt statt ein zweites,
  // separates Feld einzuführen, das sonst auseinanderlaufen könnte.
  function zeitstempelVon(store, row) {
    return store === "notizen" ? row.aktualisiert_am : row.updated_at;
  }

  function plugin() {
    if (!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform())) return null;
    return (window.Capacitor.Plugins && window.Capacitor.Plugins.LanSync) || null;
  }

  function geraeteName() {
    return (localStorage.getItem(LS_GERAETNAME) || "").trim() || "Tablet";
  }
  function istHauptgeraet() {
    return localStorage.getItem(LS_HAUPTGERAET) === "1";
  }

  let berechtigungOk = null;
  async function sicherstellenBerechtigung(LanSync) {
    if (berechtigungOk !== null) return berechtigungOk;
    try {
      const status = await LanSync.checkPermissions();
      if (status.wifi === "granted") { berechtigungOk = true; return true; }
      const angefragt = await LanSync.requestPermissions();
      berechtigungOk = angefragt.wifi === "granted";
    } catch (err) {
      // Methode/Berechtigung auf diesem Geräte-/Plugin-Stand nicht bekannt -
      // nichts erzwingen, NsdManager funktioniert auf älteren Android-
      // Versionen ohnehin ohne diese Berechtigung.
      berechtigungOk = true;
    }
    return berechtigungOk;
  }

  const BANNER_DISMISS_KEY = "go-lan-sync-berechtigung-hinweis-am";
  function zeigeBerechtigungsHinweis() {
    if (document.getElementById("goLanSyncHinweis")) return;
    const heute = new Date().toISOString().slice(0, 10);
    if (localStorage.getItem(BANNER_DISMISS_KEY) === heute) return;
    const banner = document.createElement("div");
    banner.id = "goLanSyncHinweis";
    banner.className = "fixed left-0 right-0 bottom-0 z-[998] bg-amber-50 border-t border-amber-200 text-amber-800 text-sm px-4 py-3 flex items-center justify-between gap-3 flex-wrap";
    banner.innerHTML = `
      <span><i class="fa-solid fa-triangle-exclamation mr-2"></i>Für den Geräte-Abgleich bitte die WLAN-Geräte-Berechtigung für diese App erlauben.</span>
      <span class="flex gap-2">
        <button id="goLanSyncSchliessen" class="px-3 py-1.5 rounded-lg bg-white border border-amber-300 text-xs font-bold hover:bg-amber-100">Später</button>
      </span>`;
    document.body.appendChild(banner);
    document.getElementById("goLanSyncSchliessen").addEventListener("click", () => {
      localStorage.setItem(BANNER_DISMISS_KEY, heute);
      banner.remove();
    });
  }

  // ------------------------------------------------------- FK-Übersetzung
  async function findeLokalDurchClientUuid(store, uuid) {
    if (!uuid) return null;
    const treffer = await window.LocalDB.getAllByIndex(store, "client_uuid", uuid);
    return treffer && treffer.length ? treffer[0] : null;
  }

  // Eingehende Zeile (Wire-Format mit "<feld>_client_uuid"-Strings) in ein
  // lokal speicherbares Objekt übersetzen - fehlt die Elternzeile lokal noch
  // (sollte durch die feste SYNC_STORES-Reihenfolge nicht vorkommen), bleibt
  // das Feld sicherheitshalber null statt eines harten Fehlers.
  async function loeseFksEingehendAuf(store, eingehend) {
    const zeile = { ...eingehend };
    if (!ID_IST_SYNC_SCHLUESSEL.includes(store)) delete zeile.id;
    const felder = FK_FELDER[store];
    if (felder) {
      for (const [feld, elternStore] of Object.entries(felder)) {
        const wireFeld = wireFeldname(feld);
        const uuid = zeile[wireFeld];
        delete zeile[wireFeld];
        const eltern = uuid ? await findeLokalDurchClientUuid(elternStore, uuid) : null;
        zeile[feld] = eltern ? eltern.id : null;
      }
    }
    return zeile;
  }

  // Lokale Zeile (rohe Integer-FKs) fürs Senden ins Wire-Format übersetzen.
  async function baueAusgehendeZeile(store, row) {
    const zeile = { ...row };
    if (!ID_IST_SYNC_SCHLUESSEL.includes(store)) delete zeile.id;
    // "blob" gehört NIE ins JSON (siehe BILDER_STORES oben) - ein Blob lässt
    // sich ohnehin nicht sinnvoll per JSON.stringify übertragen, der Inhalt
    // läuft separat über ladeNeueFotosHoch/fotoEmpfangen.
    if (BILDER_STORES.includes(store)) delete zeile.blob;
    const felder = FK_FELDER[store];
    if (felder) {
      for (const [feld, elternStore] of Object.entries(felder)) {
        const elternId = row[feld];
        delete zeile[feld];
        const eltern = elternId != null ? await window.LocalDB.get(elternStore, elternId) : null;
        zeile[wireFeldname(feld)] = eltern ? eltern.client_uuid : null;
      }
    }
    return zeile;
  }

  async function baueAusgehendeAenderungen(seit) {
    const changes = {};
    for (const store of SYNC_STORES) {
      const alle = await window.LocalDB.getAll(store);
      // Bewusst KEIN Filter auf deleted_at: eine gelöschte Zeile (Tombstone)
      // muss genau wie jede andere Änderung mit übertragen werden, sonst
      // taucht sie auf dem anderen Gerät beim nächsten Abgleich wieder auf.
      const geaendert = alle.filter((r) => !seit || zeitstempelVon(store, r) > seit);
      if (geaendert.length) changes[store] = await Promise.all(geaendert.map((r) => baueAusgehendeZeile(store, r)));
    }
    return changes;
  }

  // Wendet empfangene Änderungen auf die lokale IndexedDB an.
  //   ueberschreiben=false (Hauptgerät verarbeitet eine eingehende Anfrage):
  //     eine bereits bekannte client_uuid bleibt unangetastet ("Hauptgerät
  //     gewinnt") - nur wirklich neue Zeilen werden übernommen.
  //   ueberschreiben=true (Nebengerät übernimmt die Antwort des Hauptgeräts):
  //     die Antwort IST bereits die aufgelöste, autoritative Version -
  //     jede Zeile wird 1:1 übernommen (neu angelegt oder überschrieben).
  async function wendeAenderungenAn(changes, { ueberschreiben }) {
    // neuProStore: nur für die Eingangs-Benachrichtigung auf dem Hauptgerät
    // (siehe benachrichtigeUeberEingehendeAenderungen) - zählt ausschließlich
    // wirklich neu angelegte Zeilen je Store, nicht aktualisierte/übersprungene.
    const zaehler = { neu: 0, aktualisiert: 0, uebersprungen: 0, neuProStore: {} };
    for (const store of SYNC_STORES) {
      const rows = Array.isArray(changes && changes[store]) ? changes[store] : [];
      if (!rows.length) continue;
      const dedupeSchluessel = DEDUPE_SCHLUESSEL[store];
      // Lazy geladen und je Store nur einmal - erst wenn wirklich eine Zeile
      // ohne client_uuid-Treffer eine Dedupe-Prüfung braucht. Bewusst ALLE
      // lokalen Zeilen (nicht nur welche ohne eigene client_uuid) - siehe
      // Kommentar bei DEDUPE_SCHLUESSEL oben.
      let lokaleZeilen = null;
      for (const eingehend of rows) {
        let bestehend = ID_IST_SYNC_SCHLUESSEL.includes(store)
          ? await window.LocalDB.get(store, eingehend.id)
          : await findeLokalDurchClientUuid(store, eingehend.client_uuid);
        // FK-Auflösung bewusst VOR dem Inhalts-Dedupe (nicht erst danach wie
        // früher): dedupeSchluessel(termine) vergleicht serie_id - die steht
        // im Wire-Format nur als serie_id_client_uuid, in einer lokalen
        // Zeile nur als aufgelöste lokale id. Beide Seiten müssen dieselbe,
        // bereits aufgelöste Form haben, sonst vergleicht der Dedupe zwei
        // unterschiedliche Zahlenräume (Sender- vs. Empfänger-Autoincrement)
        // miteinander.
        const zeile = await loeseFksEingehendAuf(store, eingehend);
        if (!bestehend && dedupeSchluessel) {
          if (!lokaleZeilen) lokaleZeilen = await window.LocalDB.getAll(store);
          bestehend = lokaleZeilen.find((r) => dedupeSchluessel(r) === dedupeSchluessel(zeile)) || null;
        }
        if (bestehend && !ueberschreiben) { zaehler.uebersprungen++; continue; }
        if (bestehend) {
          await window.LocalDB.put(store, { ...zeile, id: bestehend.id });
          zaehler.aktualisiert++;
        } else {
          await window.LocalDB.add(store, zeile);
          zaehler.neu++;
          zaehler.neuProStore[store] = (zaehler.neuProStore[store] || 0) + 1;
        }
      }
    }
    return zaehler;
  }

  // ---------------------------------------------- Serien-Duplikate aufräumen
  // Vor dem obigen Dedupe-Schlüssel für termine konnten zwei Geräte für
  // dieselbe fällige Serie unabhängig je einen eigenen Folgetermin anlegen
  // (siehe Kommentar bei DEDUPE_SCHLUESSEL) - bereits so entstandene
  // Duplikate verschwinden dadurch nicht von selbst, der neue Dedupe greift
  // nur für zukünftig NEU ankommende Zeilen. Läuft deshalb nach jedem Sync
  // (beide Rollen) einmal über die eigene termine-Tabelle: findet Gruppen mit
  // identischem (serie_id, datum), behält die zuerst angelegte Zeile (kleinste
  // lokale id) und löscht den Rest als Tombstone - der Tombstone räumt die
  // jeweiligen Duplikate dann auch auf den anderen Geräten beim nächsten
  // Abgleich mit auf, ganz ohne manuelles Eingreifen.
  // Gibt die Anzahl der entfernten Duplikate zurück - genutzt vom manuellen
  // "Termine neu scannen"-Knopf in kalender.html (siehe unten in
  // window.GoLanSync), damit Duplikate nicht nur nach einem WLAN-Sync
  // verschwinden, sondern sich auch auf einem Gerät bereinigen lassen, das
  // (noch) nie synchronisiert hat - der Aufruf hier ist unabhängig vom
  // Sync-Ablauf und braucht kein Hauptgerät/Nebengerät.
  async function bereinigeSerienDuplikate() {
    const alle = await window.LocalDB.getAll("termine");
    const gruppen = new Map();
    for (const t of alle) {
      if (t.deleted_at || !t.serie_id) continue;
      const schluessel = t.serie_id + "|" + t.datum;
      if (!gruppen.has(schluessel)) gruppen.set(schluessel, []);
      gruppen.get(schluessel).push(t);
    }
    let entfernt = 0;
    for (const gruppe of gruppen.values()) {
      if (gruppe.length < 2) continue;
      gruppe.sort((a, b) => a.id - b.id);
      for (const duplikat of gruppe.slice(1)) {
        duplikat.deleted_at = new Date().toISOString();
        duplikat.updated_at = duplikat.deleted_at;
        await window.LocalDB.put("termine", duplikat);
        entfernt++;
      }
    }
    return entfernt;
  }

  // ------------------------------------------ Pflegelisten-Duplikate aufräumen
  // baumlisten_items hatte bislang KEINEN Eintrag in DEDUPE_SCHLUESSEL (siehe
  // oben) - zwei Geräte, die dieselbe Pflegeliste unabhängig voneinander (z.B.
  // je per eigenem CSV/Excel-Import) angelegt haben, BEVOR sie je miteinander
  // WLAN-synchronisiert wurden, erzeugen dabei je eigene client_uuids für
  // inhaltlich identische Positionen - beim ersten Sync findet der schnelle
  // client_uuid-Treffer nichts und (mangels Dedupe-Schlüssel) griff bislang
  // auch kein inhaltlicher Fallback, die Zeile wurde als "neu" übernommen und
  // dauerhaft dupliziert. Analog zu bereinigeSerienDuplikate() oben räumt
  // diese Funktion bereits so entstandene Duplikate im Nachhinein auf und
  // funktioniert unabhängig vom Sync-Ablauf (auch ganz ohne WLAN-Sync nutzbar).
  // Anders als bei termine (dort ist ein exaktes Duplikat komplett wertlos)
  // können zwei Pflegelisten-Duplikate aber unterschiedlich weit ausgefüllten
  // Pflege-Fortschritt (pflegegaenge) tragen, je nachdem auf welchem Gerät
  // zuletzt ein Pflegegang abgehakt wurde - deshalb wird hier nicht einfach
  // die "jüngere" Zeile verworfen, sondern der Fortschritt aller Duplikate
  // POSITIONSWEISE zusammengeführt, bevor die überzähligen Zeilen als
  // Tombstone gelöscht werden.
  //
  // Gruppiert wird über auftragsnummer + liegenschaft + beschreibung, BEWUSST
  // OHNE liste_id (anders als der automatische DEDUPE_SCHLUESSEL oben, der
  // beim Sync aus Sicherheitsgründen liste_id-scoped bleibt): in der Praxis
  // entstand die beobachtete Dopplung nicht nur durch doppelte Positionen
  // INNERHALB einer Liste, sondern auch durch zwei unabhängig voneinander
  // importierte, inhaltlich identische Listen-Zeilen mit unterschiedlicher
  // liste_id (z.B. wenn dieselbe Pflegeliste auf zwei Geräten je einmal neu
  // importiert wurde, statt in eine bereits geteilte Liste). Ein
  // liste_id-scoped Abgleich würde diesen Fall nicht finden. Das Zusammenspiel
  // aller drei Felder (nicht nur die Nummer) macht ein zufälliges
  // Fehl-Zusammenführen zweier tatsächlich unabhängiger Positionen praktisch
  // ausgeschlossen - das ist hier vertretbar, weil die Bereinigung eine
  // bewusste, manuell ausgelöste Aktion ist (Knopf in baumliste.html), keine
  // automatische Hintergrund-Operation.
  // Vorstufe: doppelte LISTEN zusammenführen. Solange zwei Kopien derselben
  // Pflegeliste nebeneinander stehen, hängen ihre Positionen an
  // unterschiedlichen liste_ids - der Positions-Abgleich unten würde zwar
  // greifen (sein Schlüssel ist listenübergreifend), die überlebende Position
  // bliebe aber an einer beliebigen der beiden Listen hängen und die zweite
  // Liste als leere Karteileiche zurück. Deshalb hier zuerst: gleichnamige
  // Listen (im selben Projekt) auf die inhaltsreichste zusammenziehen, alle
  // Positionen der Duplikate darauf umhängen, die leeren Kopien als Tombstone
  // löschen. Gibt die Anzahl entfernter Listen zurück.
  async function fuehreDoppelteListenZusammen() {
    const listen = (await window.LocalDB.getAll("baumlisten")).filter((l) => !l.deleted_at);
    const items = (await window.LocalDB.getAll("baumlisten_items")).filter((i) => !i.deleted_at);
    const gruppen = new Map();
    for (const liste of listen) {
      const name = String(liste.name || "").trim().toLowerCase();
      if (!name) continue;
      const schluessel = `${liste.projekt_id == null ? "" : liste.projekt_id}|${name}`;
      if (!gruppen.has(schluessel)) gruppen.set(schluessel, []);
      gruppen.get(schluessel).push(liste);
    }
    let entfernt = 0;
    for (const gruppe of gruppen.values()) {
      if (gruppe.length < 2) continue;
      const anzahlItems = (l) => items.filter((i) => i.liste_id === l.id).length;
      gruppe.sort((a, b) => anzahlItems(b) - anzahlItems(a) || a.id - b.id);
      const [survivor, ...duplikate] = gruppe;
      for (const duplikat of duplikate) {
        for (const item of items.filter((i) => i.liste_id === duplikat.id)) {
          item.liste_id = survivor.id;
          item.updated_at = new Date().toISOString();
          await window.LocalDB.put("baumlisten_items", item);
        }
        duplikat.deleted_at = new Date().toISOString();
        duplikat.updated_at = duplikat.deleted_at;
        await window.LocalDB.put("baumlisten", duplikat);
        entfernt++;
      }
    }
    return entfernt;
  }

  function pflegegangIstAusgefuellt(eintrag) {
    return !!eintrag && typeof eintrag === "object" && (eintrag.na || String(eintrag.datum || "") !== "");
  }
  function zaehleAusgefuelltePflegegaenge(item) {
    return (Array.isArray(item.pflegegaenge) ? item.pflegegaenge : []).filter(pflegegangIstAusgefuellt).length;
  }
  // Gibt { listen, positionen } zurück (Anzahl entfernter Listen-Kopien bzw.
  // zusammengeführter Positionen) - die Aufrufer (baumliste.html,
  // kalender.html) zeigen beides getrennt an, damit nachvollziehbar bleibt,
  // was tatsächlich passiert ist.
  async function bereinigePflegelistenDuplikate() {
    const listenEntfernt = await fuehreDoppelteListenZusammen();
    const alle = await window.LocalDB.getAll("baumlisten_items");
    const gruppen = new Map();
    for (const item of alle) {
      if (item.deleted_at) continue;
      const nummer = String(item.auftragsnummer || "").trim().toLowerCase();
      if (!nummer) continue;
      const liegenschaft = String(item.liegenschaft || "").trim().toLowerCase();
      const beschreibung = String(item.beschreibung || "").trim().toLowerCase();
      // Ohne liste_id als Schutzplanke braucht es mindestens EIN weiteres,
      // nicht-leeres Inhaltsfeld neben der Nummer - sonst könnten einfache
      // Wässerlisten mit rein sequenzieller Nummerierung (1, 2, 3, ...) ohne
      // Adressangabe über verschiedene, tatsächlich unabhängige Listen hinweg
      // fälschlich zusammengeführt werden.
      if (!liegenschaft && !beschreibung) continue;
      const schluessel = nummer + "|" + liegenschaft + "|" + beschreibung;
      if (!gruppen.has(schluessel)) gruppen.set(schluessel, []);
      gruppen.get(schluessel).push(item);
    }
    let entfernt = 0;
    for (const gruppe of gruppen.values()) {
      if (gruppe.length < 2) continue;
      gruppe.sort((a, b) => zaehleAusgefuelltePflegegaenge(b) - zaehleAusgefuelltePflegegaenge(a) || a.id - b.id);
      const [survivor, ...duplikate] = gruppe;
      const merged = Array.isArray(survivor.pflegegaenge) ? survivor.pflegegaenge.slice() : [];
      let geaendert = false;
      for (const duplikat of duplikate) {
        const dupPflege = Array.isArray(duplikat.pflegegaenge) ? duplikat.pflegegaenge : [];
        dupPflege.forEach((eintrag, index) => {
          if (!pflegegangIstAusgefuellt(merged[index]) && pflegegangIstAusgefuellt(eintrag)) {
            while (merged.length <= index) merged.push(null);
            merged[index] = eintrag;
            geaendert = true;
          }
        });
        if ((survivor.lat == null || survivor.lon == null) && duplikat.lat != null && duplikat.lon != null) {
          survivor.lat = duplikat.lat; survivor.lon = duplikat.lon; survivor.geo_quelle = duplikat.geo_quelle;
          geaendert = true;
        }
      }
      if (geaendert) {
        survivor.pflegegaenge = merged;
        survivor.updated_at = new Date().toISOString();
        await window.LocalDB.put("baumlisten_items", survivor);
      }
      for (const duplikat of duplikate) {
        duplikat.deleted_at = new Date().toISOString();
        duplikat.updated_at = duplikat.deleted_at;
        await window.LocalDB.put("baumlisten_items", duplikat);
        entfernt++;
      }
    }
    return { listen: listenEntfernt, positionen: entfernt };
  }

  // --------------------------------------------------- Foto-Inhaltsübertragung
  // Fotos nehmen oben nur mit ihren METADATEN am normalen JSON-Sync teil -
  // der eigentliche Bild-Inhalt ("blob") wird hier in einem eigenen Schritt
  // je Foto übertragen (ein HTTP-Request pro Bild statt eines einzigen,
  // potenziell riesigen JSON-Payloads mit allen Fotos eingebettet). Nur das
  // Nebengerät kann eine Verbindung aufbauen (Stern-Topologie, siehe
  // Kommentarkopf) - deshalb laufen BEIDE Richtungen (Hochladen eigener
  // neuer Fotos, Herunterladen fremder) hier, nicht auf dem Hauptgerät.
  function blobZuBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
  }
  function base64ZuBlob(base64) {
    const binaer = atob(base64);
    const bytes = new Uint8Array(binaer.length);
    for (let i = 0; i < binaer.length; i++) bytes[i] = binaer.charCodeAt(i);
    return new Blob([bytes], { type: "image/jpeg" });
  }

  // Nebengerät -> Hauptgerät: alle seit dem letzten Sync neu/geänderten
  // lokalen Fotos mit vorhandenem Blob hochladen (Metadaten dafür sind im
  // selben Sync-Durchlauf schon oben angekommen - das Hauptgerät hat also
  // bereits eine "leere" Zeile ohne Bild-Inhalt angelegt).
  async function ladeNeueFotosHoch(ip, port, seit) {
    for (const store of BILDER_STORES) {
      const alle = await window.LocalDB.getAll(store);
      const geaendert = alle.filter((r) => (!seit || zeitstempelVon(store, r) > seit) && r.blob && !r.deleted_at);
      for (const row of geaendert) {
        try {
          await fetch(`http://${ip}:${port}/foto/${store}/${row.client_uuid}`, { method: "POST", body: row.blob });
        } catch (err) {
          console.warn("LAN-Sync: Foto-Upload fehlgeschlagen:", err);
        }
      }
    }
  }

  // Hauptgerät -> Nebengerät: alle lokalen Foto-Zeilen ohne Blob (gerade erst
  // per Metadaten-Sync angekommen, egal ob ursprünglich vom Hauptgerät selbst
  // oder einem anderen Nebengerät) nachladen. Ein fehlgeschlagener Download
  // bleibt bewusst ohne Blob liegen - wird beim nächsten Sync automatisch
  // erneut versucht, kein harter Fehler für den ganzen Sync-Lauf.
  async function ladeFehlendeFotosHerunter(ip, port) {
    for (const store of BILDER_STORES) {
      const alle = await window.LocalDB.getAll(store);
      for (const row of alle) {
        if (row.deleted_at || row.blob) continue;
        try {
          const res = await fetch(`http://${ip}:${port}/foto/${store}/${row.client_uuid}`);
          if (!res.ok) continue;
          row.blob = await res.blob();
          await window.LocalDB.put(store, row);
        } catch (err) {
          console.warn("LAN-Sync: Foto-Download fehlgeschlagen:", err);
        }
      }
    }
  }

  // Hauptgerät-seitig: eingehendes Foto (Base64, aus der Bridge - siehe
  // LanSyncPlugin.java) auf die per Metadaten-Sync bereits angelegte Zeile
  // schreiben. Findet sich keine Zeile (sollte durch die Reihenfolge
  // Metadaten-vor-Inhalt nicht vorkommen), wird still nichts getan.
  async function speichereEmpfangenesFoto(store, uuid, bildBase64) {
    const treffer = await window.LocalDB.getAllByIndex(store, "client_uuid", uuid);
    const row = treffer && treffer[0];
    if (!row) return;
    row.blob = base64ZuBlob(bildBase64);
    await window.LocalDB.put(store, row);
  }

  // Hauptgerät-seitig: Bild-Inhalt für eine angefragte client_uuid als
  // Base64 liefern (null, falls nicht vorhanden/gelöscht - der Aufrufer
  // antwortet dann mit 404).
  async function leseFotoAlsBase64(store, uuid) {
    const treffer = await window.LocalDB.getAllByIndex(store, "client_uuid", uuid);
    const row = treffer && treffer[0];
    if (!row || !row.blob || row.deleted_at) return null;
    return blobZuBase64(row.blob);
  }

  // ------------------------------------------------------------ Nebengerät
  // Wird von public/account.html per Knopfdruck aufgerufen ("Mit Hauptgerät
  // synchronisieren"). Wirft bei Fehlern (kein Plugin/keine App, kein
  // Hauptgerät gefunden, Netzwerkfehler) - der Aufrufer zeigt die Meldung an.
  async function syncMitHauptgeraet() {
    const LanSync = plugin();
    if (!LanSync) throw new Error("Nur in der installierten App verfügbar.");
    if (!(await sicherstellenBerechtigung(LanSync))) {
      zeigeBerechtigungsHinweis();
      throw new Error("WLAN-Geräte-Berechtigung fehlt.");
    }

    const { geraete } = await LanSync.sucheHauptgeraet({ timeoutMs: 4000 });
    const ziel = (geraete || []).find((g) => g.ip);
    if (!ziel) throw new Error("Kein Hauptgerät im WLAN gefunden.");

    const cursorEintrag = await window.LocalDB.get("meta", "lanSyncCursor");
    const seit = cursorEintrag ? cursorEintrag.value : null;
    const changes = await baueAusgehendeAenderungen(seit);

    const res = await fetch(`http://${ziel.ip}:${ziel.port}/sync`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ deviceId: geraeteName(), since: seit, changes })
    });
    if (!res.ok) throw new Error("Sync fehlgeschlagen (HTTP " + res.status + ").");
    const antwort = await res.json();
    if (!antwort.ok) throw new Error(antwort.error || "Sync fehlgeschlagen.");

    const zaehler = await wendeAenderungenAn(antwort.changes, { ueberschreiben: true });
    await window.LocalDB.put("meta", { key: "lanSyncCursor", value: antwort.serverTime });
    try { await bereinigeSerienDuplikate(); } catch (err) { console.warn("LAN-Sync: Aufräumen von Serien-Duplikaten fehlgeschlagen:", err); }

    // Foto-INHALTE getrennt vom Metadaten-Sync oben übertragen (siehe
    // Kommentarkopf "Foto-Inhaltsübertragung"). Bewusst NICHT Teil des
    // eigentlichen Sync-Ergebnisses/-Fehlers: die Metadaten sind bereits
    // erfolgreich abgeglichen, ein hier fehlgeschlagenes Einzelfoto holt der
    // nächste Sync automatisch nach (Zeile bleibt einfach ohne Blob).
    try {
      await ladeNeueFotosHoch(ziel.ip, ziel.port, seit);
      await ladeFehlendeFotosHerunter(ziel.ip, ziel.port);
    } catch (err) {
      console.warn("LAN-Sync: Foto-Übertragung teilweise fehlgeschlagen:", err);
    }

    return zaehler;
  }

  // --------------------------------------- Eingangs-Benachrichtigung (Hauptgerät)
  // Zeigt nach jedem eingehenden Sync kurz an, was neu dazugekommen ist -
  // die Konfliktregel ("Hauptgerät gewinnt immer") verhindert zwar, dass
  // eigene Zeilen dabei je überschrieben werden, ganz neue Zeilen vom
  // Nebengerät kommen aber ungefragt rein. Damit das nicht unbemerkt bleibt
  // (und bei Bedarf manuell rückgängig gemacht werden kann), eine native
  // Benachrichtigung mit kurzer Aufzählung - fällt der Server auf dem
  // Hauptgerät gerade in den Hintergrund/das Display ist aus, würde ein
  // reiner DOM-Banner sonst nie gesehen werden.
  function notificationsPlugin() {
    if (!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform())) return null;
    return (window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications) || null;
  }
  let notifBerechtigungOk = null;
  async function sicherstellenNotifBerechtigung(LocalNotifications) {
    if (notifBerechtigungOk !== null) return notifBerechtigungOk;
    try {
      const status = await LocalNotifications.checkPermissions();
      if (status.display === "granted") { notifBerechtigungOk = true; return true; }
      const angefragt = await LocalNotifications.requestPermissions();
      notifBerechtigungOk = angefragt.display === "granted";
    } catch (err) {
      notifBerechtigungOk = false;
    }
    return notifBerechtigungOk;
  }

  function bezeichnung(store, anzahl) {
    const paar = STORE_LABEL[store];
    if (!paar) return store;
    return anzahl === 1 ? paar[0] : paar[1];
  }

  // Fallback, falls Benachrichtigungen nicht verfügbar/erlaubt sind (z.B. im
  // Browser-Test) - gleiches Muster wie der Berechtigungs-Hinweis oben, aber
  // grün statt gelb (positive Meldung, kein Handlungsaufruf) und schließt
  // sich nach einer Weile von selbst.
  function zeigeSyncEingangBanner(titel, body) {
    const vorhanden = document.getElementById("goLanSyncEingangBanner");
    if (vorhanden) vorhanden.remove();
    const banner = document.createElement("div");
    banner.id = "goLanSyncEingangBanner";
    banner.className = "fixed left-0 right-0 bottom-0 z-[998] bg-emerald-50 border-t border-emerald-200 text-emerald-800 text-sm px-4 py-3 flex items-center justify-between gap-3 flex-wrap";
    banner.innerHTML = `
      <span><i class="fa-solid fa-arrows-rotate mr-2"></i><strong>${titel}:</strong> ${body}</span>
      <button id="goLanSyncEingangSchliessen" class="px-3 py-1.5 rounded-lg bg-white border border-emerald-300 text-xs font-bold hover:bg-emerald-100">OK</button>`;
    document.body.appendChild(banner);
    document.getElementById("goLanSyncEingangSchliessen").addEventListener("click", () => banner.remove());
    setTimeout(() => { if (banner.parentNode) banner.remove(); }, 20000);
  }

  // Bewusst NICHT awaited am Aufrufort (siehe anfrageEmpfangen-Listener
  // unten) - die Antwort ans Nebengerät darf nicht auf eine
  // Benachrichtigungs-Berechtigungsabfrage warten.
  async function benachrichtigeUeberEingehendeAenderungen(deviceId, zaehler) {
    if (!zaehler || !zaehler.neu) return; // nichts wirklich Neues - keine Meldung nötig
    const teile = STORE_ANZEIGE_REIHENFOLGE
      .filter((s) => zaehler.neuProStore[s])
      .map((s) => `${zaehler.neuProStore[s]} ${bezeichnung(s, zaehler.neuProStore[s])}`);
    if (!teile.length) return;
    const titel = "WLAN-Sync: neue Daten übernommen";
    const body = (deviceId ? `Von "${deviceId}": ` : "") + teile.join(", ");

    const LocalNotifications = notificationsPlugin();
    if (LocalNotifications && (await sicherstellenNotifBerechtigung(LocalNotifications))) {
      try {
        await LocalNotifications.schedule({ notifications: [{ id: Date.now() % 2147483647, title: titel, body }] });
        return;
      } catch (err) {
        console.warn("LAN-Sync: Eingangs-Benachrichtigung konnte nicht angezeigt werden:", err);
      }
    }
    zeigeSyncEingangBanner(titel, body);
  }

  // ------------------------------------------------------------ Hauptgerät
  // WICHTIG: starteAlsHauptgeraet() wird an zwei Stellen aufgerufen - einmal
  // automatisch beim Laden JEDER Seite (unten, "fire and forget", niemand
  // wartet dort auf das Ergebnis) und einmal gezielt aus account.html beim
  // Umschalten/Öffnen der Seite (dort WILL man einen echten Fehler sehen,
  // z.B. wenn NsdManager.registerService scheitert oder der Port belegt ist -
  // sonst zeigt die UI faelschlich "Hauptgerät aktiviert", obwohl kein
  // Nebengerät je etwas finden könnte). Deshalb wirft diese Funktion bei
  // einem echten Fehler - der automatische Aufruf unten faengt das selbst ab.
  let serverLaeuft = false;
  let letzterFehler = null;
  async function starteAlsHauptgeraet() {
    const LanSync = plugin();
    if (!LanSync) throw new Error("Nur in der installierten App verfügbar.");
    if (serverLaeuft) return;
    if (!(await sicherstellenBerechtigung(LanSync))) {
      zeigeBerechtigungsHinweis();
      letzterFehler = "WLAN-Geräte-Berechtigung fehlt.";
      throw new Error(letzterFehler);
    }
    try {
      await LanSync.starteHauptgeraetServer({ geraetName: geraeteName() });
    } catch (err) {
      letzterFehler = String((err && err.message) || err);
      console.warn("LAN-Sync: Hauptgerät-Server konnte nicht gestartet werden:", err);
      throw err instanceof Error ? err : new Error(letzterFehler);
    }
    serverLaeuft = true;
    letzterFehler = null;
    LanSync.addListener("anfrageEmpfangen", async (event) => {
      const { anfrageId, since, changes, deviceId } = event || {};
      let statusCode, bodyJson;
      try {
        const zaehler = await wendeAenderungenAn(changes, { ueberschreiben: false });
        try { await bereinigeSerienDuplikate(); } catch (err) { console.warn("LAN-Sync: Aufräumen von Serien-Duplikaten fehlgeschlagen:", err); }
        const serverTime = new Date().toISOString();
        const ausgehend = await baueAusgehendeAenderungen(since);
        statusCode = 200;
        bodyJson = JSON.stringify({ ok: true, serverTime, changes: ausgehend });
        benachrichtigeUeberEingehendeAenderungen(deviceId, zaehler).catch((err) => console.warn("LAN-Sync: Eingangs-Benachrichtigung fehlgeschlagen:", err));
      } catch (err) {
        statusCode = 500;
        bodyJson = JSON.stringify({ ok: false, error: String((err && err.message) || err) });
      }
      try {
        await LanSync.beantworteAnfrage({ anfrageId, statusCode, bodyJson });
      } catch (err) {
        console.warn("LAN-Sync: Antwort konnte nicht zugestellt werden:", err);
      }
    });
    // Foto-Inhaltsübertragung (siehe Kommentarkopf weiter oben) - zwei
    // eigene Events, weil LanSyncPlugin.java bei einem Foto-Request weder
    // JSON parst noch die Antwort als JSON schreibt (roher Bild-Inhalt,
    // Base64-kodiert für die Bridge).
    LanSync.addListener("fotoEmpfangen", async (event) => {
      const { anfrageId, store, uuid, bildBase64 } = event || {};
      let statusCode, bodyJson;
      try {
        await speichereEmpfangenesFoto(store, uuid, bildBase64);
        statusCode = 200;
        bodyJson = JSON.stringify({ ok: true });
      } catch (err) {
        statusCode = 500;
        bodyJson = JSON.stringify({ ok: false, error: String((err && err.message) || err) });
      }
      try {
        await LanSync.beantworteAnfrage({ anfrageId, statusCode, bodyJson });
      } catch (err) {
        console.warn("LAN-Sync: Antwort auf Foto-Upload konnte nicht zugestellt werden:", err);
      }
    });
    LanSync.addListener("fotoAngefordert", async (event) => {
      const { anfrageId, store, uuid } = event || {};
      try {
        const bildBase64 = await leseFotoAlsBase64(store, uuid);
        if (bildBase64) {
          await LanSync.beantworteAnfrage({ anfrageId, statusCode: 200, bildBase64 });
        } else {
          await LanSync.beantworteAnfrage({ anfrageId, statusCode: 404, bodyJson: JSON.stringify({ error: "not_found" }) });
        }
      } catch (err) {
        console.warn("LAN-Sync: Foto-Anfrage konnte nicht beantwortet werden:", err);
        try { await LanSync.beantworteAnfrage({ anfrageId, statusCode: 500, bodyJson: JSON.stringify({ error: String((err && err.message) || err) }) }); } catch (e) { /* egal */ }
      }
    });
  }

  async function stoppeHauptgeraet() {
    const LanSync = plugin();
    if (!LanSync) return;
    try { await LanSync.stoppeServer(); } catch (err) { /* egal, war ggf. eh nicht aktiv */ }
    serverLaeuft = false;
    letzterFehler = null;
  }

  window.GoLanSync = {
    istHauptgeraet, geraeteName,
    setzeHauptgeraet(an) { localStorage.setItem(LS_HAUPTGERAET, an ? "1" : "0"); },
    setzeGeraeteName(name) { localStorage.setItem(LS_GERAETNAME, String(name || "").trim()); },
    syncMitHauptgeraet,
    starteAlsHauptgeraet, stoppeHauptgeraet,
    // Räumt Termine-Duplikate wiederkehrender Serien auf (siehe
    // bereinigeSerienDuplikate oben) - unabhängig von einem WLAN-Sync
    // aufrufbar, z.B. über "Termine neu scannen" in kalender.html. Gibt die
    // Anzahl der entfernten Duplikate zurück.
    bereinigeSerienDuplikate,
    // Räumt Pflegelisten-Positionen auf, die (typischerweise durch je einen
    // eigenen CSV/Excel-Import auf mehreren Geräten VOR deren erstem WLAN-
    // Sync) inhaltlich dupliziert wurden - siehe bereinigePflegelistenDuplikate
    // oben. Führt dabei den Pflege-Fortschritt (pflegegaenge) aller Duplikate
    // zusammen, bevor die überzähligen Zeilen gelöscht werden. Aufrufbar über
    // "Pflegelisten-Duplikate bereinigen" in baumliste.html.
    bereinigePflegelistenDuplikate,
    // Echter Laufzeit-Status des nativen Servers - NICHT identisch mit
    // istHauptgeraet() (das ist nur die per Umschalter gespeicherte Absicht).
    // account.html nutzt das, um einen fehlgeschlagenen Start sichtbar zu
    // machen statt faelschlich "Server läuft" zu zeigen.
    serverLaeuft: () => serverLaeuft,
    letzterFehler: () => letzterFehler,
    // Nur für automatisierte Tests exponiert (siehe scratchpad-Testskripte):
    // reine, ausschließlich auf der eigenen lokalen IndexedDB arbeitende
    // Funktionen - erlauben, die Merge-/Konfliktlogik ohne echtes WLAN/
    // natives Plugin zu prüfen (zwei Playwright-Kontexte simulieren zwei
    // Geräte und reichen sich den {since,changes}-Payload direkt weiter).
    _test: {
      baueAusgehendeAenderungen, wendeAenderungenAn, benachrichtigeUeberEingehendeAenderungen,
      ladeNeueFotosHoch, ladeFehlendeFotosHerunter, speichereEmpfangenesFoto, leseFotoAlsBase64,
      blobZuBase64, base64ZuBlob, bereinigeSerienDuplikate, bereinigePflegelistenDuplikate
    },
    // Für die Sicherung in account.html (siehe public/js/backup.js): reine
    // Aliase auf die bereits vorhandene Serialisierungs-/Merge-Engine oben -
    // keine neue Logik. exportiereAlleDaten liefert mit seit=null einen
    // vollständigen Dump aller Stores; importiereAlleDaten spielt ihn mit
    // "Sicherung gewinnt" wieder ein (gedacht für ein neues/zurückgesetztes
    // Gerät, bei dem ein Merge-in-leer sich wie ein sauberer Restore verhält).
    exportiereAlleDaten: () => baueAusgehendeAenderungen(null),
    importiereAlleDaten: (changes) => wendeAenderungenAn(changes, { ueberschreiben: true }),
    BILDER_STORES, blobZuBase64, base64ZuBlob, speichereEmpfangenesFoto
  };

  // Beim Laden jeder Seite (siehe Script-Einbindung): billiger localStorage-
  // Check, kein spuerbarer Overhead auf Seiten, die den Umschalter nie
  // gesetzt haben. Das Hauptgeraet muss antwortfaehig bleiben, egal auf
  // welcher Seite gerade gearbeitet wird - deshalb kein Bezug auf
  // account.html noetig. Fire-and-forget: der Fehler wurde oben schon
  // geloggt, hier nur noch abfangen, damit keine unbehandelte Promise-
  // Ablehnung entsteht.
  if (istHauptgeraet()) {
    window.addEventListener("DOMContentLoaded", () => { starteAlsHauptgeraet().catch(() => {}); });
  }
})();
