(function () {
  var KEY = "go-theme";

  function getTheme() {
    try { return localStorage.getItem(KEY) || "dark"; } catch (e) { return "dark"; }
  }

  function updateIcons(theme) {
    document.querySelectorAll("[data-theme-toggle]").forEach(function (btn) {
      btn.innerHTML = theme === "dark"
        ? '<i class="fa-solid fa-sun"></i>'
        : '<i class="fa-solid fa-moon"></i>';
      btn.title = theme === "dark" ? "Helles Design" : "Dunkles Design";
    });
  }

  window.toggleTheme = function () {
    var next = getTheme() === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    try { localStorage.setItem(KEY, next); } catch (e) {}
    updateIcons(next);
  };

  document.addEventListener("DOMContentLoaded", function () { updateIcons(getTheme()); });
})();
