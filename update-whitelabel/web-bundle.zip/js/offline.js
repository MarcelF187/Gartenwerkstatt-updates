// Offline-Datenschicht (Phase 3/4): Warteschlange (Outbox) + Sync.
//
// Idee: Schreibvorgänge (neuer Tagesbericht, neuer Heckenschnitt, Pflegegang
// abhaken) laufen über GOffline.saveOrQueue(). Ist Netz da, geht die Anfrage
// direkt an den Server. Ist kein Netz da (oder die Anfrage scheitert), wird sie
// in einer lokalen Warteschlange (IndexedDB) gesichert und automatisch
// hochgeladen, sobald wieder Verbindung besteht.
//
// Jeder Eintrag bekommt eine client_uuid -> der Server legt beim erneuten Sync
// nichts doppelt an. Der aktive Nutzer (GOAuth) wird als Autor mitgeschickt.
(function () {
  const DB_NAME = "ihre-firma-offline";
  const STORE = "outbox";
  let dbPromise = null;

  function db() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const d = req.result;
        if (!d.objectStoreNames.contains(STORE)) {
          d.createObjectStore(STORE, { keyPath: "id" });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  async function tx(mode, fn) {
    const d = await db();
    return new Promise((resolve, reject) => {
      const t = d.transaction(STORE, mode);
      const store = t.objectStore(STORE);
      let ergebnis;
      Promise.resolve(fn(store)).then((r) => { ergebnis = r; });
      t.oncomplete = () => resolve(ergebnis);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error);
    });
  }

  function uuid() {
    if (crypto.randomUUID) return crypto.randomUUID();
    return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (c) =>
      (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16));
  }

  async function alleAusstehend() {
    return tx("readonly", (s) => new Promise((res) => {
      const out = [];
      s.openCursor().onsuccess = (e) => {
        const cur = e.target.result;
        if (cur) { out.push(cur.value); cur.continue(); } else res(out.sort((a, b) => a.erstelltAm - b.erstelltAm));
      };
    }));
  }

  const GOffline = {
    _listener: new Set(),
    onChange(fn) { this._listener.add(fn); return () => this._listener.delete(fn); },
    _melden() { this.anzahlAusstehend().then((n) => this._listener.forEach((fn) => fn(n))); },

    async anzahlAusstehend() {
      return tx("readonly", (s) => new Promise((res) => { const r = s.count(); r.onsuccess = () => res(r.result); }));
    },

    // Speichert direkt oder legt die Anfrage in die Warteschlange (nur bei
    // einem echten, unerwarteten Fehler). opts: { method, body(objekt), label }
    // - body wird um client_uuid + erfasst_von ergänzt.
    //
    // WICHTIG: kein navigator.onLine-Vorbehalt mehr. /api/... läuft seit der
    // Umstellung auf die Offline-App komplett lokal über local-api.js (siehe
    // dortiger Kommentarkopf: "jede Anfrage an /api/... wird NICHT mehr ans
    // Netz geschickt") - unabhängig vom tatsächlichen WLAN/Mobilfunk-Status
    // des Geräts. navigator.onLine spiegelt aber genau diesen Gerätestatus
    // wider und hatte damit nichts mehr mit der Erreichbarkeit der lokalen
    // "API" zu tun: ohne WLAN im Garten (sehr häufiger Fall beim Abarbeiten
    // eines Pflegegangs) landete JEDER Schreibvorgang unnötig in dieser
    // Warteschlange statt sofort in der echten Tabelle zu landen - sichtbar
    // blieb nur die optimistische UI-Änderung im Speicher, die beim nächsten
    // Neuladen wieder verschwand, ohne dass je ein WLAN-Kontakt nachgeholt
    // wurde (Tablet hat evtl. nie wieder WLAN, bevor die App neu geladen
    // wird). Direkter Aufruf funktioniert lokal immer, WLAN hin oder her.
    async saveOrQueue(url, opts) {
      const method = opts.method || "POST";
      const aktiver = window.GOAuth && GOAuth.active ? GOAuth.active() : null;
      const body = { ...(opts.body || {}) };
      if (!body.client_uuid) body.client_uuid = uuid();
      if (aktiver && !body.erfasst_von) body.erfasst_von = aktiver.username;

      try {
        const res = await fetch(url, {
          method, credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });
        if (res.ok) return { ...(await res.json().catch(() => ({}))), _offline: false };
        // Serverfehler (nicht Netz): nicht in die Warteschlange, echter Fehler
        throw new Error("http_" + res.status);
      } catch (err) {
        // Nur echte, unerwartete Fehler in die Warteschlange; HTTP-Fehler weiterreichen
        if (err.message && err.message.startsWith("http_")) throw err;
      }

      // Nur bei einem echten, unerwarteten Fehler oben -> Warteschlange
      const eintrag = {
        id: body.client_uuid,
        url, method, body,
        label: opts.label || url,
        erstelltAm: Date.now()
      };
      await tx("readwrite", (s) => s.put(eintrag));
      this._melden();
      return { ok: true, _offline: true, client_uuid: body.client_uuid };
    },

    // Warteschlange abarbeiten (bei Online-Rückkehr oder manuell).
    async sync() {
      if (!navigator.onLine) return { gesendet: 0, offen: await this.anzahlAusstehend() };
      const eintraege = await alleAusstehend();
      let gesendet = 0;
      for (const e of eintraege) {
        try {
          const res = await fetch(e.url, {
            method: e.method, credentials: "include",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(e.body)
          });
          // ok ODER 4xx (z.B. schon vorhanden/dedupe) gilt als erledigt -> aus der Queue
          if (res.ok || (res.status >= 400 && res.status < 500)) {
            await tx("readwrite", (s) => s.delete(e.id));
            gesendet++;
          } else {
            break; // Serverproblem -> später erneut
          }
        } catch {
          break; // Netz weg -> abbrechen, Rest bleibt in der Queue
        }
      }
      this._melden();
      return { gesendet, offen: await this.anzahlAusstehend() };
    },

    async ausstehendeListe() { return alleAusstehend(); }
  };

  window.GOffline = GOffline;

  // Automatisch synchronisieren, sobald wieder Netz da ist
  window.addEventListener("online", () => GOffline.sync());
  // Und einmal beim Laden (falls beim letzten Mal offline gespeichert wurde)
  window.addEventListener("DOMContentLoaded", () => {
    if (navigator.onLine) GOffline.sync();
    GOffline._melden();
  });
})();
