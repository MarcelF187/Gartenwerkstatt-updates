// "Was ist neu?"-Popup nach einem App-Update.
//
// Reines Web-Code-Feature (kein natives Plugin) - läuft daher auch über das
// normale Hot-Update (siehe public/js/hot-update.js), ohne neue APK.
//
// Vergleicht die Changelog-Liste (public/js/changelog-data.js, neueste zuerst)
// mit dem zuletzt gesehenen Eintrag aus localStorage. Sind neue Einträge da,
// werden sie einmalig als Popup gezeigt; "Verstanden" merkt sich den Stand.
// Beim allerersten Start mit diesem Feature wird nur der aktuelle Stand
// gemerkt, ohne die komplette bisherige Historie auf einen Schlag zu zeigen.
(function () {
  "use strict";

  const LAST_SEEN_KEY = "go-changelog-last-seen";

  function eintragSchluessel(e) { return `${e.datum}::${e.titel}`; }

  function esc(s) {
    const d = document.createElement("div");
    d.textContent = s || "";
    return d.innerHTML;
  }

  function zeigeModal(neueEintraege) {
    const overlay = document.createElement("div");
    overlay.id = "goUpdatePopup";
    overlay.className = "fixed inset-0 z-[999] bg-slate-900/60 p-4 flex items-center justify-center";
    overlay.innerHTML = `
      <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[85vh] overflow-y-auto p-5">
        <h2 class="text-lg font-bold text-slate-800 mb-1"><i class="fa-solid fa-bullhorn mr-2 text-emerald-600"></i>Was ist neu?</h2>
        <p class="text-xs text-slate-400 mb-4">Die App wurde aktualisiert - das hat sich geändert:</p>
        <div class="flex flex-col gap-3 mb-5">
          ${neueEintraege.map((e) => `
            <div class="bg-slate-50 rounded-xl border border-slate-200 p-4">
              <div class="text-xs font-bold text-slate-400 uppercase mb-1">${esc(e.datum)}</div>
              <h3 class="font-bold text-slate-800 mb-2 text-sm">${esc(e.titel)}</h3>
              <ul class="list-disc list-inside text-sm text-slate-600 space-y-1">
                ${e.punkte.map((p) => `<li>${esc(p)}</li>`).join("")}
              </ul>
            </div>`).join("")}
        </div>
        <button id="goUpdatePopupSchliessen" class="w-full px-4 py-2 rounded-lg bg-emerald-700 text-white text-sm font-bold hover:bg-emerald-800">Verstanden</button>
      </div>`;
    document.body.appendChild(overlay);
    document.getElementById("goUpdatePopupSchliessen").addEventListener("click", () => {
      overlay.remove();
      localStorage.setItem(LAST_SEEN_KEY, eintragSchluessel(neueEintraege[0]));
    });
  }

  function pruefen() {
    const eintraege = window.GO_CHANGELOG;
    if (!Array.isArray(eintraege) || !eintraege.length) return;
    if (document.getElementById("goUpdatePopup")) return;

    const zuletztGesehen = localStorage.getItem(LAST_SEEN_KEY);
    if (zuletztGesehen === null) {
      localStorage.setItem(LAST_SEEN_KEY, eintragSchluessel(eintraege[0]));
      return;
    }

    const idx = eintraege.findIndex((e) => eintragSchluessel(e) === zuletztGesehen);
    if (idx === -1) {
      // Gemerkter Eintrag nicht mehr auffindbar (z.B. Changelog aufgeräumt) -
      // Zustand zurücksetzen statt dauerhaft hängen zu bleiben.
      localStorage.setItem(LAST_SEEN_KEY, eintragSchluessel(eintraege[0]));
      return;
    }
    const neu = eintraege.slice(0, idx);
    if (neu.length) zeigeModal(neu);
  }

  if (document.readyState === "complete") pruefen();
  else window.addEventListener("load", pruefen);
})();
