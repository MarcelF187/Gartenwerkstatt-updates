// Lokale "Datenbank im Browser" für die server-lose App (Capacitor/Android).
//
// Ersetzt Postgres komplett durch IndexedDB. Jede Tabelle aus dem Server-Schema
// wird 1:1 als Object-Store nachgebildet (gleiche Feldnamen), damit local-api.js
// die bestehenden Seiten unverändert bedienen kann. Autor: es gibt keinen
// Server mehr, der etwas absichert - dieses "Backend" läuft im selben Prozess
// wie die Seite, die es aufruft (vertrauenswürdiges Einzelgerät).
(function () {
  const DB_NAME = "ihre-firma-local";
  const DB_VERSION = 7;

  // Stores, die am geräteübergreifenden WLAN-Sync (Hauptgerät/Nebengerät,
  // siehe public/js/lan-sync.js) teilnehmen, brauchen einen client_uuid-Index
  // (Fremdschlüssel gehen über die Leitung nie als rohe id - jedes Gerät hat
  // seine eigene, unabhängige Auto-Increment-Sequenz). Bewusst NICHT unique:
  // die Eindeutigkeit stellt der Sync-Anwendungscode selbst per Dedupe sicher,
  // ein DB-Constraint waere in einer Bulk-Apply-Transaktion nur ein weiterer
  // Fehlerfall. tagesberichte/heckenschnitt/bautagesberichte hatten
  // client_uuid schon vorher (reine Offline-Idempotenz) - deren bestehender
  // unique-Index bleibt unangetastet.
  const STORES = {
    meta: { keyPath: "key" },
    kunden: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] },
    notizen: { keyPath: "id", autoIncrement: true, indexes: [["kunde_id", "kunde_id"], ["client_uuid", "client_uuid"]] },
    // "blob" enthält das bereits im Browser komprimierte JPEG direkt als
    // Blob (IndexedDB unterstützt das nativ) - kein Umweg über Base64. Der
    // Bild-INHALT (blob) läuft NICHT über den normalen JSON-WLAN-Sync (siehe
    // SYNC_STORES_V7 unten und public/js/lan-sync.js) - nur die Metadaten
    // inkl. client_uuid; die eigentlichen Bytes holt lan-sync.js in einem
    // eigenen, getrennten Übertragungsschritt je Foto nach.
    notiz_bilder: { keyPath: "id", autoIncrement: true, indexes: [["notiz_id", "notiz_id"], ["client_uuid", "client_uuid"]] },
    users: { keyPath: "id", autoIncrement: true, indexes: [["username", "username", { unique: true }], ["client_uuid", "client_uuid"]] },
    stammdaten: { keyPath: "id", autoIncrement: true, indexes: [["typ", "typ"], ["bereich", "bereich"], ["client_uuid", "client_uuid"]] },
    tagesberichte: {
      keyPath: "id", autoIncrement: true,
      indexes: [["bericht_nr", "bericht_nr", { unique: true }], ["client_uuid", "client_uuid", { unique: true }]]
    },
    heckenschnitt: {
      keyPath: "id", autoIncrement: true,
      indexes: [["kunde", "kunde"], ["datum", "datum"], ["client_uuid", "client_uuid", { unique: true }]]
    },
    // Vorher-/Nachher-Fotos je Heckenschnitt-Eintrag - gleiches Muster wie
    // notiz_bilder: das komprimierte JPEG liegt direkt als Blob im Store.
    heckenschnitt_bilder: { keyPath: "id", autoIncrement: true, indexes: [["eintrag_id", "eintrag_id"], ["client_uuid", "client_uuid"]] },
    baumlisten: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] },
    baumlisten_items: { keyPath: "id", autoIncrement: true, indexes: [["liste_id", "liste_id"], ["client_uuid", "client_uuid"]] },
    projekte: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] },
    bautagesberichte: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid", { unique: true }]] },
    lv_bau_projekte: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] },
    lv_bau_listen: { keyPath: "id", autoIncrement: true, indexes: [["projekt_id", "projekt_id"], ["client_uuid", "client_uuid"]] },
    lv_bau_items: { keyPath: "id", autoIncrement: true, indexes: [["liste_id", "liste_id"], ["client_uuid", "client_uuid"]] },
    termine: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid"]] }
  };

  // Stores, für die V5 bestehende Zeilen nachrüstet (client_uuid/updated_at/
  // deleted_at) - Umfang von public/js/lan-sync.js Phase 1, siehe dortigen
  // Kommentarkopf. kunden zählt mit, weil notizen.kunde_id sonst beim Sync
  // nicht auflösbar wäre.
  const SYNC_STORES_V5 = ["kunden", "baumlisten", "baumlisten_items", "termine", "notizen", "tagesberichte", "heckenschnitt"];

  // V6 (Phase 2 des WLAN-Syncs): Bau-Bereich, Stammdaten, Nutzerverwaltung,
  // Projekte kommen dazu. bautagesberichte hatte den Store (inkl. eindeutigem
  // client_uuid-Index) schon vorher, nur nie befüllte Werte - läuft hier
  // trotzdem mit, damit bestehende Berichte einen Sync-Schlüssel bekommen.
  const SYNC_STORES_V6 = ["users", "stammdaten", "projekte", "bautagesberichte", "lv_bau_projekte", "lv_bau_listen", "lv_bau_items"];

  // V7: Foto-Metadaten (notiz_bilder/heckenschnitt_bilder) nehmen jetzt auch
  // am WLAN-Sync teil - nur Metadaten (client_uuid/updated_at/deleted_at),
  // nicht der Bild-INHALT selbst (siehe Kommentar bei notiz_bilder oben).
  // Zeitstempel-Fallback bewusst nur "erstellt_am" (kein "aktualisiert_am"/
  // "created_at" wie bei V5/V6 - diese Stores hatten nie ein anderes Feld).
  const SYNC_STORES_V7 = ["notiz_bilder", "heckenschnitt_bilder"];

  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = (event) => {
        const d = req.result;
        for (const [name, def] of Object.entries(STORES)) {
          if (d.objectStoreNames.contains(name)) continue;
          const store = d.createObjectStore(name, {
            keyPath: def.keyPath,
            autoIncrement: !!def.autoIncrement
          });
          (def.indexes || []).forEach(([idxName, keyPath, opts]) => store.createIndex(idxName, keyPath, opts || {}));
        }

        // V5: die Schleife oben legt nur komplett fehlende Stores neu an und
        // rührt bestehende nicht an - für den WLAN-Sync müssen aber gerade
        // die längst vorhandenen Zeilen in SYNC_STORES_V5 nachträglich einen
        // client_uuid-Index bekommen (falls noch nicht vorhanden) und selbst
        // client_uuid/updated_at/deleted_at nachgerüstet bekommen, sonst
        // wären ältere, vor diesem Update angelegte Datensätze für den Sync
        // unsichtbar (kein Schlüssel zum Abgleichen, kein Zeitstempel für die
        // Delta-Berechnung).
        if (event.oldVersion > 0 && event.oldVersion < 5) {
          for (const name of SYNC_STORES_V5) {
            if (!d.objectStoreNames.contains(name)) continue; // sollte nicht vorkommen, sicherheitshalber
            const store = req.transaction.objectStore(name);
            if (!store.indexNames.contains("client_uuid")) {
              store.createIndex("client_uuid", "client_uuid", { unique: false });
            }
            store.openCursor().onsuccess = (ev) => {
              const cursor = ev.target.result;
              if (!cursor) return;
              const row = cursor.value;
              if (!row.client_uuid) {
                row.client_uuid = crypto.randomUUID();
                row.updated_at = row.updated_at || row.aktualisiert_am || row.erstellt_am || new Date().toISOString();
                if (row.deleted_at === undefined) row.deleted_at = null;
                cursor.update(row);
              }
              cursor.continue();
            };
          }
        }

        // V6: gleiche Nachrüstung wie V5, nur für die 7 Phase-2-Stores (siehe
        // SYNC_STORES_V6 oben). Ergänzt den Zeitstempel-Fallback um
        // "created_at" (users/bautagesberichte) - stammdaten hat gar keinen
        // eigenen Zeitstempel, bekommt also schlicht "jetzt" als erstes
        // updated_at, was für eine reine Migrations-Backfill-Zeile
        // unproblematisch ist.
        if (event.oldVersion > 0 && event.oldVersion < 6) {
          for (const name of SYNC_STORES_V6) {
            if (!d.objectStoreNames.contains(name)) continue;
            const store = req.transaction.objectStore(name);
            if (!store.indexNames.contains("client_uuid")) {
              store.createIndex("client_uuid", "client_uuid", { unique: false });
            }
            store.openCursor().onsuccess = (ev) => {
              const cursor = ev.target.result;
              if (!cursor) return;
              const row = cursor.value;
              if (!row.client_uuid) {
                row.client_uuid = crypto.randomUUID();
                row.updated_at = row.updated_at || row.aktualisiert_am || row.erstellt_am || row.created_at || new Date().toISOString();
                if (row.deleted_at === undefined) row.deleted_at = null;
                cursor.update(row);
              }
              cursor.continue();
            };
          }
        }

        // V7: gleiche Nachrüstung wie V5/V6, nur für die beiden Foto-Stores
        // (siehe SYNC_STORES_V7 oben) - deren einziger vorheriger Zeitstempel
        // ist "erstellt_am".
        if (event.oldVersion > 0 && event.oldVersion < 7) {
          for (const name of SYNC_STORES_V7) {
            if (!d.objectStoreNames.contains(name)) continue;
            const store = req.transaction.objectStore(name);
            if (!store.indexNames.contains("client_uuid")) {
              store.createIndex("client_uuid", "client_uuid", { unique: false });
            }
            store.openCursor().onsuccess = (ev) => {
              const cursor = ev.target.result;
              if (!cursor) return;
              const row = cursor.value;
              if (!row.client_uuid) {
                row.client_uuid = crypto.randomUUID();
                row.updated_at = row.updated_at || row.erstellt_am || new Date().toISOString();
                if (row.deleted_at === undefined) row.deleted_at = null;
                cursor.update(row);
              }
              cursor.continue();
            };
          }
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  async function tx(storeNames, mode, fn) {
    const d = await open();
    return new Promise((resolve, reject) => {
      const t = d.transaction(storeNames, mode);
      const stores = Array.isArray(storeNames)
        ? Object.fromEntries(storeNames.map((n) => [n, t.objectStore(n)]))
        : t.objectStore(storeNames);
      let ergebnis;
      Promise.resolve(fn(stores)).then((r) => { ergebnis = r; }, reject);
      t.oncomplete = () => resolve(ergebnis);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error);
    });
  }

  function reqToPromise(req) {
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  const LocalDB = {
    async add(store, obj) {
      return tx(store, "readwrite", async (s) => {
        const id = await reqToPromise(s.add(obj));
        return { ...obj, [STORES[store].keyPath]: id };
      });
    },
    async put(store, obj) {
      await tx(store, "readwrite", (s) => reqToPromise(s.put(obj)));
      return obj;
    },
    async get(store, id) {
      return tx(store, "readonly", (s) => reqToPromise(s.get(id)));
    },
    async getAll(store) {
      return tx(store, "readonly", (s) => reqToPromise(s.getAll()));
    },
    async getAllByIndex(store, indexName, value) {
      return tx(store, "readonly", (s) => reqToPromise(s.index(indexName).getAll(value)));
    },
    async delete(store, id) {
      return tx(store, "readwrite", (s) => reqToPromise(s.delete(id)));
    },
    async count(store) {
      return tx(store, "readonly", (s) => reqToPromise(s.count()));
    },
    async clear(store) {
      return tx(store, "readwrite", (s) => reqToPromise(s.clear()));
    },

    // Einmalig beim allerersten Start: Stammdaten-Grunddaten importieren, damit
    // Dropdowns nicht leer sind (entspricht Migration 010_stammdaten_seed.sql).
    // local-api.js ruft das vor JEDEM /api-Aufruf auf - ein modulweiter
    // Promise-Lock verhindert, dass mehrere gleichzeitig gestartete Aufrufe
    // die Stammdaten doppelt importieren (Race Condition ohne Lock).
    ensureSeeded() {
      if (!this._seedPromise) {
        this._seedPromise = (async () => {
          const schonGesät = await this.get("meta", "stammdatenSeedV1");
          if (schonGesät) return;
          const vorhanden = await this.count("stammdaten");
          if (vorhanden === 0) {
            const res = await fetch("/js/local-data/stammdaten.seed.json");
            const zeilen = await res.json();
            await tx("stammdaten", "readwrite", (s) => {
              zeilen.forEach((z) => s.add({ typ: z.typ, bereich: z.bereich || "pflege", bezeichnung: z.bezeichnung, aktiv: true }));
            });
          }
          await this.put("meta", { key: "stammdatenSeedV1", value: true });
        })();
      }
      return this._seedPromise;
    }
  };

  window.LocalDB = LocalDB;
})();
