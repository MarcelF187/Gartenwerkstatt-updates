// Lokale "Datenbank im Browser" für die server-lose App (Capacitor/Android).
//
// Ersetzt Postgres komplett durch IndexedDB. Jede Tabelle aus dem Server-Schema
// wird 1:1 als Object-Store nachgebildet (gleiche Feldnamen), damit local-api.js
// die bestehenden Seiten unverändert bedienen kann. Autor: es gibt keinen
// Server mehr, der etwas absichert - dieses "Backend" läuft im selben Prozess
// wie die Seite, die es aufruft (vertrauenswürdiges Einzelgerät).
(function () {
  const DB_NAME = "ihre-firma-local";
  const DB_VERSION = 4;

  const STORES = {
    meta: { keyPath: "key" },
    kunden: { keyPath: "id", autoIncrement: true },
    notizen: { keyPath: "id", autoIncrement: true, indexes: [["kunde_id", "kunde_id"]] },
    // "blob" enthält das bereits im Browser komprimierte JPEG direkt als
    // Blob (IndexedDB unterstützt das nativ) - kein Umweg über Base64.
    notiz_bilder: { keyPath: "id", autoIncrement: true, indexes: [["notiz_id", "notiz_id"]] },
    users: { keyPath: "id", autoIncrement: true, indexes: [["username", "username", { unique: true }]] },
    stammdaten: { keyPath: "id", autoIncrement: true, indexes: [["typ", "typ"], ["bereich", "bereich"]] },
    tagesberichte: {
      keyPath: "id", autoIncrement: true,
      indexes: [["bericht_nr", "bericht_nr", { unique: true }], ["client_uuid", "client_uuid", { unique: true }]]
    },
    heckenschnitt: {
      keyPath: "id", autoIncrement: true,
      indexes: [["kunde", "kunde"], ["datum", "datum"], ["client_uuid", "client_uuid", { unique: true }]]
    },
    // Vorher-/Nachher-Fotos je Heckenschnitt-Eintrag - gleiches Muster wie
    // notiz_bilder: das komprimierte JPEG liegt direkt als Blob im Store.
    heckenschnitt_bilder: { keyPath: "id", autoIncrement: true, indexes: [["eintrag_id", "eintrag_id"]] },
    baumlisten: { keyPath: "id", autoIncrement: true },
    baumlisten_items: { keyPath: "id", autoIncrement: true, indexes: [["liste_id", "liste_id"]] },
    projekte: { keyPath: "id", autoIncrement: true },
    bautagesberichte: { keyPath: "id", autoIncrement: true, indexes: [["client_uuid", "client_uuid", { unique: true }]] },
    lv_bau_projekte: { keyPath: "id", autoIncrement: true },
    lv_bau_listen: { keyPath: "id", autoIncrement: true, indexes: [["projekt_id", "projekt_id"]] },
    lv_bau_items: { keyPath: "id", autoIncrement: true, indexes: [["liste_id", "liste_id"]] },
    termine: { keyPath: "id", autoIncrement: true }
  };

  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const d = req.result;
        for (const [name, def] of Object.entries(STORES)) {
          if (d.objectStoreNames.contains(name)) continue;
          const store = d.createObjectStore(name, {
            keyPath: def.keyPath,
            autoIncrement: !!def.autoIncrement
          });
          (def.indexes || []).forEach(([idxName, keyPath, opts]) => store.createIndex(idxName, keyPath, opts || {}));
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  async function tx(storeNames, mode, fn) {
    const d = await open();
    return new Promise((resolve, reject) => {
      const t = d.transaction(storeNames, mode);
      const stores = Array.isArray(storeNames)
        ? Object.fromEntries(storeNames.map((n) => [n, t.objectStore(n)]))
        : t.objectStore(storeNames);
      let ergebnis;
      Promise.resolve(fn(stores)).then((r) => { ergebnis = r; }, reject);
      t.oncomplete = () => resolve(ergebnis);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error);
    });
  }

  function reqToPromise(req) {
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  const LocalDB = {
    async add(store, obj) {
      return tx(store, "readwrite", async (s) => {
        const id = await reqToPromise(s.add(obj));
        return { ...obj, [STORES[store].keyPath]: id };
      });
    },
    async put(store, obj) {
      await tx(store, "readwrite", (s) => reqToPromise(s.put(obj)));
      return obj;
    },
    async get(store, id) {
      return tx(store, "readonly", (s) => reqToPromise(s.get(id)));
    },
    async getAll(store) {
      return tx(store, "readonly", (s) => reqToPromise(s.getAll()));
    },
    async getAllByIndex(store, indexName, value) {
      return tx(store, "readonly", (s) => reqToPromise(s.index(indexName).getAll(value)));
    },
    async delete(store, id) {
      return tx(store, "readwrite", (s) => reqToPromise(s.delete(id)));
    },
    async count(store) {
      return tx(store, "readonly", (s) => reqToPromise(s.count()));
    },
    async clear(store) {
      return tx(store, "readwrite", (s) => reqToPromise(s.clear()));
    },

    // Einmalig beim allerersten Start: Stammdaten-Grunddaten importieren, damit
    // Dropdowns nicht leer sind (entspricht Migration 010_stammdaten_seed.sql).
    // local-api.js ruft das vor JEDEM /api-Aufruf auf - ein modulweiter
    // Promise-Lock verhindert, dass mehrere gleichzeitig gestartete Aufrufe
    // die Stammdaten doppelt importieren (Race Condition ohne Lock).
    ensureSeeded() {
      if (!this._seedPromise) {
        this._seedPromise = (async () => {
          const schonGesät = await this.get("meta", "stammdatenSeedV1");
          if (schonGesät) return;
          const vorhanden = await this.count("stammdaten");
          if (vorhanden === 0) {
            const res = await fetch("/js/local-data/stammdaten.seed.json");
            const zeilen = await res.json();
            await tx("stammdaten", "readwrite", (s) => {
              zeilen.forEach((z) => s.add({ typ: z.typ, bereich: z.bereich || "pflege", bezeichnung: z.bezeichnung, aktiv: true }));
            });
          }
          await this.put("meta", { key: "stammdatenSeedV1", value: true });
        })();
      }
      return this._seedPromise;
    }
  };

  window.LocalDB = LocalDB;
})();
