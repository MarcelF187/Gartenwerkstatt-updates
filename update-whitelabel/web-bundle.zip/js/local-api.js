// Lokales "Backend im Browser" für die server-lose App (Capacitor/Android).
//
// Patcht window.fetch: jede Anfrage an /api/... wird NICHT mehr ans Netz
// geschickt, sondern hier direkt aus IndexedDB (local-db.js) beantwortet - im
// exakt gleichen JSON-Format wie die echten Express-Routen, damit die
// bestehenden Seiten unverändert weiterlaufen.
//
// Wichtige Einschränkung: Nur JS-`fetch()`-Aufrufe werden abgefangen. Direkte
// Navigationen (window.open(url), <a href>) laufen am Service Worker vorbei
// an dieser Datei vorbei - für PDF/ICS-Downloads rufen die Seiten deshalb
// lokale Erzeuger (local-pdf.js) direkt auf statt über einen /api-Link zu
// navigieren (siehe dortige Kommentare).
(function () {
  "use strict";

  const originalFetch = window.fetch.bind(window);
  const D = () => window.LocalDB;

  function json(body, status) {
    return new Response(JSON.stringify(body), {
      status: status || 200,
      headers: { "Content-Type": "application/json" }
    });
  }

  function activeUser() {
    return (window.GOAuth && GOAuth.active) ? GOAuth.active() : null;
  }
  function role() { return String(activeUser()?.role || "mitarbeiter").toLowerCase(); }
  function isAdmin() { return role() === "admin"; }

  // Rollen/Berechtigungen sind jetzt vollständig matrixgetrieben (nur Admin
  // bleibt fest im Code) - Offline-Pendant zu backend/middleware/auth.js +
  // berechtigung.js. Damit isVerwalter() synchron bleiben kann (es wird an
  // ~30 Stellen ohne await genutzt), wird die Matrix der aktiven Rolle pro
  // /api-Request einmal in aktiveBerechtigungen gecacht (siehe handle()).
  // "Verwalter" einer Domäne = die Rolle darf in mind. einem Bereich der
  // Domäne bearbeiten (trennt "nur eigene" von "alle verwalten").
  const PFLEGE_BEREICHE = ["tagesberichte", "heckenschnitt", "baumlisten", "projekte", "notizen"];
  const BAU_BEREICHE = ["bautagesberichte", "lv_bau"];
  function bereicheFuerDomaene(domaene) {
    if (domaene === "pflege") return PFLEGE_BEREICHE;
    if (domaene === "bau") return BAU_BEREICHE;
    return [...PFLEGE_BEREICHE, ...BAU_BEREICHE];
  }

  let aktiveBerechtigungen = {}; // Matrix der aktuell aktiven Rolle (Cache)
  async function ladeAktiveBerechtigungen() {
    if (isAdmin()) { aktiveBerechtigungen = null; return; }
    try {
      const rolle = await D().get("rollen", role());
      aktiveBerechtigungen = (rolle && !rolle.deleted_at && rolle.berechtigungen) || {};
    } catch { aktiveBerechtigungen = {}; }
  }

  function isVerwalter(domaene) {
    if (isAdmin()) return true;
    const b = aktiveBerechtigungen || {};
    return bereicheFuerDomaene(domaene).some((ber) => b[ber] && b[ber].bearbeiten);
  }

  // Admin hat eine leere Matrix (fester Vollzugriff im Code) - beim Kopieren
  // von Admin als Ausgangspunkt wird deshalb eine volle Matrix über alle
  // Bereiche nachgebildet. Server-Pendant: backend/routes/rollen.routes.js.
  const ALLE_BEREICHE = [
    "mitarbeiter", "stammdaten", "urlaub", "tagesberichte", "bautagesberichte",
    "heckenschnitt", "baumlisten", "lv_bau", "projekte", "termine", "notizen",
    "statistik", "wlan_sync", "account"
  ];
  const VOLL = { ansehen: true, anlegen: true, bearbeiten: true, loeschen: true };
  const ADMIN_EFFEKTIVE_BERECHTIGUNGEN = Object.fromEntries(ALLE_BEREICHE.map((b) => [b, { ...VOLL }]));
  function hatBerechtigung(bereich, aktion) {
    if (isAdmin()) return true;
    const b = aktiveBerechtigungen || {};
    return !!(b[bereich] && b[bereich][aktion]);
  }
  async function istAdminOderBerechtigung(bereich, aktion) {
    return isAdmin() || (await hatBerechtigung(bereich, aktion));
  }
  async function istVerwalterOderBerechtigung(bereich, aktion) {
    return isAdmin() || (await hatBerechtigung(bereich, aktion));
  }

  // Autor-Auflösung wie backend/utils/offlineAutor.js: der aktive Nutzer,
  // ausser ein anderer bekannter Nutzername wurde explizit mitgeschickt
  // (Nutzerwechsel auf dem geteilten Tablet).
  async function ermittleAutor(erfasstVon) {
    const au = activeUser();
    const name = String(erfasstVon || "").trim();
    if (name && (!au || name.toLowerCase() !== String(au.username || "").toLowerCase())) {
      const users = await D().getAll("users");
      const hit = users.find((u) => String(u.username).toLowerCase() === name.toLowerCase() && u.is_active !== false);
      if (hit) return { id: hit.id, username: hit.username };
    }
    return au ? { id: au.id, username: au.username } : { id: 0, username: "unbekannt" };
  }

  function formatDatumDE(iso) {
    const p = String(iso || "").split("-");
    if (p.length !== 3) return String(iso || "").trim();
    const [y, m, d] = p;
    return `${d}.${m}.${y}`;
  }
  function buildBerichtNr(data, ersteller) {
    const datum = formatDatumDE(data?.datum) || "-";
    const name = String(ersteller || "").trim() || "-";
    return `TB ${name}, ${datum}`;
  }

  // ------------------------------------------------------- LAN-Sync-Stempel
  // Für den geräteübergreifenden WLAN-Sync (siehe public/js/lan-sync.js)
  // braucht jede Zeile der betroffenen Stores eine stabile client_uuid +
  // einen updated_at-Zeitstempel; Löschen passiert dort als Soft-Delete
  // (deleted_at) statt echtem Entfernen, damit eine Tombstone zum anderen
  // Gerät durchgereicht werden kann. Phase 1: kunden, baumlisten,
  // baumlisten_items, tagesberichte, heckenschnitt, termine, notizen. Phase 2:
  // users, stammdaten, projekte, bautagesberichte, lv_bau_projekte,
  // lv_bau_listen, lv_bau_items.
  function stampNeu(obj) {
    return { ...obj, client_uuid: obj.client_uuid || crypto.randomUUID(), updated_at: new Date().toISOString(), deleted_at: null };
  }
  function stampGeaendert(obj) {
    obj.updated_at = new Date().toISOString();
    return obj;
  }

  // Foto-Metadaten (notiz_bilder/heckenschnitt_bilder, siehe DB_VERSION 7 in
  // local-db.js) nehmen seit hier ebenfalls am WLAN-Sync teil - aber NUR die
  // Metadaten, nicht das "blob"-Feld selbst (siehe lan-sync.js: der
  // Bild-INHALT läuft über einen eigenen, getrennten Übertragungsschritt je
  // Foto statt im normalen JSON-Sync-Payload). stampBildGeloescht räumt
  // "blob" beim Löschen bewusst leer - der Tombstone (deleted_at) reicht für
  // den Sync, die oft mehrere hundert KB großen Bilddaten müssen dafür nicht
  // aufgehoben werden.
  function stampBildNeu(obj) {
    return { ...obj, client_uuid: crypto.randomUUID(), updated_at: new Date().toISOString(), deleted_at: null };
  }
  function stampBildGeloescht(obj) {
    return { ...obj, blob: null, deleted_at: new Date().toISOString(), updated_at: new Date().toISOString() };
  }

  // ---------------------------------------------------------------- Routing
  const ROUTES = [];
  function toRegex(path) {
    const re = path.replace(/:[a-zA-Z]+/g, (m) => `(?<${m.slice(1)}>[^/]+)`);
    return new RegExp(`^${re}$`);
  }
  function on(method, path, handler) { ROUTES.push({ method, pattern: toRegex(path), handler }); }
  const get = (p, h) => on("GET", p, h);
  const post = (p, h) => on("POST", p, h);
  const put = (p, h) => on("PUT", p, h);
  const patch = (p, h) => on("PATCH", p, h);
  const del = (p, h) => on("DELETE", p, h);

  async function bodyOf(request) {
    try { return await request.clone().json(); } catch { return {}; }
  }

  // ================================================================== AUTH
  // Kein Passwort, keine 2FA: auf einem vertrauenswürdigen Einzelgerät ist
  // "angemeldet" gleichbedeutend mit "ein lokaler Nutzer ist ausgewählt".
  get("/api/auth/me", async () => {
    const u = activeUser();
    if (!u) return json({ authenticated: false, user: null });
    // Effektive Rechte-Matrix mitgeben (Admin: null) - home.html blendet die
    // Kacheln danach ein, identisch zur Server-Version.
    const berechtigungen = isAdmin() ? null : (aktiveBerechtigungen || {});
    return json({ authenticated: true, user: { id: u.id, username: u.username, email: u.email || null, role: u.role, isActive: true, twoFactorEnabled: false, berechtigungen } });
  });
  post("/api/auth/login", async ({ request }) => {
    const body = await bodyOf(request);
    const identifier = String(body.identifier || body.username || "").trim();
    if (!identifier) return json({ error: "identifier_required" }, 400);
    const users = await D().getAll("users");
    const hit = users.find((u) => String(u.username).toLowerCase() === identifier.toLowerCase() && u.is_active !== false);
    if (!hit) return json({ error: "invalid_login" }, 401);
    GOAuth.remember(hit);
    return json({ ok: true, user: { id: hit.id, username: hit.username, email: hit.email || null, role: hit.role } });
  });
  post("/api/auth/logout", async () => json({ ok: true }));

  // ============================================== USERS (lokale Crew-Liste)
  // Nimmt seit Phase 2 (siehe public/js/lan-sync.js) am WLAN-Sync teil - die
  // Liste zeigt bewusst weiterhin gesperrte (is_active:false) Nutzer, damit
  // sie sich wieder freischalten lassen; nur echt gelöschte (Tombstone,
  // deleted_at) verschwinden komplett. Historische Namens-Auflösungen an
  // anderen Stellen dieser Datei (z.B. "erstellt_von_name") filtern deleted_at
  // absichtlich NICHT, damit alte Berichte weiterhin den Namen des damaligen
  // Erfassers zeigen.
  async function istGueltigeRolle(id) {
    if (!id) return false;
    const r = await D().get("rollen", id);
    return !!(r && !r.deleted_at);
  }
  // GET/POST bewusst OHNE Berechtigungsprüfung (anders als PUT/DELETE unten):
  // login.html erlaubt jedem unangemeldeten Nutzer ein Selbstbedienungs-Konto
  // ("+ Neuen Mitarbeiter anlegen" auf dem Login-Bildschirm, auch fürs allererste
  // Konto auf einem frischen Gerät), und tagesbericht.html liest/erweitert die
  // Mitarbeiterliste für JEDE angemeldete Rolle (Dropdown + automatisches
  // Anlegen unbekannter Namen im Team-Feld) - beides bewusst so, siehe
  // Kommentar am Dateianfang zum Einzelgeräte-Vertrauensmodell. Eine echte
  // Kontoverwaltung (Rolle ändern, sperren, löschen) bleibt unten mit PUT/DELETE
  // admin-gated, die werden ausschliesslich von admin/mitarbeiter.html genutzt.
  get("/api/users", async () => {
    const users = (await D().getAll("users")).filter((u) => !u.deleted_at);
    return json({ ok: true, users: users.map((u) => ({ id: u.id, username: u.username, email: u.email || null, role: u.role, is_active: u.is_active !== false, created_at: u.created_at, urlaubsanspruch_tage: u.urlaubsanspruch_tage ?? 30 })) });
  });
  post("/api/users", async ({ request }) => {
    const body = await bodyOf(request);
    const username = String(body.username || "").trim();
    if (!username) return json({ error: "username_required" }, 400);
    const users = (await D().getAll("users")).filter((u) => !u.deleted_at);
    if (users.some((u) => u.username.toLowerCase() === username.toLowerCase())) return json({ error: "username_or_email_taken" }, 409);
    const rolle = (await istGueltigeRolle(body.role)) ? body.role : "mitarbeiter";
    const urlaubsanspruchTage = Number.isFinite(Number(body.urlaubsanspruch_tage)) ? Number(body.urlaubsanspruch_tage) : 30;
    const rec = await D().add("users", stampNeu({ username, email: body.email || null, role: rolle, is_active: true, created_at: new Date().toISOString(), urlaubsanspruch_tage: urlaubsanspruchTage }));
    return json({ ok: true, user: rec });
  });
  put("/api/users/:id", async ({ params, request }) => {
    if (!(await istAdminOderBerechtigung("mitarbeiter", "bearbeiten"))) return json({ error: "forbidden_admin" }, 403);
    const u = await D().get("users", Number(params.id));
    if (!u || u.deleted_at) return json({ error: "user_not_found" }, 404);
    const body = await bodyOf(request);
    if (body.role !== undefined) u.role = (await istGueltigeRolle(body.role)) ? body.role : "mitarbeiter";
    if (body.is_active !== undefined) u.is_active = !!body.is_active;
    if (body.urlaubsanspruch_tage !== undefined) {
      const tage = Number(body.urlaubsanspruch_tage);
      if (!Number.isFinite(tage) || tage < 0) return json({ error: "invalid_urlaubsanspruch_tage" }, 400);
      u.urlaubsanspruch_tage = tage;
    }
    stampGeaendert(u);
    await D().put("users", u);
    return json({ ok: true, user: u });
  });
  // Soft-Delete (Tombstone für den WLAN-Sync) statt echtem Entfernen - setzt
  // gleichzeitig is_active=false, damit Login/Autor-Zuordnung (die das Feld
  // ohnehin schon prüfen) den gelöschten Nutzer automatisch mit ausschließen.
  del("/api/users/:id", async ({ params }) => {
    if (!(await istAdminOderBerechtigung("mitarbeiter", "loeschen"))) return json({ error: "forbidden_admin" }, 403);
    const u = await D().get("users", Number(params.id));
    if (!u || u.deleted_at) return json({ error: "user_not_found" }, 404);
    u.deleted_at = new Date().toISOString();
    u.is_active = false;
    stampGeaendert(u);
    await D().put("users", u);
    return json({ ok: true });
  });

  // ============================================================ STAMMDATEN
  const VALID_TYPEN = ["taetigkeit", "material_lieferung", "material_abfuhr", "maschine"];
  const VALID_BEREICHE = ["pflege", "bau"];
  get("/api/stammdaten", async ({ url }) => {
    const typ = url.searchParams.get("typ");
    const bereich = url.searchParams.get("bereich");
    if (typ && !VALID_TYPEN.includes(typ)) return json({ error: "invalid_typ" }, 400);
    if (bereich && !VALID_BEREICHE.includes(bereich)) return json({ error: "invalid_bereich" }, 400);
    let rows = (await D().getAll("stammdaten")).filter((r) => r.aktiv !== false && !r.deleted_at);
    if (typ) rows = rows.filter((r) => r.typ === typ);
    if (bereich) rows = rows.filter((r) => (r.bereich || "pflege") === bereich);
    rows.sort((a, b) => a.bezeichnung.localeCompare(b.bezeichnung, "de"));
    return json({ ok: true, stammdaten: rows });
  });
  post("/api/stammdaten", async ({ request }) => {
    if (!(await istAdminOderBerechtigung("stammdaten", "anlegen"))) return json({ error: "forbidden_admin" }, 403);
    const body = await bodyOf(request);
    const typ = String(body.typ || "");
    const bereich = String(body.bereich || "pflege");
    const bezeichnung = String(body.bezeichnung || "").trim();
    if (!VALID_TYPEN.includes(typ)) return json({ error: "invalid_typ" }, 400);
    if (!VALID_BEREICHE.includes(bereich)) return json({ error: "invalid_bereich" }, 400);
    if (!bezeichnung) return json({ error: "bezeichnung_required" }, 400);
    const rec = await D().add("stammdaten", stampNeu({ typ, bereich, bezeichnung, aktiv: true }));
    return json({ ok: true, item: rec });
  });
  put("/api/stammdaten/:id", async ({ params, request }) => {
    if (!(await istAdminOderBerechtigung("stammdaten", "bearbeiten"))) return json({ error: "forbidden_admin" }, 403);
    const item = await D().get("stammdaten", Number(params.id));
    if (!item || item.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    if (body.bezeichnung !== undefined) item.bezeichnung = String(body.bezeichnung).trim();
    if (body.aktiv !== undefined) item.aktiv = !!body.aktiv;
    if (body.bereich !== undefined) {
      if (!VALID_BEREICHE.includes(body.bereich)) return json({ error: "invalid_bereich" }, 400);
      item.bereich = body.bereich;
    }
    stampGeaendert(item);
    await D().put("stammdaten", item);
    return json({ ok: true, item });
  });
  del("/api/stammdaten/:id", async ({ params }) => {
    if (!(await istAdminOderBerechtigung("stammdaten", "loeschen"))) return json({ error: "forbidden_admin" }, 403);
    const id = Number(params.id);
    const item = await D().get("stammdaten", id);
    if (!item || item.deleted_at) return json({ error: "not_found" }, 404);
    item.deleted_at = new Date().toISOString();
    stampGeaendert(item);
    await D().put("stammdaten", item);
    return json({ ok: true });
  });

  // ============================================ TAGESBERICHTE / BAUTAGESBERICHTE
  // Beide Berichtsarten funktionieren identisch (data-JSON + generierte
  // bericht_nr) - eine Factory erzeugt die Routen für beide Stores.
  function registerBerichteRoutes(store, basePath, { offlineFelder, bereich }) {
    post(basePath, async ({ request }) => {
      const body = await bodyOf(request);
      const { client_uuid, erfasst_von, ...data } = body;

      if (offlineFelder && client_uuid) {
        const alle = await D().getAll(store);
        const vorhanden = alle.find((r) => r.client_uuid === client_uuid);
        if (vorhanden) return json({ ok: true, id: vorhanden.id, bericht_nr: vorhanden.bericht_nr, dedupe: true });
      }

      const autor = offlineFelder ? await ermittleAutor(erfasst_von) : (activeUser() || { id: 0, username: "unbekannt" });
      const baseBerichtNr = buildBerichtNr(data, autor.username);

      const alle = await D().getAll(store);
      let berichtNr = baseBerichtNr;
      let versuch = 0;
      while (alle.some((r) => r.bericht_nr === berichtNr) && versuch < 5) {
        versuch++;
        berichtNr = `${baseBerichtNr} (${versuch + 1})`;
      }

      const rec = await D().add(store, {
        data, bericht_nr: berichtNr, created_by: autor.id,
        created_at: new Date().toISOString(), updated_at: new Date().toISOString(),
        pdf_content: null,
        // client_uuid nie leer lassen: sonst ist der Bericht für den
        // WLAN-Sync (siehe public/js/lan-sync.js) unsichtbar. Seit Phase 2
        // gilt das für tagesberichte UND bautagesberichte gleichermaßen
        // (offlineFelder ist für beide true).
        ...(offlineFelder ? { client_uuid: client_uuid || crypto.randomUUID(), deleted_at: null } : {})
      });
      return json({ ok: true, id: rec.id, bericht_nr: rec.bericht_nr });
    });

    get(basePath, async () => {
      const au = activeUser();
      let rows = (await D().getAll(store)).filter((r) => !r.deleted_at);
      if (!isVerwalter(bereich)) rows = rows.filter((r) => r.created_by === au?.id);
      rows.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
      const users = await D().getAll("users");
      const list = rows.map((r) => ({
        id: r.id, bericht_nr: r.bericht_nr, created_at: r.created_at,
        baustelle: r.data?.baustelle || "", datum: r.data?.datum || "",
        created_by: users.find((u) => u.id === r.created_by)?.username || ""
      }));
      return json({ ok: true, berichte: list });
    });

    get(`${basePath}/:id`, async ({ params }) => {
      const r = await D().get(store, Number(params.id));
      if (!r || r.deleted_at) return json({ ok: false, error: "not_found" }, 404);
      const au = activeUser();
      if (!isVerwalter(bereich) && r.created_by !== au?.id) return json({ ok: false, error: "forbidden" }, 403);
      return json({ ok: true, data: r.data, bericht_nr: r.bericht_nr, created_at: r.created_at });
    });

    put(`${basePath}/:id`, async ({ params, request }) => {
      const r = await D().get(store, Number(params.id));
      if (!r) return json({ ok: false, error: "not_found" }, 404);
      const au = activeUser();
      if (!isVerwalter(bereich) && r.created_by !== au?.id) return json({ ok: false, error: "forbidden" }, 403);
      r.data = await bodyOf(request);
      r.updated_at = new Date().toISOString();
      await D().put(store, r);
      return json({ ok: true, id: r.id });
    });

    del(`${basePath}/:id`, async ({ params }) => {
      if (!isVerwalter(bereich)) return json({ ok: false, error: "forbidden_vorarbeiter" }, 403);
      const id = Number(params.id);
      const r = await D().get(store, id);
      if (!r || r.deleted_at) return json({ ok: false, error: "not_found" }, 404);
      if (offlineFelder) {
        // Soft-Delete: Tombstone für den WLAN-Sync (nur tagesberichte, siehe
        // public/js/lan-sync.js) - ein echtes delete() würde bei einem
        // Nebengerät, das den Bericht noch hat, beim nächsten Abgleich
        // unbeabsichtigt wieder auftauchen.
        r.deleted_at = new Date().toISOString();
        r.updated_at = r.deleted_at;
        await D().put(store, r);
      } else {
        await D().delete(store, id);
      }
      return json({ ok: true });
    });

    // Nur den Baustellen-Namen ändern (Sammel-Umbenennung, siehe
    // admin/berichte.html) - Rest der Berichtsdaten bleibt unangetastet.
    patch(`${basePath}/:id/baustelle`, async ({ params, request }) => {
      if (!isVerwalter(bereich)) return json({ ok: false, error: "forbidden_vorarbeiter" }, 403);
      const r = await D().get(store, Number(params.id));
      if (!r) return json({ ok: false, error: "not_found" }, 404);
      const body = await bodyOf(request);
      const baustelle = String(body?.baustelle || "").trim();
      if (!baustelle) return json({ ok: false, error: "baustelle_required" }, 400);
      r.data = { ...r.data, baustelle };
      r.updated_at = new Date().toISOString();
      await D().put(store, r);
      return json({ ok: true, id: r.id });
    });

    // PDF wird nicht über diese Route erzeugt (siehe local-pdf.js) - hier nur
    // ein Platzhalter, damit Seiten, die trotzdem darüber fetchen, keinen
    // harten Fehler bekommen.
    post(`${basePath}/:id/pdf`, async ({ params }) => {
      const r = await D().get(store, Number(params.id));
      if (!r) return json({ ok: false, error: "not_found" }, 404);
      return json({ ok: true, filename: `${r.bericht_nr}.pdf`, hinweis: "PDF wird lokal über LocalPdf erzeugt" });
    });
  }
  registerBerichteRoutes("tagesberichte", "/api/tagesberichte", { offlineFelder: true, bereich: "pflege" });
  // offlineFelder war bis Phase 2 des WLAN-Syncs (siehe public/js/lan-sync.js)
  // false, weil Bautagesberichte noch nicht am Sync teilnahmen - der Store
  // hatte den client_uuid-Index aber schon immer (siehe local-db.js), nur nie
  // befüllte Werte.
  registerBerichteRoutes("bautagesberichte", "/api/bautagesberichte", { offlineFelder: true, bereich: "bau" });

  // ============================================================ HECKENSCHNITT
  function normalisiereSeiten(wert) {
    const n = Number(wert);
    return [1, 2, 3].includes(n) ? n : null;
  }
  get("/api/heckenschnitt/kunden", async () => {
    const rows = (await D().getAll("heckenschnitt")).filter((r) => !r.deleted_at);
    const kunden = [...new Set(rows.map((r) => r.kunde))].sort((a, b) => a.localeCompare(b, "de"));
    return json({ ok: true, kunden });
  });
  get("/api/heckenschnitt", async ({ url }) => {
    const datum = url.searchParams.get("datum");
    const users = await D().getAll("users");
    const bilder = await D().getAll("heckenschnitt_bilder");
    let rows = (await D().getAll("heckenschnitt")).filter((r) => !r.deleted_at);
    if (datum) rows = rows.filter((r) => r.datum === datum);
    rows.sort((a, b) => new Date(b.erstellt_am) - new Date(a.erstellt_am));
    rows = rows.map((r) => ({
      ...r,
      erstellt_von_name: users.find((u) => u.id === r.erstellt_von)?.username || "",
      vorher_anzahl: bilder.filter((b) => b.eintrag_id === r.id && b.typ === "vorher" && !b.deleted_at).length,
      nachher_anzahl: bilder.filter((b) => b.eintrag_id === r.id && b.typ === "nachher" && !b.deleted_at).length
    }));
    return json({ ok: true, eintraege: rows });
  });
  post("/api/heckenschnitt", async ({ request }) => {
    const body = await bodyOf(request);
    const kunde = String(body.kunde || "").trim();
    if (!kunde) return json({ error: "kunde_required" }, 400);
    if (body.client_uuid) {
      const alle = await D().getAll("heckenschnitt");
      const vorhanden = alle.find((r) => r.client_uuid === body.client_uuid);
      if (vorhanden) return json({ ok: true, eintrag: vorhanden, dedupe: true });
    }
    const autor = await ermittleAutor(body.erfasst_von);
    const rec = await D().add("heckenschnitt", {
      kunde, heckenart: String(body.heckenart || "").trim(),
      laenge: Number(body.laenge) || null, breite: Number(body.breite) || null, hoehe: Number(body.hoehe) || null,
      dauer: Number(body.dauer) || 0, datum: body.datum || new Date().toISOString().slice(0, 10),
      seiten: normalisiereSeiten(body.seiten), anmerkung: String(body.anmerkung || "").trim() || null,
      erstellt_von: autor.id, erstellt_am: new Date().toISOString(),
      client_uuid: body.client_uuid || crypto.randomUUID(), updated_at: new Date().toISOString(), deleted_at: null
    });
    return json({ ok: true, eintrag: rec });
  });
  put("/api/heckenschnitt/:id", async ({ params, request }) => {
    if (!isVerwalter("pflege")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const r = await D().get("heckenschnitt", Number(params.id));
    if (!r || r.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    const kunde = String(body.kunde || "").trim();
    if (!kunde) return json({ error: "kunde_required" }, 400);
    Object.assign(r, {
      kunde, heckenart: String(body.heckenart || "").trim(),
      laenge: Number(body.laenge) || null, breite: Number(body.breite) || null, hoehe: Number(body.hoehe) || null,
      dauer: Number(body.dauer) || 0, datum: body.datum || new Date().toISOString().slice(0, 10),
      seiten: normalisiereSeiten(body.seiten), anmerkung: String(body.anmerkung || "").trim() || null
    });
    stampGeaendert(r);
    await D().put("heckenschnitt", r);
    return json({ ok: true, eintrag: r });
  });
  // Soft-Delete (Tombstone für den WLAN-Sync, siehe public/js/lan-sync.js) -
  // kaskadiert als Soft-Delete auf die zugehörigen Fotos (nehmen seit
  // DB_VERSION 7 selbst am Sync teil, siehe stampBildGeloescht oben).
  del("/api/heckenschnitt/:id", async ({ params }) => {
    if (!isVerwalter("pflege")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const id = Number(params.id);
    const r = await D().get("heckenschnitt", id);
    if (!r || r.deleted_at) return json({ error: "not_found" }, 404);
    const bilder = await D().getAll("heckenschnitt_bilder");
    for (const b of bilder.filter((x) => x.eintrag_id === id && !x.deleted_at)) await D().put("heckenschnitt_bilder", stampBildGeloescht(b));
    r.deleted_at = new Date().toISOString();
    stampGeaendert(r);
    await D().put("heckenschnitt", r);
    return json({ ok: true });
  });
  del("/api/heckenschnitt", async () => {
    if (!isVerwalter("pflege")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const bilder = await D().getAll("heckenschnitt_bilder");
    for (const b of bilder.filter((x) => !x.deleted_at)) await D().put("heckenschnitt_bilder", stampBildGeloescht(b));
    const alle = (await D().getAll("heckenschnitt")).filter((r) => !r.deleted_at);
    for (const r of alle) {
      r.deleted_at = new Date().toISOString();
      stampGeaendert(r);
      await D().put("heckenschnitt", r);
    }
    return json({ ok: true });
  });

  // Vorher-/Nachher-Fotos zu Heckenschnitt-Einträgen - gleiches Muster wie die
  // Notiz-Fotos weiter unten (dataUrlZuBlob), Hochladen ist bewusst für jeden
  // angemeldeten Nutzer offen (nicht nur Vorarbeiter/Admin), damit Fotos direkt
  // bei der Neuanlage eines Eintrags angehängt werden können; Löschen bleibt
  // wie das Bearbeiten des Eintrags selbst Vorarbeitern/Admins vorbehalten.
  get("/api/heckenschnitt/:eintragId/bilder", async ({ params }) => {
    const eintragId = Number(params.eintragId);
    const rows = (await D().getAll("heckenschnitt_bilder")).filter((b) => b.eintrag_id === eintragId && !b.deleted_at)
      .map((b) => ({ id: b.id, eintrag_id: b.eintrag_id, typ: b.typ, erstellt_am: b.erstellt_am }))
      .sort((a, b) => a.erstellt_am.localeCompare(b.erstellt_am));
    return json({ ok: true, bilder: rows });
  });
  post("/api/heckenschnitt/:eintragId/bilder", async ({ params, request }) => {
    const eintragId = Number(params.eintragId);
    const e = await D().get("heckenschnitt", eintragId);
    if (!e) return json({ error: "eintrag_not_found" }, 404);
    const body = await bodyOf(request);
    const blob = dataUrlZuBlob(body.bild);
    if (!blob) return json({ error: "bild_required" }, 400);
    if (blob.size > 5 * 1024 * 1024) return json({ error: "bild_zu_gross" }, 413);
    const typ = body.typ === "nachher" ? "nachher" : "vorher";
    const rec = await D().add("heckenschnitt_bilder", stampBildNeu({ eintrag_id: eintragId, typ, blob, erstellt_am: new Date().toISOString() }));
    return json({ ok: true, bild: { id: rec.id, eintrag_id: rec.eintrag_id, typ: rec.typ, erstellt_am: rec.erstellt_am } });
  });
  get("/api/heckenschnitt/bilder/:id", async ({ params }) => {
    const b = await D().get("heckenschnitt_bilder", Number(params.id));
    // "blob" fehlt auch kurzzeitig bei einer per WLAN-Sync gerade erst
    // eingetroffenen Foto-Zeile, deren Bild-Inhalt noch nicht nachgeladen
    // wurde (siehe lan-sync.js) - fuer die Anzeige nicht unterscheidbar von
    // "gibt es nicht", daher hier bewusst derselbe 404.
    if (!b || b.deleted_at || !b.blob) return json({ error: "not_found" }, 404);
    return new Response(b.blob, { status: 200, headers: { "Content-Type": "image/jpeg" } });
  });
  del("/api/heckenschnitt/bilder/:id", async ({ params }) => {
    if (!isVerwalter("pflege")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const b = await D().get("heckenschnitt_bilder", Number(params.id));
    if (!b || b.deleted_at) return json({ error: "not_found" }, 404);
    await D().put("heckenschnitt_bilder", stampBildGeloescht(b));
    return json({ ok: true });
  });

  // ================================================================ PROJEKTE
  // Gemeinsame Fortschritts-Berechnung für Pflege-Projekte/Listen (ersetzt die
  // SQL-Aggregation total/erledigt aus baumlisten.routes.js/projekte.routes.js).
  function pflegelisteFortschritt(items) {
    let total = 0, erledigt = 0;
    for (const item of items) {
      const isHeader = /^\d+\.\d+$/.test(String(item.auftragsnummer || ""));
      if (isHeader || item.nur_position) continue;
      const pg = Array.isArray(item.pflegegaenge) ? item.pflegegaenge : [];
      for (const e of pg) {
        if (e && typeof e === "object" && e.na) continue;
        total++;
        if (e && typeof e === "object" && String(e.datum || "") !== "") erledigt++;
      }
    }
    return { total, erledigt };
  }
  async function projekteMitFortschritt(store, itemStore, indexName) {
    const projekte = (await D().getAll(store)).filter((p) => !p.deleted_at);
    const listen = (await D().getAll(itemStore === "baumlisten_items" ? "baumlisten" : "lv_bau_listen")).filter((l) => !l.deleted_at);
    const items = (await D().getAll(itemStore)).filter((i) => !i.deleted_at);
    const users = await D().getAll("users");
    return projekte.map((p) => {
      const eigeneListen = listen.filter((l) => l.projekt_id === p.id);
      let total = 0, erledigt = 0;
      for (const l of eigeneListen) {
        const listItems = items.filter((i) => i.liste_id === l.id);
        if (itemStore === "baumlisten_items") {
          const f = pflegelisteFortschritt(listItems);
          total += f.total; erledigt += f.erledigt;
        } else {
          total += listItems.length;
          erledigt += listItems.filter((i) => i.erledigt).length;
        }
      }
      return {
        ...p, erstellt_von_name: users.find((u) => u.id === p.erstellt_von)?.username || "",
        listen_anzahl: eigeneListen.length, items_gesamt: total, items_erledigt: erledigt
      };
    }).sort((a, b) => a.name.localeCompare(b.name, "de"));
  }
  get("/api/projekte", async () => json({ ok: true, projekte: await projekteMitFortschritt("projekte", "baumlisten_items") }));
  get("/api/projekte/:id", async ({ params }) => {
    const id = Number(params.id);
    const p = await D().get("projekte", id);
    if (!p || p.deleted_at) return json({ error: "not_found" }, 404);
    const listen = (await D().getAll("baumlisten")).filter((l) => !l.deleted_at && l.projekt_id === id);
    const items = (await D().getAll("baumlisten_items")).filter((i) => !i.deleted_at);
    const listenMitFortschritt = listen.map((l) => ({ ...l, ...pflegelisteFortschritt(items.filter((i) => i.liste_id === l.id)) }))
      .sort((a, b) => new Date(b.erstellt_am) - new Date(a.erstellt_am));
    return json({ ok: true, projekt: p, listen: listenMitFortschritt });
  });
  post("/api/projekte", async ({ request }) => {
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);
    const au = activeUser();
    const rec = await D().add("projekte", stampNeu({ name, beschreibung: body.beschreibung || null, erstellt_von: au?.id || 0, erstellt_am: new Date().toISOString() }));
    return json({ ok: true, projekt: rec });
  });
  put("/api/projekte/:id", async ({ params, request }) => {
    const p = await D().get("projekte", Number(params.id));
    if (!p || p.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);
    p.name = name; p.beschreibung = body.beschreibung || null;
    stampGeaendert(p);
    await D().put("projekte", p);
    return json({ ok: true, projekt: p });
  });
  // Soft-Delete (Tombstone für den WLAN-Sync) statt echtem Entfernen - wie bei
  // baumlisten bleibt eine bereits zugeordnete Pflegeliste dabei bewusst ohne
  // automatische Kaskade (schon vor Phase 2 so, siehe baumlisten.projekt_id).
  del("/api/projekte/:id", async ({ params }) => {
    if (!isVerwalter("pflege")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const id = Number(params.id);
    const p = await D().get("projekte", id);
    if (!p || p.deleted_at) return json({ error: "not_found" }, 404);
    p.deleted_at = new Date().toISOString();
    stampGeaendert(p);
    await D().put("projekte", p);
    return json({ ok: true });
  });

  // =============================================================== BAUMLISTEN
  const NA_PATTERN = /^(n\/?a|k\.?a\.?|keine?|none|null|nil|-+|x+)$/i;
  function toPflegegangObjects(dates) {
    return (Array.isArray(dates) ? dates : []).map((d) => {
      if (d && typeof d === "object") {
        const v = String(d.datum ?? "").trim();
        if (!v) return null;
        if (NA_PATTERN.test(v)) return { na: true };
        const erledigt = !!d.erledigt;
        return { datum: v, erledigt, erledigt_von: null, erledigt_am: erledigt ? new Date().toISOString() : null, ...(d.farbe === "rot" ? { farbe: "rot" } : {}) };
      }
      const v = String(d == null ? "" : d).trim();
      if (!v) return null;
      if (NA_PATTERN.test(v)) return { na: true };
      return { datum: v, erledigt: false, erledigt_von: null, erledigt_am: null };
    });
  }
  const ITEM_FIELDS = ["auftragsnummer", "liegenschaft", "beschreibung", "menge", "einheit"];
  async function insertBaumlistenItems(listeId, items) {
    for (const item of items) {
      const rec = { liste_id: listeId };
      ITEM_FIELDS.forEach((f) => { rec[f] = String(item[f] || "").trim(); });
      rec.pflegegaenge = toPflegegangObjects(item.pflegegaenge);
      rec.info = item.info || null;
      rec.lat = null; rec.lon = null; rec.geo_quelle = null;
      rec.prioritaet = false;
      rec.nur_position = !!item.nur_position;
      await D().add("baumlisten_items", stampNeu(rec));
    }
  }

  get("/api/baumlisten", async () => {
    const listen = (await D().getAll("baumlisten")).filter((l) => !l.deleted_at);
    const items = (await D().getAll("baumlisten_items")).filter((i) => !i.deleted_at);
    const users = await D().getAll("users");
    const projekte = await D().getAll("projekte");
    const out = listen.map((l) => ({
      ...l,
      erstellt_von_name: users.find((u) => u.id === l.erstellt_von)?.username || "",
      projekt_name: projekte.find((p) => p.id === l.projekt_id)?.name || null,
      ...pflegelisteFortschritt(items.filter((i) => i.liste_id === l.id))
    })).sort((a, b) => new Date(b.erstellt_am) - new Date(a.erstellt_am));
    return json({ ok: true, listen: out });
  });

  get("/api/baumlisten/rot-markiert", async ({ url }) => {
    const datum = url.searchParams.get("datum") || "";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(datum)) return json({ error: "invalid_date" }, 400);
    const [jahr, monat, tag] = datum.split("-");
    const datumDE = `${tag}.${monat}.${jahr}`;
    const projektId = url.searchParams.get("projekt_id") ? Number(url.searchParams.get("projekt_id")) : null;
    const listen = (await D().getAll("baumlisten")).filter((l) => !l.deleted_at);
    const items = (await D().getAll("baumlisten_items")).filter((i) => !i.deleted_at);
    const treffer = items.filter((i) => {
      const liste = listen.find((l) => l.id === i.liste_id);
      if (!liste) return false;
      if (Number.isFinite(projektId) && liste.projekt_id !== projektId) return false;
      return (i.pflegegaenge || []).some((e) => {
        if (!e || typeof e !== "object" || e.farbe !== "rot") return false;
        if (e.datum === datumDE) return true;
        const weitere = Array.isArray(e.weitere_termine) ? e.weitere_termine : [];
        return weitere.some((w) => (w && typeof w === "object" ? w.datum : w) === datumDE);
      });
    }).map((i) => ({ id: i.id, liste_id: i.liste_id, auftragsnummer: i.auftragsnummer, liegenschaft: i.liegenschaft, beschreibung: i.beschreibung, menge: i.menge, einheit: i.einheit, info: i.info, liste_name: listen.find((l) => l.id === i.liste_id)?.name }));

    // Klassische Listen: Straßenname der vorangehenden Trennzeile nachschlagen
    // (siehe Server-Route) - liegenschaft/beschreibung der Position selbst
    // sind meist leer, der Straßenname steht nur im Header.
    const listenIds = [...new Set(treffer.filter((r) => !r.info).map((r) => r.liste_id))];
    const strassenMap = new Map();
    for (const listeId of listenIds) {
      const alle = items.filter((i) => i.liste_id === listeId).sort((a, b) => a.id - b.id);
      for (const [itemId, ortsangabe] of ordneStrassenZu(alle)) strassenMap.set(itemId, ortsangabe);
    }
    for (const r of treffer) {
      r.strasse = strassenMap.get(r.id)?.strasse || "";
      r.stadtteil = strassenMap.get(r.id)?.stadtteil || r.liegenschaft || "";
    }

    // Generische Listen (z.B. Wässerliste): der Pflegetermin steht nur auf der
    // Hauptposition (Sammelzeile, nur_position=false) - die einzelnen damit
    // "verketteten" Unterpositionen (gleiche Hauptposition, nur_position=true,
    // z.B. einzelne Bäume/Standorte) tragen selbst keinen Termin und tauchen
    // deshalb sonst gar nicht in der Übernahme auf. Hier zusätzlich einsammeln,
    // damit im Tagesbericht sichtbar wird, was konkret dazugehört (siehe
    // Server-Route baumlisten.routes.js für dasselbe Vorgehen).
    for (const r of treffer) {
      if (!r.info) { r.unterpositionen = []; continue; }
      // Feldnamen aus spalten_config.infoFelder (nicht Object.keys(r.info)) -
      // hält das mit der Server-Route deckungsgleich, siehe dortiger Kommentar.
      const felder = listen.find((l) => l.id === r.liste_id)?.spalten_config?.infoFelder || [];
      const hauptFeld = felder[0], unterFeld = felder[1];
      if (!hauptFeld || !unterFeld) { r.unterpositionen = []; continue; }
      const hauptWert = String(r.info[hauptFeld] || "").trim();
      r.unterpositionen = items
        .filter((i) => i.liste_id === r.liste_id && i.nur_position && String(i.info?.[hauptFeld] || "").trim() === hauptWert)
        .map((i) => String(i.info?.[unterFeld] || "").trim())
        .filter(Boolean);
    }
    return json({ ok: true, items: treffer });
  });

  get("/api/baumlisten/karte-punkte", async () => {
    const listen = (await D().getAll("baumlisten")).filter((l) => !l.deleted_at);
    const items = (await D().getAll("baumlisten_items")).filter((i) => !i.deleted_at && i.lat != null && i.lon != null);
    const punkte = items.map((r) => {
      const pg = Array.isArray(r.pflegegaenge) ? r.pflegegaenge : [];
      let hatTermin = false, offen = false;
      for (const e of pg) {
        if (!e || typeof e !== "object" || e.na) continue;
        const besuche = [e, ...(Array.isArray(e.weitere_termine) ? e.weitere_termine : [])];
        for (const b of besuche) {
          const datum = typeof b === "string" ? b : b?.datum;
          if (!datum) continue;
          hatTermin = true;
          if (!(typeof b === "object" && b?.erledigt)) offen = true;
        }
      }
      return {
        id: r.id, liste_id: r.liste_id, liste_name: listen.find((l) => l.id === r.liste_id)?.name,
        position: r.auftragsnummer, stadtteil: r.liegenschaft, leistung: String(r.beschreibung || "").slice(0, 140),
        lat: Number(r.lat), lon: Number(r.lon), status: !hatTermin ? "ohne" : offen ? "offen" : "erledigt"
      };
    });
    return json({ ok: true, punkte });
  });

  // Priorisierte Positionen (Stern in der Pflegeliste) - eine priorisierte
  // Straßen-/Stadtteil-Überschrift bringt automatisch ihre Unterpositionen
  // mit, genau wie beim echten Server (siehe baumlisten.routes.js).
  function istGenerischeListeServer(liste) {
    return !!(liste?.spalten_config?.infoFelder?.length);
  }
  function istHeaderAuftragsnummer(wert) {
    return /^\d+\.\d+$/.test(String(wert || "").trim());
  }
  get("/api/baumlisten/prioritaet/gruppen", async () => {
    const listen = (await D().getAll("baumlisten")).filter((l) => !l.deleted_at);
    const alleItems = (await D().getAll("baumlisten_items")).filter((i) => !i.deleted_at);
    const projekte = await D().getAll("projekte");
    const prioItems = alleItems.filter((i) => i.prioritaet).sort((a, b) => (a.liste_id - b.liste_id) || (a.id - b.id));

    const gruppen = prioItems.map((prioItem) => {
      const liste = listen.find((l) => l.id === prioItem.liste_id);
      const meta = {
        liste_id: prioItem.liste_id,
        liste_name: liste?.name || "",
        projekt_name: projekte.find((p) => p.id === liste?.projekt_id)?.name || null,
        spalten_config: liste?.spalten_config || null
      };
      const generisch = istGenerischeListeServer(liste);
      const istHeader = !generisch && istHeaderAuftragsnummer(prioItem.auftragsnummer);

      if (!istHeader) {
        // Straßennamen der vorangehenden Trennzeile nachschlagen (siehe
        // Server-Route) - sonst zeigt eine einzeln priorisierte Position nur
        // ihre nackte Positionsnummer.
        let vorherigerHeader = null;
        if (!generisch) {
          vorherigerHeader = alleItems
            .filter((i) => i.liste_id === prioItem.liste_id && i.id < prioItem.id && istHeaderAuftragsnummer(i.auftragsnummer))
            .sort((a, b) => b.id - a.id)[0] || null;
        }
        return { ...meta, header: null, vorherigerHeader, items: [prioItem] };
      }

      const kinder = [];
      for (const it of alleItems
        .filter((i) => i.liste_id === prioItem.liste_id && i.id > prioItem.id)
        .sort((a, b) => a.id - b.id)) {
        if (istHeaderAuftragsnummer(it.auftragsnummer)) break;
        kinder.push(it);
      }
      return { ...meta, header: prioItem, items: kinder };
    });

    return json({ ok: true, gruppen });
  });
  patch("/api/baumlisten/:id/items/:itemId/prioritaet", async ({ params, request }) => {
    if (!isVerwalter("pflege")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const item = await D().get("baumlisten_items", Number(params.itemId));
    if (!item || item.liste_id !== Number(params.id)) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    item.prioritaet = !!body.prioritaet;
    stampGeaendert(item);
    await D().put("baumlisten_items", item);
    return json({ ok: true, item: { id: item.id, prioritaet: item.prioritaet } });
  });
  patch("/api/baumlisten/:id/items/:itemId/nur-position", async ({ params, request }) => {
    if (!isVerwalter("pflege")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const item = await D().get("baumlisten_items", Number(params.itemId));
    if (!item || item.liste_id !== Number(params.id)) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    item.nur_position = !!body.nur_position;
    stampGeaendert(item);
    await D().put("baumlisten_items", item);
    return json({ ok: true, item: { id: item.id, nur_position: item.nur_position } });
  });

  // ---------------------------------------------------------- Geocoding
  // Adress-Geocoding über Nominatim (OpenStreetMap) - ruft bei Bedarf echtes
  // Internet vom Gerät ab, genau wie früher der Server. 1:1 aus
  // backend/utils/geocoding.js portiert. "User-Agent" darf im Browser/WebView
  // per fetch() nicht gesetzt werden (verbotener Header) - das ist unkritisch,
  // Nominatim bekommt stattdessen den Standard-UA des Geräts.
  const NOMINATIM_URL = "https://nominatim.openstreetmap.org/search";
  const NOMINATIM_MIN_ABSTAND_MS = 1100;
  let nominatimLetzteAnfrage = 0;
  async function nominatimWarteAufSlot() {
    const wartezeit = Math.max(0, nominatimLetzteAnfrage + NOMINATIM_MIN_ABSTAND_MS - Date.now());
    if (wartezeit > 0) await new Promise((r) => setTimeout(r, wartezeit));
    nominatimLetzteAnfrage = Date.now();
  }
  async function geocodeAdresse(adresse, viewbox) {
    await nominatimWarteAufSlot();
    let url = `${NOMINATIM_URL}?q=${encodeURIComponent(adresse)}&format=json&limit=1&countrycodes=de`;
    if (viewbox) url += `&viewbox=${viewbox}&bounded=0`;
    const res = await originalFetch(url, { headers: { "Accept-Language": "de" } });
    if (!res.ok) throw new Error(`nominatim_http_${res.status}`);
    const treffer = await res.json();
    if (!Array.isArray(treffer) || !treffer.length) return null;
    const lat = parseFloat(treffer[0].lat), lon = parseFloat(treffer[0].lon);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
    return { lat, lon, anzeige: treffer[0].display_name || adresse };
  }
  // Ortspräferenz für mehrdeutige Ortsnamen (z.B. "Reinfeld" gibt es mehrfach
  // in Deutschland) - siehe backend/utils/geocoding.js, 1:1 portiert.
  function baueViewbox(punkte) {
    let latMin = null, latMax = null, lonMin = null, lonMax = null;
    const RAND = 0.1;
    for (const p of punkte) {
      // Number(null) ist 0, nicht NaN - ohne den expliziten null-Check würde ein
      // noch nicht verorteter Punkt fälschlich als (0,0) in die Box eingerechnet.
      if (p?.lat == null || p?.lon == null) continue;
      const lat = Number(p.lat), lon = Number(p.lon);
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) continue;
      latMin = latMin === null ? lat - RAND : Math.min(latMin, lat - RAND);
      latMax = latMax === null ? lat + RAND : Math.max(latMax, lat + RAND);
      lonMin = lonMin === null ? lon - RAND : Math.min(lonMin, lon - RAND);
      lonMax = lonMax === null ? lon + RAND : Math.max(lonMax, lon + RAND);
    }
    return latMin === null ? null : { latMin, latMax, lonMin, lonMax };
  }
  function erweitereViewbox(box, lat, lon) {
    const RAND = 0.1;
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return box;
    if (!box) return { latMin: lat - RAND, latMax: lat + RAND, lonMin: lon - RAND, lonMax: lon + RAND };
    return {
      latMin: Math.min(box.latMin, lat - RAND),
      latMax: Math.max(box.latMax, lat + RAND),
      lonMin: Math.min(box.lonMin, lon - RAND),
      lonMax: Math.max(box.lonMax, lon + RAND)
    };
  }
  function viewboxParam(box) {
    return box ? `${box.lonMin},${box.latMax},${box.lonMax},${box.latMin}` : null;
  }
  function ordneStrassenZu(items) {
    const zuordnung = new Map();
    let aktuelleStrasse = "", aktuellerStadtteil = "";
    for (const item of items) {
      const nr = String(item.auftragsnummer || "").trim();
      if (/^\d+\.\d+$/.test(nr)) {
        aktuelleStrasse = String(item.beschreibung || "").trim();
        aktuellerStadtteil = String(item.liegenschaft || "").trim();
        continue;
      }
      zuordnung.set(item.id, { strasse: aktuelleStrasse, stadtteil: String(item.liegenschaft || "").trim() || aktuellerStadtteil });
    }
    return zuordnung;
  }
  function baueAdressVarianten({ strasse, stadtteil }, ort) {
    const varianten = [];
    const gleichWieOrt = (s) => !!ort && String(s || "").trim().toLowerCase() === String(ort).trim().toLowerCase();
    const zusatz = (s) => (ort && !gleichWieOrt(s)) ? `, ${ort}` : "";
    if (strasse) varianten.push(`${strasse}${zusatz(strasse)}`);
    if (stadtteil && stadtteil !== strasse) varianten.push(`${stadtteil}${zusatz(stadtteil)}`);
    if (!varianten.length && ort) varianten.push(ort);
    return [...new Set(varianten)];
  }
  async function geocodeMitVarianten(varianten, viewbox) {
    for (const adresse of varianten) {
      const treffer = await geocodeAdresse(adresse, viewbox);
      if (treffer) return { ...treffer, verwendeteAdresse: adresse };
    }
    return null;
  }

  const geocodeLaeufe = new Map(); // listeId -> Status (wie im alten Server-Endpoint)
  post("/api/baumlisten/:id/geocode", async ({ params, request }) => {
    const listeId = Number(params.id);
    const laufend = geocodeLaeufe.get(listeId);
    if (laufend?.laufend) return json({ ok: true, status: laufend });

    const liste = await D().get("baumlisten", listeId);
    if (!liste) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    // orteProGruppe: bei generischen Listen (z.B. Wässerliste) mit mehreren
    // Hauptpositionen liegt oft nicht überall derselbe Ort - deshalb kann statt
    // eines einzelnen "ort" eine Map Hauptposition -> Ort mitgeschickt werden.
    const orteProGruppeEingabe = (body?.orteProGruppe && typeof body.orteProGruppe === "object") ? body.orteProGruppe : null;
    const ort = String(body?.ort || liste.geo_ort || "").trim();
    if (!orteProGruppeEingabe && !ort) return json({ error: "ort_required" }, 400);
    liste.geo_ort = orteProGruppeEingabe ? JSON.stringify(orteProGruppeEingabe) : ort;
    await D().put("baumlisten", liste);

    const items = (await D().getAllByIndex("baumlisten_items", "liste_id", listeId)).sort((a, b) => a.id - b.id);
    // Generische Listen (z.B. Wässerliste) haben kein Straßen-Trennzeilen-
    // Layout - dort steht die Adresse direkt im Info-Feld "Adresse" jeder
    // Position, es gibt also keine Strasse/Stadtteil-Zuordnung zu berechnen.
    const generisch = !!liste.spalten_config?.infoFelder?.length;
    const gruppenFeld = generisch ? (liste.spalten_config.infoFelder[0] || null) : null;
    const zuordnung = generisch ? null : ordneStrassenZu(items);
    let ortsBox = baueViewbox(items);
    const neuBerechnen = !!body?.neuBerechnen;
    const adressen = new Map();
    for (const item of items) {
      if (item.geo_quelle === "manuell") continue;
      if (item.lat != null && !neuBerechnen) continue;

      let varianten;
      if (generisch) {
        const adresse = String(item.info?.Adresse || "").trim();
        if (!adresse) continue;
        let ortFuerItem = ort;
        if (orteProGruppeEingabe && gruppenFeld) {
          const gruppenWert = String(item.info?.[gruppenFeld] || "").trim();
          ortFuerItem = String(orteProGruppeEingabe[gruppenWert] || "").trim();
        }
        if (!ortFuerItem) continue; // Hauptposition wurde beim Verorten übersprungen
        varianten = baueAdressVarianten({ strasse: adresse, stadtteil: "" }, ortFuerItem);
      } else {
        const ortsangabe = zuordnung.get(item.id);
        if (!ortsangabe || (!ortsangabe.strasse && !ortsangabe.stadtteil)) continue;
        varianten = baueAdressVarianten(ortsangabe, ort);
      }
      if (!varianten.length) continue;
      const schluessel = varianten.join(" | ");
      if (!adressen.has(schluessel)) adressen.set(schluessel, { varianten, itemIds: [] });
      adressen.get(schluessel).itemIds.push(item.id);
    }

    const status = { laufend: true, gesamt: adressen.size, erledigt: 0, gefunden: 0, fehler: 0, ort, fertigAm: null };
    geocodeLaeufe.set(listeId, status);

    // Im Hintergrund weiterlaufen (Antwort ist schon raus) - genau wie im
    // Server-Original, weil ~1 Anfrage/Sekunde bei vielen Adressen dauert.
    (async () => {
      for (const [schluessel, { varianten, itemIds }] of adressen) {
        try {
          const treffer = await geocodeMitVarianten(varianten, viewboxParam(ortsBox));
          if (treffer) {
            for (const id of itemIds) {
              const it = await D().get("baumlisten_items", id);
              if (it) { it.lat = treffer.lat; it.lon = treffer.lon; it.geo_quelle = "geocode"; stampGeaendert(it); await D().put("baumlisten_items", it); }
            }
            ortsBox = erweitereViewbox(ortsBox, treffer.lat, treffer.lon);
            status.gefunden += itemIds.length;
          } else {
            status.fehler += 1;
          }
        } catch (err) {
          // Netzfehler (z.B. gerade kein Internet) - Rest der Liste
          // abbrechen statt jede Adresse einzeln scheitern zu lassen; beim
          // nächsten Mal (wieder online) einfach erneut "Verorten" drücken.
          console.warn("Geocoding-Fehler, breche Lauf ab:", err.message);
          status.fehler += adressen.size - status.erledigt;
          break;
        }
        status.erledigt += 1;
      }
      status.laufend = false;
      status.fertigAm = new Date().toISOString();
    })();

    return json({ ok: true, status });
  });
  get("/api/baumlisten/:id/geocode/status", async ({ params }) => {
    return json({ ok: true, status: geocodeLaeufe.get(Number(params.id)) || null });
  });

  patch("/api/baumlisten/:id/items/:itemId/geo", async ({ params, request }) => {
    const item = await D().get("baumlisten_items", Number(params.itemId));
    if (!item || item.liste_id !== Number(params.id)) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    const lat = Number(body.lat), lon = Number(body.lon);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return json({ error: "invalid_coords" }, 400);
    item.lat = lat; item.lon = lon; item.geo_quelle = "manuell";
    stampGeaendert(item);
    await D().put("baumlisten_items", item);
    return json({ ok: true, item: { id: item.id, lat, lon, geo_quelle: "manuell" } });
  });
  del("/api/baumlisten/:id/items/:itemId/geo", async ({ params }) => {
    const item = await D().get("baumlisten_items", Number(params.itemId));
    if (!item || item.liste_id !== Number(params.id)) return json({ error: "not_found" }, 404);
    item.lat = null; item.lon = null; item.geo_quelle = null;
    stampGeaendert(item);
    await D().put("baumlisten_items", item);
    return json({ ok: true });
  });

  get("/api/baumlisten/:id", async ({ params }) => {
    const id = Number(params.id);
    const liste = await D().get("baumlisten", id);
    if (!liste || liste.deleted_at) return json({ error: "not_found" }, 404);
    const alleZeilen = await D().getAllByIndex("baumlisten_items", "liste_id", id);
    const items = alleZeilen.filter((i) => !i.deleted_at).sort((a, b) => a.id - b.id);
    // Zähl-Schnappschuss bei jedem Öffnen einer Liste - siehe public/protokoll.html.
    // Wichtigster Einzel-Eintrag im Audit-Log, um einen Vorfall wie
    // "Pflegeliste plötzlich leer" zeitlich einzugrenzen: eine Reihe dieser
    // Einträge zeigt den Verlauf der Positionszahl über die Zeit, unabhängig
    // davon, wodurch eine Änderung ausgelöst wurde (UI, WLAN-Sync, Import).
    D().protokolliere({
      typ: "aktion", bereich: "baumlisten_items", aktion: "liste_geladen",
      beschreibung: `Liste #${id} "${liste.name || ""}" geöffnet: ${items.length} von ${alleZeilen.length} Positionen (Rest gelöscht/Tombstone)`,
      detail: JSON.stringify({ liste_id: id, sichtbar: items.length, gesamt_inkl_geloescht: alleZeilen.length })
    });
    const users = await D().getAll("users");
    const projekte = await D().getAll("projekte");
    return json({ ok: true, liste: { ...liste, erstellt_von_name: users.find((u) => u.id === liste.erstellt_von)?.username || "", projekt_name: projekte.find((p) => p.id === liste.projekt_id)?.name || null }, items });
  });

  post("/api/baumlisten", async ({ request }) => {
    const body = await bodyOf(request);
    const { name, projekt_id, auftraggeber, beschreibung, spalten_config } = body;
    // items ist optional - eine leere Liste laesst sich anlegen, um Positionen
    // anschliessend direkt per Klick auf der Karte zu erfassen (Waesserlisten).
    const items = Array.isArray(body.items) ? body.items : [];
    if (!name) return json({ error: "name_required" }, 400);
    const au = activeUser();
    const liste = await D().add("baumlisten", stampNeu({
      name, projekt_id: projekt_id || null, auftraggeber: auftraggeber || null, beschreibung: beschreibung || null,
      erstellt_von: au?.id || 0, erstellt_am: new Date().toISOString(), spalten_config: spalten_config || null
    }));
    if (items.length) await insertBaumlistenItems(liste.id, items);
    return json({ ok: true, id: liste.id, count: items.length });
  });

  put("/api/baumlisten/:id", async ({ params, request }) => {
    const liste = await D().get("baumlisten", Number(params.id));
    if (!liste) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    liste.name = body.name; liste.projekt_id = body.projekt_id || null;
    liste.auftraggeber = body.auftraggeber || null; liste.beschreibung = body.beschreibung || null;
    stampGeaendert(liste);
    await D().put("baumlisten", liste);
    return json({ ok: true });
  });

  post("/api/baumlisten/:id/items", async ({ params, request }) => {
    const listeId = Number(params.id);
    const liste = await D().get("baumlisten", listeId);
    if (!liste) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    if (!Array.isArray(body.items) || !body.items.length) return json({ error: "items_required" }, 400);
    await insertBaumlistenItems(listeId, body.items);
    stampGeaendert(liste);
    await D().put("baumlisten", liste);
    return json({ ok: true, count: body.items.length });
  });

  // Bearbeitet nur die Info-/Klassik-Felder einer Position (z.B. Hauptposition/
  // Bezeichnung/Adresse/Notiz einer Wässerliste) - Pflegegänge, Prioritaet und
  // Position (lat/lon) haben eigene Handler und bleiben hier unangetastet.
  put("/api/baumlisten/:id/items/:itemId", async ({ params, request }) => {
    const listeId = Number(params.id), itemId = Number(params.itemId);
    const item = await D().get("baumlisten_items", itemId);
    if (!item || item.liste_id !== listeId) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    Object.assign(item, {
      auftragsnummer: String(body.auftragsnummer || "").trim(),
      liegenschaft: String(body.liegenschaft || "").trim(),
      beschreibung: String(body.beschreibung || "").trim(),
      menge: String(body.menge || "").trim(),
      einheit: String(body.einheit || "").trim(),
      info: body.info || null
    });
    stampGeaendert(item);
    await D().put("baumlisten_items", item);
    const liste = await D().get("baumlisten", listeId);
    if (liste) { stampGeaendert(liste); await D().put("baumlisten", liste); }
    return json({ ok: true, item });
  });

  // Löschen ist ein Soft-Delete (deleted_at statt echtem Entfernen) - der
  // WLAN-Sync (siehe public/js/lan-sync.js) braucht eine Tombstone, damit ein
  // anderes Gerät die Löschung übernimmt, statt die Liste beim nächsten
  // Abgleich aus seiner eigenen, noch vorhandenen Kopie unbeabsichtigt wieder
  // aufleben zu lassen.
  del("/api/baumlisten/:id", async ({ params }) => {
    if (!isVerwalter("pflege")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const id = Number(params.id);
    const liste = await D().get("baumlisten", id);
    if (!liste || liste.deleted_at) return json({ error: "not_found" }, 404);
    const items = await D().getAllByIndex("baumlisten_items", "liste_id", id);
    for (const it of items) await D().put("baumlisten_items", stampGeaendert({ ...it, deleted_at: new Date().toISOString() }));
    await D().put("baumlisten", stampGeaendert({ ...liste, deleted_at: new Date().toISOString() }));
    return json({ ok: true });
  });

  patch("/api/baumlisten/:id/items/:itemId/pflegegang/:index", async ({ params, request }) => {
    const listeId = Number(params.id), itemId = Number(params.itemId), index = Number(params.index);
    if (!Number.isInteger(index) || index < 0) return json({ error: "invalid_id" }, 400);
    const body = await bodyOf(request);
    const { erledigt, datum, zusatzTermin, weitereIndex, loeschen } = body;
    if (erledigt === undefined && datum === undefined && zusatzTermin === undefined && !loeschen) return json({ error: "nothing_to_update" }, 400);
    if ((erledigt !== undefined || loeschen) && !isVerwalter("pflege")) return json({ error: "admin_required" }, 403);

    const liste = await D().get("baumlisten", listeId);
    if (!liste) return json({ error: "not_found" }, 404);
    const terminCount = liste.spalten_config?.terminSpalten?.length || 10;
    if (index >= terminCount) return json({ error: "invalid_id" }, 400);

    const item = await D().get("baumlisten_items", itemId);
    if (!item || item.liste_id !== listeId) return json({ error: "not_found" }, 404);
    stampGeaendert(item); // trägt über die {...item, ...}-Spreads unten in jeden Zweig durch

    const pflegegaenge = Array.isArray(item.pflegegaenge) ? item.pflegegaenge.slice() : [];
    while (pflegegaenge.length <= index) pflegegaenge.push(null);

    // Vor Migration 007 waren Pflegegaenge reine Datums-Strings statt Objekte
    // ({datum, erledigt, ...}) - auf einem Geraet, das seit damals offline
    // Daten angesammelt hat, koennen einzelne Eintraege das noch sein (die
    // SQL-Migration lief nur serverseitig, nie gegen IndexedDB). Ohne diese
    // Normalisierung wuerde {...prev} den String zeichenweise in nummerierte
    // Keys spreaden und dabei sowohl das alte Datum als auch jeden neu
    // hinzugefuegten "weiteren Termin" lautlos zerstoeren.
    const rawPrev = pflegegaenge[index];
    const prev = typeof rawPrev === "string"
      ? { datum: rawPrev, erledigt: false, erledigt_von: null, erledigt_am: null }
      : rawPrev;
    const existing = (prev && !prev.na) ? { ...prev } : { datum: "", erledigt: false, erledigt_von: null, erledigt_am: null };

    // Löschen: entweder einen einzelnen "weiteren Termin" aus der Liste
    // entfernen, oder (ohne weitereIndex) den ganzen Durchgang wieder auf
    // "offen" zurücksetzen (inkl. aller weiteren Termine).
    if (loeschen) {
      if (weitereIndex !== null && weitereIndex !== undefined && Array.isArray(existing.weitere_termine)) {
        existing.weitere_termine.splice(weitereIndex, 1);
        pflegegaenge[index] = existing;
      } else {
        pflegegaenge[index] = null;
      }
      await D().put("baumlisten_items", { ...item, pflegegaenge });
      const aktualisiert = await D().get("baumlisten_items", itemId);
      return json({ ok: true, item: aktualisiert });
    }

    // Datum eines bereits vorhandenen "weiteren Termins" bearbeiten (statt
    // wie sonst den primären Termin zu setzen/überschreiben).
    if (datum !== undefined && weitereIndex !== null && weitereIndex !== undefined && Array.isArray(existing.weitere_termine) && existing.weitere_termine[weitereIndex]) {
      existing.weitere_termine[weitereIndex].datum = String(datum || "").trim();
      pflegegaenge[index] = existing;
      await D().put("baumlisten_items", { ...item, pflegegaenge });
      const aktualisiert = await D().get("baumlisten_items", itemId);
      return json({ ok: true, item: aktualisiert });
    }

    if (datum !== undefined) {
      existing.datum = String(datum || "").trim();
      existing.farbe = "rot";
      delete existing.na;
    }
    if (zusatzTermin !== undefined) {
      const v = String(zusatzTermin || "").trim();
      if (v) {
        if (!existing.datum) {
          existing.datum = v;
        } else {
          if (!Array.isArray(existing.weitere_termine)) existing.weitere_termine = [];
          existing.weitere_termine.push({ datum: v, erledigt: false, erledigt_von: null, erledigt_am: null });
        }
        existing.farbe = "rot";
        delete existing.na;
      }
    }
    if (erledigt !== undefined) {
      const weitere = Array.isArray(existing.weitere_termine) ? existing.weitere_termine : null;
      const target = weitere && weitere[weitereIndex] && typeof weitere[weitereIndex] === "object" ? weitere[weitereIndex] : existing;
      const abhakerName = String(body.erfasst_von || "").trim() || activeUser()?.username || "unbekannt";
      target.erledigt = !!erledigt;
      target.erledigt_von = erledigt ? abhakerName : null;
      target.erledigt_am = erledigt ? (body.erledigt_am || new Date().toISOString()) : null;
    }

    pflegegaenge[index] = existing;
    item.pflegegaenge = pflegegaenge;
    await D().put("baumlisten_items", item);
    return json({ ok: true, item });
  });

  patch("/api/baumlisten/:id/abrechnung", async ({ params }) => {
    if (!isAdmin()) return json({ error: "admin_required" }, 403);
    const listeId = Number(params.id);
    const items = await D().getAllByIndex("baumlisten_items", "liste_id", listeId);

    let geaendert = 0;
    for (const item of items) {
      const pflegegaenge = Array.isArray(item.pflegegaenge) ? item.pflegegaenge : [];
      let hatRot = false;
      const neu = pflegegaenge.map((e) => {
        if (e && typeof e === "object" && e.farbe === "rot") {
          hatRot = true;
          const { farbe, ...rest } = e;
          return rest;
        }
        return e;
      });
      if (hatRot) {
        geaendert++;
        await D().put("baumlisten_items", { ...item, pflegegaenge: neu });
      }
    }

    return json({ ok: true, geaendert });
  });

  // ================================================================ LV-BAU
  get("/api/lv-bau-projekte", async () => json({ ok: true, projekte: await projekteMitFortschritt("lv_bau_projekte", "lv_bau_items") }));
  get("/api/lv-bau-projekte/:id", async ({ params }) => {
    const id = Number(params.id);
    const p = await D().get("lv_bau_projekte", id);
    if (!p || p.deleted_at) return json({ error: "not_found" }, 404);
    const listen = (await D().getAllByIndex("lv_bau_listen", "projekt_id", id)).filter((l) => !l.deleted_at);
    const items = (await D().getAll("lv_bau_items")).filter((i) => !i.deleted_at);
    const listenMitFortschritt = listen.map((l) => {
      const eigene = items.filter((i) => i.liste_id === l.id);
      return { ...l, total: eigene.length, erledigt: eigene.filter((i) => i.erledigt).length };
    }).sort((a, b) => new Date(b.erstellt_am) - new Date(a.erstellt_am));
    return json({ ok: true, projekt: p, listen: listenMitFortschritt });
  });
  post("/api/lv-bau-projekte", async ({ request }) => {
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);
    const au = activeUser();
    const rec = await D().add("lv_bau_projekte", stampNeu({ name, beschreibung: body.beschreibung || null, erstellt_von: au?.id || 0, erstellt_am: new Date().toISOString() }));
    return json({ ok: true, projekt: rec });
  });
  put("/api/lv-bau-projekte/:id", async ({ params, request }) => {
    const p = await D().get("lv_bau_projekte", Number(params.id));
    if (!p || p.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);
    p.name = name; p.beschreibung = body.beschreibung || null;
    stampGeaendert(p);
    await D().put("lv_bau_projekte", p);
    return json({ ok: true, projekt: p });
  });
  del("/api/lv-bau-projekte/:id", async ({ params }) => {
    if (!isAdmin()) return json({ error: "forbidden_admin" }, 403);
    const id = Number(params.id);
    const p = await D().get("lv_bau_projekte", id);
    if (!p || p.deleted_at) return json({ error: "not_found" }, 404);
    p.deleted_at = new Date().toISOString();
    stampGeaendert(p);
    await D().put("lv_bau_projekte", p);
    return json({ ok: true });
  });

  const LV_ITEM_FIELDS = ["oz", "langtext", "menge", "einheit", "dauer", "einheitsangaben", "bemerkung"];
  async function insertLvItems(listeId, items) {
    for (const item of items) {
      const rec = { liste_id: listeId, erledigt: false, erledigt_von: null, erledigt_am: null };
      LV_ITEM_FIELDS.forEach((f) => { rec[f] = String(item[f] || "").trim(); });
      await D().add("lv_bau_items", stampNeu(rec));
    }
  }
  get("/api/lv-bau", async ({ url }) => {
    const projektIdRaw = url.searchParams.get("projekt_id");
    let listen = (await D().getAll("lv_bau_listen")).filter((l) => !l.deleted_at);
    if (projektIdRaw === "none") listen = listen.filter((l) => !l.projekt_id);
    else if (projektIdRaw) listen = listen.filter((l) => l.projekt_id === Number(projektIdRaw));
    const items = (await D().getAll("lv_bau_items")).filter((i) => !i.deleted_at);
    const users = await D().getAll("users");
    const projekte = await D().getAll("lv_bau_projekte");
    const out = listen.map((l) => {
      const eigene = items.filter((i) => i.liste_id === l.id);
      return {
        ...l, erstellt_von_name: users.find((u) => u.id === l.erstellt_von)?.username || "",
        projekt_name: projekte.find((p) => p.id === l.projekt_id)?.name || null,
        total: eigene.length, erledigt: eigene.filter((i) => i.erledigt).length
      };
    }).sort((a, b) => new Date(b.erstellt_am) - new Date(a.erstellt_am));
    return json({ ok: true, listen: out });
  });
  get("/api/lv-bau/erledigt-heute", async ({ url }) => {
    const datum = url.searchParams.get("datum") || "";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(datum)) return json({ error: "invalid_date" }, 400);
    const listen = (await D().getAll("lv_bau_listen")).filter((l) => !l.deleted_at);
    const items = (await D().getAll("lv_bau_items")).filter((i) => !i.deleted_at && i.erledigt && String(i.erledigt_am || "").slice(0, 10) === datum);
    const out = items.map((i) => ({ id: i.id, oz: i.oz, langtext: i.langtext, menge: i.menge, einheit: i.einheit, liste_name: listen.find((l) => l.id === i.liste_id)?.name })).sort((a, b) => String(a.oz).localeCompare(String(b.oz)));
    return json({ ok: true, items: out });
  });
  get("/api/lv-bau/:id", async ({ params }) => {
    const id = Number(params.id);
    const liste = await D().get("lv_bau_listen", id);
    if (!liste || liste.deleted_at) return json({ error: "not_found" }, 404);
    const items = (await D().getAllByIndex("lv_bau_items", "liste_id", id)).filter((i) => !i.deleted_at).sort((a, b) => a.id - b.id);
    const users = await D().getAll("users");
    const projekte = await D().getAll("lv_bau_projekte");
    return json({ ok: true, liste: { ...liste, erstellt_von_name: users.find((u) => u.id === liste.erstellt_von)?.username || "", projekt_name: projekte.find((p) => p.id === liste.projekt_id)?.name || null }, items });
  });
  post("/api/lv-bau", async ({ request }) => {
    const body = await bodyOf(request);
    const { name, projekt_id, auftraggeber, beschreibung, items } = body;
    if (!name || !Array.isArray(items) || !items.length) return json({ error: "name_and_items_required" }, 400);
    const au = activeUser();
    const liste = await D().add("lv_bau_listen", stampNeu({ name, projekt_id: projekt_id || null, auftraggeber: auftraggeber || null, beschreibung: beschreibung || null, erstellt_von: au?.id || 0, erstellt_am: new Date().toISOString() }));
    await insertLvItems(liste.id, items);
    return json({ ok: true, id: liste.id, count: items.length });
  });
  put("/api/lv-bau/:id", async ({ params, request }) => {
    const liste = await D().get("lv_bau_listen", Number(params.id));
    if (!liste || liste.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    liste.name = body.name; liste.projekt_id = body.projekt_id || null;
    liste.auftraggeber = body.auftraggeber || null; liste.beschreibung = body.beschreibung || null;
    stampGeaendert(liste);
    await D().put("lv_bau_listen", liste);
    return json({ ok: true });
  });
  post("/api/lv-bau/:id/items", async ({ params, request }) => {
    const listeId = Number(params.id);
    const liste = await D().get("lv_bau_listen", listeId);
    if (!liste || liste.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    if (!Array.isArray(body.items) || !body.items.length) return json({ error: "items_required" }, 400);
    await insertLvItems(listeId, body.items);
    stampGeaendert(liste);
    await D().put("lv_bau_listen", liste);
    return json({ ok: true, count: body.items.length });
  });
  // Soft-Delete kaskadiert auf die Items (gleiches Muster wie bei baumlisten/
  // baumlisten_items) - eine Tombstone der Liste allein würde die noch
  // vorhandenen Items auf einem Nebengerät verwaist zurücklassen.
  del("/api/lv-bau/:id", async ({ params }) => {
    if (!isAdmin()) return json({ error: "forbidden_admin" }, 403);
    const id = Number(params.id);
    const liste = await D().get("lv_bau_listen", id);
    if (!liste || liste.deleted_at) return json({ error: "not_found" }, 404);
    const items = await D().getAllByIndex("lv_bau_items", "liste_id", id);
    for (const it of items) await D().put("lv_bau_items", stampGeaendert({ ...it, deleted_at: new Date().toISOString() }));
    await D().put("lv_bau_listen", stampGeaendert({ ...liste, deleted_at: new Date().toISOString() }));
    return json({ ok: true });
  });
  patch("/api/lv-bau/:id/items/:itemId", async ({ params, request }) => {
    const item = await D().get("lv_bau_items", Number(params.itemId));
    if (!item || item.liste_id !== Number(params.id) || item.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    const { erledigt, bemerkung } = body;
    if (erledigt === undefined && bemerkung === undefined) return json({ error: "nothing_to_update" }, 400);
    if (erledigt !== undefined) {
      item.erledigt = !!erledigt;
      item.erledigt_von = erledigt ? (activeUser()?.id || null) : null;
      item.erledigt_am = erledigt ? new Date().toISOString() : null;
    }
    if (bemerkung !== undefined) item.bemerkung = String(bemerkung || "").trim();
    stampGeaendert(item);
    await D().put("lv_bau_items", item);
    return json({ ok: true, item });
  });
  // PDF-Textauswertung: lädt das bereits für die PDF-Vorschau vendorte pdf.js
  // (siehe anleitung.html/admin/berichte.html) per dynamischem import() nach -
  // lokal-api.js läuft als klassisches <script> ohne type="module", ein
  // statisches "import" am Dateianfang wäre hier ein Syntaxfehler.
  let pdfjsLibPromise = null;
  function ladePdfjs() {
    if (!pdfjsLibPromise) {
      pdfjsLibPromise = import("/js/vendor/pdfjs/pdf.min.mjs").then((mod) => {
        mod.GlobalWorkerOptions.workerSrc = "/js/vendor/pdfjs/pdf.worker.min.mjs";
        return mod;
      });
    }
    return pdfjsLibPromise;
  }

  // Text pro Seite exakt nach demselben Verfahren wie das serverseitige
  // pdf-parse-Paket zusammensetzen (Vergleich der Y-Position aufeinander-
  // folgender Text-Fragmente: gleiche Zeile -> direkt anhängen, neue Zeile ->
  // Zeilenumbruch einfügen) - damit liefert exakt derselbe Parser
  // (parsePdfLvText) hier wie serverseitig dasselbe Ergebnis.
  async function extrahierePdfText(arrayBuffer) {
    const pdfjsLib = await ladePdfjs();
    const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(arrayBuffer) }).promise;
    let volltext = "";
    for (let seite = 1; seite <= pdf.numPages; seite++) {
      const page = await pdf.getPage(seite);
      const inhalt = await page.getTextContent();
      let lastY, text = "";
      for (const item of inhalt.items) {
        if (lastY === item.transform[5] || lastY === undefined) {
          text += item.str;
        } else {
          text += "\n" + item.str;
        }
        lastY = item.transform[5];
      }
      volltext += text + "\n\n";
    }
    return volltext;
  }

  // Heuristischer Parser für klassisches deutsches Leistungsverzeichnis
  // ("1. Titel: XXX" als Kapitel, "1.1. Kurztext" als Position, mehrzeiliger
  // Langtext, abgeschlossen durch eine Menge/Einheit-Zeile) - 1:1 aus
  // backend/utils/lvPdfParser.js portiert (reines JS ohne Node-Abhängigkeiten,
  // export-Syntax entfernt, da hier kein ES-Modul).
  const LV_CHAPTER_RE = /^(\d{1,2})\.\s*Titel\s*:\s*(.+)$/i;
  const LV_POSITION_RE = /^(\d{1,3}\.\d{1,3}[a-z]?\.?)\s+(\S.*)$/;
  const LV_EVENTUAL_RE = /^\*?\s*Eventualposition\b/i;
  const LV_SUMME_RE = /^Summe\s+(Titel|Lv)\b/i;
  const LV_QUANTITY_RE = /^([\d.,]+)\s+((?:\d+\s+)?[A-Za-zÄÖÜäöüß0-9²³/%]+)\s+((?:[\d.,]+\s*)*(?:\*?\s*nur\s*Einheitspreis\s*\*?|EP|GP)?)\s*$/i;
  const LV_SKIP_RE = /^(Seite\s+\d+\s+von\s+\d+|Bauvorhaben\s*:|Dipl\.-Ing\.|Lv\s*:|.*Fax\s*:\s*\d|.*Tel(efon)?\s*:\s*\d)/i;
  function lvIstUeberspringbar(line) {
    return LV_SKIP_RE.test(line) || LV_SUMME_RE.test(line);
  }
  function parsePdfLvText(text) {
    const lines = String(text || "")
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => l.length > 0);

    const items = [];
    let oz = null;
    let kurztext = null;
    let langtextLines = [];
    let eventual = false;

    function flush(menge, einheit) {
      if (oz == null) return;
      const langtext = [kurztext, ...langtextLines].filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
      items.push({
        oz,
        langtext,
        menge: menge || "",
        einheit: einheit || "",
        bemerkung: eventual ? "Eventualposition" : ""
      });
      oz = null;
      kurztext = null;
      langtextLines = [];
      eventual = false;
    }

    for (const line of lines) {
      if (lvIstUeberspringbar(line)) continue;
      if (LV_CHAPTER_RE.test(line)) continue;

      if (LV_EVENTUAL_RE.test(line)) {
        eventual = true;
        continue;
      }

      const posMatch = line.match(LV_POSITION_RE);
      if (posMatch && !LV_QUANTITY_RE.test(line)) {
        oz = posMatch[1].replace(/\.$/, "");
        kurztext = posMatch[2].trim();
        langtextLines = [];
        continue;
      }

      const qMatch = line.match(LV_QUANTITY_RE);
      if (qMatch && oz != null) {
        flush(qMatch[1], qMatch[2]);
        continue;
      }

      if (oz != null) langtextLines.push(line);
    }

    return items;
  }

  post("/api/lv-bau/parse-pdf", async ({ request }) => {
    const body = await bodyOf(request);
    const pdfBase64 = body.pdfBase64;
    if (!pdfBase64 || typeof pdfBase64 !== "string") return json({ error: "pdf_required" }, 400);

    try {
      const binaer = atob(pdfBase64);
      const bytes = new Uint8Array(binaer.length);
      for (let i = 0; i < binaer.length; i++) bytes[i] = binaer.charCodeAt(i);

      const text = await extrahierePdfText(bytes.buffer);
      const items = parsePdfLvText(text);

      if (!items.length) {
        return json({
          error: "no_positions_found",
          message: "Es konnten keine Positionen im PDF erkannt werden. Das Layout dieses LV weicht vermutlich vom erwarteten Muster (Nr., Kurztext, Menge/Einheit) ab - bitte alternativ als Tabellen-CSV/Excel importieren."
        }, 422);
      }

      return json({
        ok: true,
        headers: ["OZ", "Langtext", "Menge", "Einheit", "Bemerkung"],
        rows: items.map((i) => [i.oz, i.langtext, i.menge, i.einheit, i.bemerkung])
      });
    } catch (err) {
      console.error("PDF-Import (LV-Bau) fehlgeschlagen:", err);
      return json({ error: "pdf_parse_failed" }, 500);
    }
  });

  // ================================================================= TERMINE
  const TERMIN_STATUS = ["geplant", "erledigt", "abgesagt"];
  const RSVP_STATUS = ["offen", "angenommen", "abgelehnt", "vielleicht"];
  // Termine trugen ursprünglich einen einzelnen Mitarbeiter-Namen (String).
  // Jetzt können mehrere zugewiesen werden, daher intern immer als Array
  // gehalten - alte Datensätze mit einem einzelnen String bleiben lesbar.
  function mitarbeiterListe(v) {
    if (Array.isArray(v)) return v.map((s) => String(s || "").trim()).filter(Boolean);
    const s = String(v || "").trim();
    return s ? [s] : [];
  }

  // Erinnerungs-Vorlaufzeit in Minuten vor Terminbeginn ("keine" = null),
  // fuer die Geraetebenachrichtigung (siehe public/js/notifications.js).
  function erinnerungWert(v) {
    if (v === null || v === undefined || v === "") return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  // "JJJJ-MM-TT" + Tage -> "JJJJ-MM-TT", ohne Zeitzonen-Stolperfallen (siehe
  // gleichnamige Rechnung in backend/routes/termine.routes.js, dort per
  // SQL-Datumsarithmetik statt hier per JS-Date).
  function addTage(iso, tage) {
    const [j, m, t] = String(iso).split("-").map(Number);
    const d = new Date(j, m - 1, t);
    d.setDate(d.getDate() + tage);
    return isoDatum(d);
  }
  get("/api/termine", async ({ url }) => {
    // Sonderfall fuer die rollierende Serien-Generierung (siehe
    // public/kalender.html): faellige "Wurzel"-Termine wiederkehrender
    // Serien, unabhaengig von Monatsfilter/Sichtbarkeit.
    if (url.searchParams.get("serie_faellig") === "1") {
      const heute = isoDatum(new Date());
      const rows = (await D().getAll("termine")).filter((t) => !t.deleted_at && t.serie_naechstes_datum && t.serie_naechstes_datum <= heute)
        .sort((a, b) => a.serie_naechstes_datum.localeCompare(b.serie_naechstes_datum));
      return json({ ok: true, termine: rows.map((t) => ({ ...t, mitarbeiter: mitarbeiterListe(t.mitarbeiter) })) });
    }
    const von = url.searchParams.get("von"), bis = url.searchParams.get("bis");
    const au = activeUser();
    let rows = (await D().getAll("termine")).filter((t) => !t.deleted_at);
    if (von) rows = rows.filter((t) => t.datum >= von);
    if (bis) rows = rows.filter((t) => t.datum <= bis);
    if (!isVerwalter()) rows = rows.filter((t) => t.erstellt_von === au?.id || mitarbeiterListe(t.mitarbeiter).includes(au?.username));
    const users = await D().getAll("users");
    rows = rows.map((t) => ({ ...t, mitarbeiter: mitarbeiterListe(t.mitarbeiter), erstellt_von_name: users.find((u) => u.id === t.erstellt_von)?.username || "" }))
      .sort((a, b) => a.datum.localeCompare(b.datum) || String(a.von || "").localeCompare(String(b.von || "")));
    return json({ ok: true, termine: rows });
  });

  // Fälligkeits-Logik 1:1 aus backend/utils/faelligkeit.js portiert.
  const WOCHEN_RE = /alle\s+(\d{1,2})\s+Wochen/i;
  const PRO_JAHR_RE = /(\d{1,2})\s*[-\s]*(?:x|mal)\s*[\/\s]*(?:im\s+|pro\s+)?Jahr/i;
  const AB_KW_RE = /ab\s+(?:der\s+)?(\d{1,2})\.\s*KW/i;
  const BIS_KW_RE = /bis\s+(?:zur\s+)?(\d{1,2})\.\s*KW/i;
  function leseIntervall(text) {
    const t = String(text || "");
    const wochen = t.match(WOCHEN_RE), proJahr = t.match(PRO_JAHR_RE), abKw = t.match(AB_KW_RE), bisKw = t.match(BIS_KW_RE);
    let intervallWochen = wochen ? Number(wochen[1]) : null;
    const malProJahr = proJahr ? Number(proJahr[1]) : null;
    if (!intervallWochen && malProJahr > 0) intervallWochen = Math.max(1, Math.round(30 / malProJahr));
    return { intervallWochen, abKw: abKw ? Number(abKw[1]) : null, bisKw: bisKw ? Number(bisKw[1]) : null };
  }
  function parseListenDatum(wert, bezugsjahr) {
    const s = String(wert || "").trim();
    const m = s.match(/^(\d{1,2})[.\/](\d{1,2})[.\/](\d{2,4})?/);
    if (!m) return null;
    let jahr = m[3] ? Number(m[3]) : (bezugsjahr || new Date().getFullYear());
    if (jahr < 100) jahr += 2000;
    const d = new Date(jahr, Number(m[2]) - 1, Number(m[1]));
    return isNaN(d.getTime()) ? null : d;
  }
  function montagDerKw(jahr, kw) {
    const vierter = new Date(jahr, 0, 4);
    const wochentag = vierter.getDay() || 7;
    const montagKw1 = new Date(vierter);
    montagKw1.setDate(vierter.getDate() - (wochentag - 1));
    const ziel = new Date(montagKw1);
    ziel.setDate(montagKw1.getDate() + (kw - 1) * 7);
    return ziel;
  }
  function naechsteFaelligkeit(item, heute) {
    const pg = Array.isArray(item.pflegegaenge) ? item.pflegegaenge : [];
    if (!pg.length) return null;
    const { intervallWochen, abKw, bisKw } = leseIntervall(item.beschreibung);
    let letzterTermin = null, naechsterIndex = -1;
    for (let i = 0; i < pg.length; i++) {
      const e = pg[i];
      if (e && typeof e === "object" && e.na) continue;
      const datum = typeof e === "string" ? e : e?.datum;
      if (datum) {
        const d = parseListenDatum(datum, heute.getFullYear());
        if (d && (!letzterTermin || d > letzterTermin)) letzterTermin = d;
      } else if (naechsterIndex < 0) naechsterIndex = i;
    }
    if (naechsterIndex < 0) return null;
    let faelligAm;
    if (letzterTermin && intervallWochen) { faelligAm = new Date(letzterTermin); faelligAm.setDate(faelligAm.getDate() + intervallWochen * 7); }
    else if (abKw) faelligAm = montagDerKw(heute.getFullYear(), abKw);
    else if (letzterTermin) { faelligAm = new Date(letzterTermin); faelligAm.setDate(faelligAm.getDate() + 42); }
    else return null;
    if (bisKw) {
      const saisonende = montagDerKw(faelligAm.getFullYear(), bisKw);
      saisonende.setDate(saisonende.getDate() + 6);
      if (faelligAm > saisonende) return null;
    }
    return { faelligAm, durchgang: naechsterIndex + 1, intervallWochen, letzterTermin, ueberfaelligTage: Math.floor((heute - faelligAm) / 86400000) };
  }
  function isoDatum(d) { return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; }
  get("/api/termine/faellig", async ({ url }) => {
    const tage = Math.min(Number(url.searchParams.get("tage")) || 30, 365);
    const heute = new Date();
    const grenze = new Date(heute); grenze.setDate(grenze.getDate() + tage);
    const listen = (await D().getAll("baumlisten")).filter((l) => !l.deleted_at);
    const alleItems = (await D().getAll("baumlisten_items")).filter((i) => !i.deleted_at);
    const items = alleItems.filter((i) => !/^\d+\.\d+$/.test(String(i.auftragsnummer || "")));

    // Straßenname statt Stadtteil (siehe backend/routes/termine.routes.js):
    // klassische Listen über die Trennzeile (ordneStrassenZu), generische
    // Listen über eine Info-Spalte, die wie eine Adresse/Straße heißt.
    const strassenMap = new Map();
    for (const liste of listen) {
      const adressFeld = liste.spalten_config?.infoFelder?.find((f) => /adresse|stra(ß|ss)e/i.test(f));
      const listenItems = alleItems.filter((i) => i.liste_id === liste.id);
      if (adressFeld) {
        for (const i of listenItems) strassenMap.set(i.id, String(i.info?.[adressFeld] || "").trim());
      } else {
        const sortiert = listenItems.slice().sort((a, b) => a.id - b.id);
        for (const [itemId, ortsangabe] of ordneStrassenZu(sortiert)) strassenMap.set(itemId, ortsangabe.strasse);
      }
    }

    // Items, für die bereits ein (nicht abgesagter) Termin zu genau diesem
    // Fällig-Datum existiert, nicht nochmal als "fällig" vorschlagen - siehe
    // ausführliche Begründung in backend/routes/termine.routes.js.
    const bestehendeSet = new Set(
      (await D().getAll("termine"))
        .filter((t) => !t.deleted_at && t.item_id && t.status !== "abgesagt")
        .map((t) => `${t.item_id}|${t.datum}`)
    );

    const faellig = [];
    for (const item of items) {
      const f = naechsteFaelligkeit(item, heute);
      if (!f || f.faelligAm > grenze) continue;
      if (bestehendeSet.has(`${item.id}|${isoDatum(f.faelligAm)}`)) continue;
      faellig.push({
        item_id: item.id, liste_id: item.liste_id, liste_name: listen.find((l) => l.id === item.liste_id)?.name,
        position: item.auftragsnummer, strasse: strassenMap.get(item.id) || "", stadtteil: item.liegenschaft,
        leistung: String(item.beschreibung || "").split("\n")[0].slice(0, 120),
        menge: item.menge, einheit: item.einheit, lat: item.lat, lon: item.lon,
        faellig_am: isoDatum(f.faelligAm), durchgang: f.durchgang, intervall_wochen: f.intervallWochen,
        letzter_termin: f.letzterTermin ? isoDatum(f.letzterTermin) : null, ueberfaellig_tage: Math.max(0, f.ueberfaelligTage)
      });
    }
    faellig.sort((a, b) => a.faellig_am.localeCompare(b.faellig_am));
    return json({ ok: true, faellig });
  });
  post("/api/termine", async ({ request }) => {
    const body = await bodyOf(request);
    const titel = String(body.titel || "").trim();
    const datum = String(body.datum || "").trim();
    if (!titel) return json({ error: "titel_required" }, 400);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(datum)) return json({ error: "datum_required" }, 400);
    const au = activeUser();
    // serie_id vom Client gesetzt -> das ist ein bereits generierter
    // Folgetermin einer bestehenden Serie, keine neue Wurzel (siehe
    // gleichnamige Logik in backend/routes/termine.routes.js).
    const serieId = Number(body.serie_id) || null;
    const wiederholungTage = serieId ? null : (Number(body.wiederholung_tage) || null);
    const organisatorEmail = String(body.organisator_email || "").trim() || null;
    const rec = await D().add("termine", stampNeu({
      titel, kunde: String(body.kunde || "").trim() || null, datum,
      von: String(body.von || "").trim() || null, bis: String(body.bis || "").trim() || null,
      beschreibung: String(body.beschreibung || "").trim() || null, mitarbeiter: mitarbeiterListe(body.mitarbeiter),
      quelle: body.quelle === "pflegeliste" ? "pflegeliste" : body.quelle === "pflege_vorschlag" ? "pflege_vorschlag" : "manuell", liste_id: Number(body.liste_id) || null, item_id: Number(body.item_id) || null,
      erstellt_von: au?.id || 0, status: "geplant",
      erinnerung_minuten: erinnerungWert(body.erinnerung_minuten),
      wiederholung_tage: wiederholungTage,
      serie_naechstes_datum: wiederholungTage ? addTage(datum, wiederholungTage) : null,
      serie_id: serieId,
      adresse: String(body.adresse || "").trim() || null,
      organisator_name: String(body.organisator_name || "").trim() || null,
      organisator_email: organisatorEmail,
      ical_uid: String(body.ical_uid || "").trim() || null,
      ical_sequence: Number.isFinite(Number(body.ical_sequence)) ? Number(body.ical_sequence) : null,
      rsvp_status: organisatorEmail ? "offen" : null
    }));
    return json({ ok: true, termin: rec });
  });
  put("/api/termine/:id", async ({ params, request }) => {
    const t = await D().get("termine", Number(params.id));
    if (!t || t.deleted_at) return json({ error: "not_found" }, 404);
    const au = activeUser();
    if (!isVerwalter() && t.erstellt_von !== au?.id) return json({ error: "forbidden" }, 403);
    const body = await bodyOf(request);
    const wiederholungTageAlt = t.wiederholung_tage || null;
    const wiederholungTageNeu = Number(body.wiederholung_tage) || null;
    Object.assign(t, {
      titel: String(body.titel || "").trim(), kunde: String(body.kunde || "").trim() || null, datum: String(body.datum || "").trim(),
      von: String(body.von || "").trim() || null, bis: String(body.bis || "").trim() || null,
      beschreibung: String(body.beschreibung || "").trim() || null, mitarbeiter: mitarbeiterListe(body.mitarbeiter),
      status: TERMIN_STATUS.includes(body.status) ? body.status : "geplant",
      erinnerung_minuten: erinnerungWert(body.erinnerung_minuten),
      wiederholung_tage: wiederholungTageNeu,
      adresse: String(body.adresse || "").trim() || null
    });
    // Serie neu/geaendert -> Fortschritt ab dem eigenen Datum neu anlegen;
    // unveraendert gesetzt -> bestehenden Fortschritt (serie_naechstes_datum)
    // nicht zuruecksetzen, nur weil andere Felder gespeichert wurden.
    if (wiederholungTageNeu !== wiederholungTageAlt) {
      t.serie_naechstes_datum = wiederholungTageNeu ? addTage(t.datum, wiederholungTageNeu) : null;
    }
    stampGeaendert(t);
    await D().put("termine", t);
    return json({ ok: true, termin: t });
  });
  patch("/api/termine/:id/serie-weiter", async ({ params }) => {
    const t = await D().get("termine", Number(params.id));
    if (!t || !t.wiederholung_tage || !t.serie_naechstes_datum) return json({ error: "not_found" }, 404);
    t.serie_naechstes_datum = addTage(t.serie_naechstes_datum, t.wiederholung_tage);
    stampGeaendert(t);
    await D().put("termine", t);
    return json({ ok: true, termin: t });
  });
  patch("/api/termine/:id/status", async ({ params, request }) => {
    const t = await D().get("termine", Number(params.id));
    if (!t) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    if (!TERMIN_STATUS.includes(body.status)) return json({ error: "invalid_status" }, 400);
    t.status = body.status;
    if (body.bericht_id) t.bericht_id = Number(body.bericht_id);
    stampGeaendert(t);
    await D().put("termine", t);
    return json({ ok: true, termin: t });
  });
  patch("/api/termine/:id/rsvp", async ({ params, request }) => {
    const t = await D().get("termine", Number(params.id));
    if (!t || !t.organisator_email) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    if (!RSVP_STATUS.includes(body.status)) return json({ error: "invalid_status" }, 400);
    t.rsvp_status = body.status;
    stampGeaendert(t);
    await D().put("termine", t);
    return json({ ok: true, termin: t });
  });
  // Vom nativen Android-Teil per "Teilen"/"Öffnen mit" empfangene
  // Kalendereinladung (siehe public/js/ics-empfang.js) ODER ein aus dem
  // Geräte-Kalender gespiegelter Termin (siehe public/js/kalender-sync.js) -
  // Gegenstück zu backend/utils/emailEinladungen.js#uebernehmeTermin, nur
  // lokal in IndexedDB statt gegen Postgres. Legt neu an, aktualisiert bei
  // bekannter ical_uid (Sequence-Schutz gegen verspätete alte Versionen,
  // erzwingeUpdate umgeht das für Quellen ohne echte Sequence-Zählung wie
  // den Geräte-Kalender) oder markiert bei einer Absage als "abgesagt".
  post("/api/termine/aus-einladung", async ({ request }) => {
    const e = await bodyOf(request);
    if (!e.icalUid || !e.datum) return json({ error: "invalid_data" }, 400);
    const quelle = e.quelle === "geraetekalender" ? "geraetekalender" : "email_einladung";

    const alle = await D().getAll("termine");
    const bestehend = alle.find((t) => t.ical_uid === e.icalUid);

    if (e.abgesagt) {
      if (bestehend) {
        bestehend.status = "abgesagt";
        bestehend.updated_at = new Date().toISOString();
        await D().put("termine", bestehend);
      }
      return json({ ok: true });
    }

    if (bestehend) {
      const istNeuer = e.erzwingeUpdate || bestehend.ical_sequence == null || Number(e.icalSequence) > bestehend.ical_sequence;
      if (!istNeuer) return json({ ok: true, unveraendert: true });
      Object.assign(bestehend, {
        titel: e.titel, datum: e.datum, von: e.von || null, bis: e.bis || null,
        beschreibung: e.beschreibung || null, adresse: e.adresse || null,
        organisator_name: e.organisatorName || null, organisator_email: e.organisatorEmail || null,
        ical_sequence: Number(e.icalSequence) || 0, updated_at: new Date().toISOString()
      });
      await D().put("termine", bestehend);
      return json({ ok: true, termin: bestehend });
    }

    const au = activeUser();
    const organisatorEmail = e.organisatorEmail || null;
    const rec = await D().add("termine", stampNeu({
      titel: e.titel, kunde: null, datum: e.datum, von: e.von || null, bis: e.bis || null,
      beschreibung: e.beschreibung || null, mitarbeiter: mitarbeiterListe(),
      quelle, liste_id: null, item_id: null,
      erstellt_von: au?.id || null, status: "geplant",
      erinnerung_minuten: null, wiederholung_tage: null, serie_naechstes_datum: null, serie_id: null,
      adresse: e.adresse || null, organisator_name: e.organisatorName || null,
      organisator_email: organisatorEmail, ical_uid: e.icalUid,
      ical_sequence: Number(e.icalSequence) || 0, rsvp_status: organisatorEmail ? "offen" : null
    }));
    return json({ ok: true, termin: rec });
  });
  // Alle noch offenen, aus fälligen Pflegegängen vorgeschlagenen Termine auf
  // einmal entfernen (siehe backend/routes/termine.routes.js für die
  // ausführliche Begründung, inkl. der Titel-Regex für ältere, noch
  // untaggte Vorschlags-Termine) - muss vor "/api/termine/:id" stehen, sonst
  // würde die Parameter-Route "pflege-vorschlaege" als id abfangen.
  const PFLEGE_VORSCHLAG_TITEL = /^\d+\.\s*Pflegegang\s*–/;
  del("/api/termine/pflege-vorschlaege", async () => {
    const alle = await D().getAll("termine");
    let anzahl = 0;
    for (const t of alle) {
      if (t.deleted_at || t.status !== "geplant") continue;
      if (t.quelle !== "pflege_vorschlag" && !PFLEGE_VORSCHLAG_TITEL.test(t.titel || "")) continue;
      t.deleted_at = new Date().toISOString();
      stampGeaendert(t);
      await D().put("termine", t);
      anzahl++;
    }
    return json({ ok: true, anzahl });
  });
  // "Kalender leeren": entfernt ALLE nicht selbst angelegten Termine
  // (quelle='pflegeliste' aus Dauerpflege-Serien + quelle='pflege_vorschlag'
  // aus fälligen Pflegegängen) - Offline-Pendant zu
  // backend/routes/termine.routes.js DELETE /nicht-manuell, siehe dort für die
  // ausführliche Begründung. Muss vor "/api/termine/:id" stehen, sonst würde
  // die Parameter-Route "nicht-manuell" als id abfangen.
  del("/api/termine/nicht-manuell", async () => {
    if (!(await istAdminOderBerechtigung("termine", "loeschen"))) return json({ error: "forbidden_admin" }, 403);
    const alle = await D().getAll("termine");
    let anzahl = 0;
    for (const t of alle) {
      if (t.deleted_at) continue;
      if (t.quelle !== "pflegeliste" && t.quelle !== "pflege_vorschlag") continue;
      t.deleted_at = new Date().toISOString();
      stampGeaendert(t);
      await D().put("termine", t);
      anzahl++;
    }
    return json({ ok: true, anzahl });
  });
  // Soft-Delete (Tombstone für den WLAN-Sync, siehe public/js/lan-sync.js).
  del("/api/termine/:id", async ({ params }) => {
    const t = await D().get("termine", Number(params.id));
    if (!t || t.deleted_at) return json({ error: "not_found" }, 404);
    const au = activeUser();
    if (!isVerwalter() && t.erstellt_von !== au?.id) return json({ error: "forbidden" }, 403);
    t.deleted_at = new Date().toISOString();
    stampGeaendert(t);
    await D().put("termine", t);
    return json({ ok: true });
  });

  // ================================================================= NOTIZEN
  // Freie Anmerkungen je Kunde ("kleine Notizen-Datenbank", siehe
  // public/notizen.html) - eigener Kunden-Datensatz (nicht der freie
  // "kunde"-Text wie bei Terminen/Heckenschnitt), damit sich Notizen gezielt
  // einem angelegten Kunden zuordnen lassen.
  get("/api/notizen/kunden", async () => {
    const kunden = (await D().getAll("kunden")).filter((k) => !k.deleted_at);
    const notizen = (await D().getAll("notizen")).filter((n) => !n.deleted_at);
    const users = await D().getAll("users");
    const angereichert = kunden.map((k) => {
      const eigene = notizen.filter((n) => n.kunde_id === k.id);
      const letzte = eigene.map((n) => n.aktualisiert_am).sort().pop() || null;
      return {
        ...k,
        erstellt_von_name: users.find((u) => u.id === k.erstellt_von)?.username || "",
        notizen_anzahl: eigene.length,
        letzte_notiz_am: letzte
      };
    }).sort((a, b) => a.name.localeCompare(b.name, "de"));
    return json({ ok: true, kunden: angereichert });
  });
  post("/api/notizen/kunden", async ({ request }) => {
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);
    const au = activeUser();
    const rec = await D().add("kunden", stampNeu({ name, erstellt_von: au?.id || 0, erstellt_am: new Date().toISOString() }));
    return json({ ok: true, kunde: rec });
  });
  put("/api/notizen/kunden/:id", async ({ params, request }) => {
    const k = await D().get("kunden", Number(params.id));
    if (!k || k.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);
    k.name = name;
    stampGeaendert(k);
    await D().put("kunden", k);
    return json({ ok: true, kunde: k });
  });
  // Soft-Delete (Tombstone für den WLAN-Sync, siehe public/js/lan-sync.js) -
  // kaskadiert als Soft-Delete auf die zugehörigen Notizen UND deren Fotos
  // (nehmen seit DB_VERSION 7 selbst am Sync teil, siehe stampBildGeloescht oben).
  del("/api/notizen/kunden/:id", async ({ params }) => {
    if (!isVerwalter("pflege")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const id = Number(params.id);
    const k = await D().get("kunden", id);
    if (!k || k.deleted_at) return json({ error: "not_found" }, 404);
    const notizen = await D().getAll("notizen");
    const bilder = await D().getAll("notiz_bilder");
    for (const n of notizen.filter((x) => x.kunde_id === id && !x.deleted_at)) {
      for (const b of bilder.filter((x) => x.notiz_id === n.id && !x.deleted_at)) await D().put("notiz_bilder", stampBildGeloescht(b));
      n.deleted_at = new Date().toISOString();
      stampGeaendert(n);
      await D().put("notizen", n);
    }
    k.deleted_at = new Date().toISOString();
    stampGeaendert(k);
    await D().put("kunden", k);
    return json({ ok: true });
  });

  get("/api/notizen", async ({ url }) => {
    // url.searchParams.get() liefert bei fehlendem Parameter null statt
    // undefined - Number(null) waere 0 und damit fälschlich "vorhanden"
    // (Number.isFinite(0) === true). Deshalb explizit .has() prüfen statt
    // nur auf eine geparste Zahl zu vertrauen (analog req.query.x ===
    // undefined im echten Backend, siehe notizen.routes.js).
    const hatKunde = url.searchParams.has("kunde_id");
    const hatListe = url.searchParams.has("liste_id");
    const hatItem = url.searchParams.has("item_id");
    const kundeId = Number(url.searchParams.get("kunde_id"));
    const listeId = Number(url.searchParams.get("liste_id"));
    const itemId = Number(url.searchParams.get("item_id"));
    if (!hatKunde && !hatListe) return json({ error: "kunde_id_required" }, 400);
    const users = await D().getAll("users");
    const kunden = await D().getAll("kunden");
    let rows = (await D().getAll("notizen")).filter((n) => !n.deleted_at);
    if (hatKunde) rows = rows.filter((n) => n.kunde_id === kundeId);
    if (hatListe) rows = rows.filter((n) => n.liste_id === listeId);
    if (hatItem) rows = rows.filter((n) => n.item_id === itemId);
    rows = rows.map((n) => ({
      ...n,
      erstellt_von_name: users.find((u) => u.id === n.erstellt_von)?.username || "",
      kunde_name: kunden.find((k) => k.id === n.kunde_id)?.name || null
    })).sort((a, b) => b.erstellt_am.localeCompare(a.erstellt_am));
    return json({ ok: true, notizen: rows });
  });
  post("/api/notizen", async ({ request }) => {
    const body = await bodyOf(request);
    let kundeId = Number(body.kunde_id);
    const kundeName = String(body.kunde_name || "").trim();
    const text = String(body.text || "").trim();
    const listeId = Number(body.liste_id) || null;
    const itemId = Number(body.item_id) || null;
    if (!Number.isFinite(kundeId) && !kundeName) return json({ error: "kunde_id_required" }, 400);
    if (!text) return json({ error: "text_required" }, 400);
    const au = activeUser();
    if (Number.isFinite(kundeId)) {
      const kunde = await D().get("kunden", kundeId);
      if (!kunde || kunde.deleted_at) return json({ error: "kunde_not_found" }, 404);
    } else {
      const bestehend = (await D().getAll("kunden")).find((k) => !k.deleted_at && k.name.toLowerCase() === kundeName.toLowerCase());
      if (bestehend) {
        kundeId = bestehend.id;
      } else {
        const neu = await D().add("kunden", stampNeu({ name: kundeName, erstellt_von: au?.id || 0, erstellt_am: new Date().toISOString() }));
        kundeId = neu.id;
      }
    }
    const jetzt = new Date().toISOString();
    // aktualisiert_am ist hier das "updated_at" für den WLAN-Sync (siehe
    // public/js/lan-sync.js) - Notizen hatten dieses Feld schon vor dem Sync,
    // ein zweites, separates updated_at würde nur auseinanderlaufen können.
    const rec = await D().add("notizen", { kunde_id: kundeId, text, liste_id: listeId, item_id: itemId, erstellt_von: au?.id || 0, erstellt_am: jetzt, aktualisiert_am: jetzt, client_uuid: crypto.randomUUID(), deleted_at: null });
    return json({ ok: true, notiz: rec });
  });
  put("/api/notizen/:id", async ({ params, request }) => {
    const n = await D().get("notizen", Number(params.id));
    if (!n || n.deleted_at) return json({ error: "not_found" }, 404);
    const au = activeUser();
    if (!isVerwalter("pflege") && n.erstellt_von !== au?.id) return json({ error: "forbidden" }, 403);
    const body = await bodyOf(request);
    const text = String(body.text || "").trim();
    if (!text) return json({ error: "text_required" }, 400);
    n.text = text;
    n.aktualisiert_am = new Date().toISOString();
    await D().put("notizen", n);
    return json({ ok: true, notiz: n });
  });
  // Soft-Delete (Tombstone für den WLAN-Sync) - kaskadiert als Soft-Delete
  // auf die zugehörigen Fotos (nehmen seit DB_VERSION 7 selbst am Sync teil,
  // siehe stampBildGeloescht oben).
  del("/api/notizen/:id", async ({ params }) => {
    const n = await D().get("notizen", Number(params.id));
    if (!n || n.deleted_at) return json({ error: "not_found" }, 404);
    const au = activeUser();
    if (!isVerwalter("pflege") && n.erstellt_von !== au?.id) return json({ error: "forbidden" }, 403);
    const bilder = await D().getAll("notiz_bilder");
    for (const b of bilder.filter((x) => x.notiz_id === n.id && !x.deleted_at)) await D().put("notiz_bilder", stampBildGeloescht(b));
    n.deleted_at = new Date().toISOString();
    n.aktualisiert_am = n.deleted_at;
    await D().put("notizen", n);
    return json({ ok: true });
  });

  // Foto-Anhänge zu Notizen - das Bild kommt bereits im Browser verkleinert/
  // komprimiert als JPEG-Data-URL an (siehe notizen.html) und wird direkt als
  // Blob im Store abgelegt (IndexedDB unterstützt Blob-Werte nativ).
  function dataUrlZuBlob(dataUrl) {
    const match = /^data:image\/jpeg;base64,(.+)$/.exec(String(dataUrl || ""));
    if (!match) return null;
    const binaer = atob(match[1]);
    const bytes = new Uint8Array(binaer.length);
    for (let i = 0; i < binaer.length; i++) bytes[i] = binaer.charCodeAt(i);
    return new Blob([bytes], { type: "image/jpeg" });
  }

  get("/api/notizen/:notizId/bilder", async ({ params }) => {
    const notizId = Number(params.notizId);
    const rows = (await D().getAll("notiz_bilder")).filter((b) => b.notiz_id === notizId && !b.deleted_at)
      .map((b) => ({ id: b.id, notiz_id: b.notiz_id, erstellt_am: b.erstellt_am }))
      .sort((a, b) => a.erstellt_am.localeCompare(b.erstellt_am));
    return json({ ok: true, bilder: rows });
  });
  post("/api/notizen/:notizId/bilder", async ({ params, request }) => {
    const notizId = Number(params.notizId);
    const n = await D().get("notizen", notizId);
    if (!n) return json({ error: "notiz_not_found" }, 404);
    const body = await bodyOf(request);
    const blob = dataUrlZuBlob(body.bild);
    if (!blob) return json({ error: "bild_required" }, 400);
    if (blob.size > 5 * 1024 * 1024) return json({ error: "bild_zu_gross" }, 413);
    const rec = await D().add("notiz_bilder", stampBildNeu({ notiz_id: notizId, blob, erstellt_am: new Date().toISOString() }));
    return json({ ok: true, bild: { id: rec.id, notiz_id: rec.notiz_id, erstellt_am: rec.erstellt_am } });
  });
  get("/api/notizen/bilder/:id", async ({ params }) => {
    const b = await D().get("notiz_bilder", Number(params.id));
    // "blob" fehlt auch kurzzeitig bei einer per WLAN-Sync gerade erst
    // eingetroffenen Foto-Zeile, deren Bild-Inhalt noch nicht nachgeladen
    // wurde (siehe lan-sync.js) - fuer die Anzeige nicht unterscheidbar von
    // "gibt es nicht", daher hier bewusst derselbe 404.
    if (!b || b.deleted_at || !b.blob) return json({ error: "not_found" }, 404);
    return new Response(b.blob, { status: 200, headers: { "Content-Type": "image/jpeg" } });
  });
  del("/api/notizen/bilder/:id", async ({ params }) => {
    const b = await D().get("notiz_bilder", Number(params.id));
    if (!b || b.deleted_at) return json({ error: "not_found" }, 404);
    const n = await D().get("notizen", b.notiz_id);
    const au = activeUser();
    if (!isVerwalter("pflege") && n && n.erstellt_von !== au?.id) return json({ error: "forbidden" }, 403);
    await D().put("notiz_bilder", stampBildGeloescht(b));
    return json({ ok: true });
  });

  // =============================================================== STATISTIK
  function parseDatumDE(s) {
    const t = String(s || "").split(".");
    if (t.length !== 3) return null;
    const d = new Date(Number(t[2]), Number(t[1]) - 1, Number(t[0]));
    return isNaN(d.getTime()) ? null : d;
  }
  function isoWoche(d) {
    const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    const wochentag = date.getUTCDay() || 7;
    date.setUTCDate(date.getUTCDate() + 4 - wochentag);
    const jahresStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
    return { jahr: date.getUTCFullYear(), kw: Math.ceil(((date - jahresStart) / 86400000 + 1) / 7) };
  }
  function wochenMontag(d) {
    const date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const wochentag = date.getDay() || 7;
    date.setDate(date.getDate() - (wochentag - 1));
    return date;
  }
  function kurzDatum(d) { return `${String(d.getDate()).padStart(2, "0")}.${String(d.getMonth() + 1).padStart(2, "0")}.`; }
  function runde(v) { return Math.round(v * 100) / 100; }
  // "MM.JJJJ" -> ISO-Von/Bis des Monats (fuer die Urlaub-Ueberschneidung).
  function monatsBereich(monat) {
    const [monatNum, jahr] = monat.split(".").map(Number);
    const letzterTag = new Date(jahr, monatNum, 0).getDate();
    const pad = (n) => String(n).padStart(2, "0");
    return { monatVon: `${jahr}-${pad(monatNum)}-01`, monatBis: `${jahr}-${pad(monatNum)}-${pad(letzterTag)}` };
  }
  // Ordnet einen Tagesbericht-Mitarbeiternamen einem echten Benutzerkonto zu
  // (gleiche Logik wie istEigener() unten, nur allgemein) - Urlaub haengt an
  // einer echten users.id, die Arbeitsstunden-Statistik nur an einem freien
  // Namensfeld.
  function findeUserFuerName(name, users) {
    const n = String(name || "").trim().toLocaleLowerCase("de-DE");
    return users.find((u) => {
      const un = String(u.username || "").trim().toLocaleLowerCase("de-DE");
      return un === n || n.split(/\s+/)[0] === un;
    }) || null;
  }
  get("/api/statistik/arbeitsstunden", async ({ url }) => {
    const au = activeUser();
    if (!au) return json({ ok: false, error: "unauthorized" }, 401);
    let monat = url.searchParams.get("monat") || "";
    if (!/^(0[1-9]|1[0-2])\.\d{4}$/.test(monat)) {
      const jetzt = new Date();
      monat = `${String(jetzt.getMonth() + 1).padStart(2, "0")}.${jetzt.getFullYear()}`;
    }
    const alleBerichte = (await D().getAll("tagesberichte")).filter((r) => !r.deleted_at);
    const rows = alleBerichte.filter((r) => String(r.data?.datum || "").endsWith(`.${monat}`));

    const userNorm = String(au.username || "").trim().toLocaleLowerCase("de-DE");
    const istEigener = (name) => {
      const n = String(name || "").trim().toLocaleLowerCase("de-DE");
      return n === userNorm || n.split(/\s+/)[0] === userNorm;
    };
    const eigene = { gesamtStunden: 0, einsaetze: 0, tage: new Set(), wochen: new Map() };
    const proMitarbeiter = new Map();
    for (const row of rows) {
      const datumText = row.data?.datum || "";
      const datum = parseDatumDE(datumText);
      for (const m of row.data?.mitarbeiter || []) {
        const name = String(m?.name || "").trim();
        if (!name) continue;
        const stunden = parseFloat(String(m.gesamt ?? "").replace(",", ".")) || 0;
        const key = name.toLocaleLowerCase("de-DE");
        if (!proMitarbeiter.has(key)) proMitarbeiter.set(key, { name, stunden: 0, einsaetze: 0, tage: new Set() });
        const alleEintrag = proMitarbeiter.get(key);
        alleEintrag.stunden += stunden; alleEintrag.einsaetze += 1;
        if (datumText) alleEintrag.tage.add(datumText);
        if (!istEigener(name)) continue;
        eigene.gesamtStunden += stunden; eigene.einsaetze += 1;
        if (datumText) eigene.tage.add(datumText);
        if (datum) {
          const { jahr, kw } = isoWoche(datum);
          const wKey = `${jahr}-${String(kw).padStart(2, "0")}`;
          if (!eigene.wochen.has(wKey)) {
            const montag = wochenMontag(datum);
            const sonntag = new Date(montag); sonntag.setDate(sonntag.getDate() + 6);
            eigene.wochen.set(wKey, { kw, zeitraum: `${kurzDatum(montag)} – ${kurzDatum(sonntag)}`, stunden: 0, tage: new Set() });
          }
          const woche = eigene.wochen.get(wKey);
          woche.stunden += stunden;
          if (datumText) woche.tage.add(datumText);
        }
      }
    }
    const wochenSchluesselMitArbeit = new Set(eigene.wochen.keys());
    const wochen = [...eigene.wochen.entries()].sort((a, b) => a[0].localeCompare(b[0]))
      .map(([, w]) => ({ kw: w.kw, zeitraum: w.zeitraum, tage: w.tage.size, stunden: runde(w.stunden) }));
    const tageGearbeitet = eigene.tage.size;

    // Urlaubstage im gewaehlten Monat fliessen in die Durchschnittswerte mit
    // ein (Ø Stunden/Tag und Ø Stunden/Woche laufen jetzt ueber Arbeits- UND
    // Urlaubstage) - "Tage gearbeitet" selbst bleibt unveraendert die reine
    // Ist-Arbeitszeit, Urlaubstage werden separat ausgewiesen.
    const { monatVon, monatBis } = monatsBereich(monat);
    const eigeneUrlaub = await ladeUrlaubstageImMonat(au.id, monatVon, monatBis);
    const tageGesamtFuerSchnitt = tageGearbeitet + eigeneUrlaub.tage;
    const wochenSchluesselGesamt = new Set([...wochenSchluesselMitArbeit, ...eigeneUrlaub.wochenSchluessel]);

    const antwort = {
      ok: true, monat, benutzer: au.username,
      eigene: {
        gesamtStunden: runde(eigene.gesamtStunden), einsaetze: eigene.einsaetze, tageGearbeitet,
        urlaubstage: eigeneUrlaub.tage,
        schnittProTag: tageGesamtFuerSchnitt ? runde(eigene.gesamtStunden / tageGesamtFuerSchnitt) : 0,
        wochen, wochenSchnitt: wochenSchluesselGesamt.size ? runde(eigene.gesamtStunden / wochenSchluesselGesamt.size) : 0
      }
    };
    if (hatBerechtigung("statistik", "ansehen")) {
      const alleUsers = (await D().getAll("users")).filter((u) => !u.deleted_at && u.is_active !== false);
      const alleListe = [...proMitarbeiter.values()].map((e) => ({ name: e.name, stunden: runde(e.stunden), einsaetze: e.einsaetze, arbeitstage: e.tage.size }));
      for (const eintrag of alleListe) {
        const match = findeUserFuerName(eintrag.name, alleUsers);
        eintrag.urlaubstage = match ? (await ladeUrlaubstageImMonat(match.id, monatVon, monatBis)).tage : null;
      }
      antwort.alle = alleListe.sort((a, b) => b.stunden - a.stunden || a.name.localeCompare(b.name, "de"));
      antwort.anzahlBerichte = rows.length;
    }
    return json(antwort);
  });

  // ================================================================== URLAUB
  // Eigenstaendiger Store (nicht Teil der tagesberichte.data-JSONB-Struktur -
  // dort gibt es keine echte FK zu users). Eintragen duerfen laut Anforderung
  // nur Admin/Vorarbeiter, kein Selbstbedienungs-Workflow. Nimmt am WLAN-Sync
  // teil (siehe public/js/lan-sync.js), daher stampNeu/stampGeaendert wie
  // ueberall sonst; echtes Loeschen statt Soft-Delete waere hier ein
  // Sync-Regressionsrisiko (Tombstone wuerde fehlen) - deshalb Soft-Delete wie
  // bei allen anderen Sync-Stores.
  function werktageInBereich(vonISO, bisISO) {
    const von = new Date(vonISO + "T00:00:00Z");
    const bis = new Date(bisISO + "T00:00:00Z");
    let anzahl = 0;
    for (let d = new Date(von); d <= bis; d.setUTCDate(d.getUTCDate() + 1)) {
      const wochentag = d.getUTCDay();
      if (wochentag !== 0 && wochentag !== 6) anzahl++;
    }
    return anzahl;
  }
  // Schneidet einen Zeitraum auf einen anderen (Jahr, Monat, ...) zurecht -
  // null, wenn sich die beiden Zeitraeume gar nicht ueberschneiden. Wird auch
  // von der Monatsstatistik unten (Urlaubstage im gewaehlten Monat) genutzt.
  function clampBereich(vonISO, bisISO, zeitraumVonISO, zeitraumBisISO) {
    const von = vonISO < zeitraumVonISO ? zeitraumVonISO : vonISO;
    const bis = bisISO > zeitraumBisISO ? zeitraumBisISO : bisISO;
    if (von > bis) return null;
    return { von, bis };
  }
  function clampAufJahr(vonISO, bisISO, jahr) {
    return clampBereich(vonISO, bisISO, `${jahr}-01-01`, `${jahr}-12-31`);
  }
  // Die ISO-Kalenderwochen (jahr-KW), die die Werktage eines Zeitraums
  // beruehren - genutzt in der Monatsstatistik, damit auch Wochen mit NUR
  // Urlaub (keine gearbeiteten Tage) in die "Ø Stunden/Woche"-Basis einfliessen.
  function wochenSchluesselFuerWerktage(vonISO, bisISO) {
    const schluessel = new Set();
    const von = new Date(vonISO + "T00:00:00Z");
    const bis = new Date(bisISO + "T00:00:00Z");
    for (let d = new Date(von); d <= bis; d.setUTCDate(d.getUTCDate() + 1)) {
      const wochentag = d.getUTCDay();
      if (wochentag === 0 || wochentag === 6) continue;
      const iso = new Date(d);
      const isoWochentag = iso.getUTCDay() || 7;
      iso.setUTCDate(iso.getUTCDate() + 4 - isoWochentag);
      const jahresStart = new Date(Date.UTC(iso.getUTCFullYear(), 0, 1));
      const kw = Math.ceil(((iso - jahresStart) / 86400000 + 1) / 7);
      schluessel.add(`${iso.getUTCFullYear()}-${String(kw).padStart(2, "0")}`);
    }
    return schluessel;
  }
  function parseJahr(v) {
    const jahr = Number(v);
    if (Number.isInteger(jahr) && jahr >= 2000 && jahr <= 2100) return jahr;
    return new Date().getFullYear();
  }
  // Urlaubstage (Werktage) eines Mitarbeiters im gewaehlten Monat + die dabei
  // beruehrten ISO-Kalenderwochen - Pendant zu backend/utils/werktage.js:
  // ladeUrlaubstageImMonat, hier ohne SQL direkt auf dem urlaub-Store.
  async function ladeUrlaubstageImMonat(mitarbeiterId, monatVon, monatBis) {
    const alle = (await D().getAll("urlaub")).filter((e) => !e.deleted_at && e.mitarbeiter_id === mitarbeiterId);
    let tage = 0;
    const wochenSchluessel = new Set();
    for (const e of alle) {
      const bereich = clampBereich(e.von_datum, e.bis_datum, monatVon, monatBis);
      if (!bereich) continue;
      tage += werktageInBereich(bereich.von, bereich.bis);
      for (const k of wochenSchluesselFuerWerktage(bereich.von, bereich.bis)) wochenSchluessel.add(k);
    }
    return { tage, wochenSchluessel };
  }
  async function ladeUrlaubZusammenfassung(mitarbeiterId, jahr) {
    const user = await D().get("users", mitarbeiterId);
    if (!user || user.deleted_at) return null;
    const alle = (await D().getAll("urlaub")).filter((e) => !e.deleted_at && e.mitarbeiter_id === mitarbeiterId);
    const jahrVon = `${jahr}-01-01`, jahrBis = `${jahr}-12-31`;
    const eintraege = alle.filter((e) => e.von_datum <= jahrBis && e.bis_datum >= jahrVon)
      .sort((a, b) => a.von_datum.localeCompare(b.von_datum));
    let genommen = 0;
    for (const e of eintraege) {
      const bereich = clampAufJahr(e.von_datum, e.bis_datum, jahr);
      if (bereich) genommen += werktageInBereich(bereich.von, bereich.bis);
    }
    const anspruch = user.urlaubsanspruch_tage ?? 30;
    return { mitarbeiter_id: user.id, username: user.username, jahr, anspruch, genommen, rest: anspruch - genommen, eintraege };
  }
  get("/api/urlaub", async ({ url }) => {
    const au = activeUser();
    if (!au) return json({ error: "unauthorized" }, 401);
    const jahr = parseJahr(url.searchParams.get("jahr"));
    let mitarbeiterId = au.id;
    const angefragtRaw = url.searchParams.get("mitarbeiter_id");
    if (angefragtRaw !== null) {
      const angefragt = Number(angefragtRaw);
      if (!Number.isFinite(angefragt)) return json({ error: "invalid_mitarbeiter_id" }, 400);
      if (angefragt !== au.id && !(await istVerwalterOderBerechtigung("urlaub", "ansehen"))) return json({ error: "forbidden" }, 403);
      mitarbeiterId = angefragt;
    }
    const zusammenfassung = await ladeUrlaubZusammenfassung(mitarbeiterId, jahr);
    if (!zusammenfassung) return json({ error: "user_not_found" }, 404);
    return json({ ok: true, ...zusammenfassung });
  });
  get("/api/urlaub/alle", async ({ url }) => {
    if (!(await istVerwalterOderBerechtigung("urlaub", "ansehen"))) return json({ error: "forbidden_vorarbeiter" }, 403);
    const jahr = parseJahr(url.searchParams.get("jahr"));
    const users = (await D().getAll("users")).filter((u) => !u.deleted_at && u.is_active !== false);
    const alle = [];
    for (const u of users) {
      const z = await ladeUrlaubZusammenfassung(u.id, jahr);
      if (z) alle.push(z);
    }
    return json({ ok: true, jahr, mitarbeiter: alle });
  });
  post("/api/urlaub", async ({ request }) => {
    if (!(await istVerwalterOderBerechtigung("urlaub", "anlegen"))) return json({ error: "forbidden_vorarbeiter" }, 403);
    const body = await bodyOf(request);
    const mitarbeiterId = Number(body.mitarbeiter_id);
    const vonDatum = String(body.von_datum || "");
    const bisDatum = String(body.bis_datum || "");
    const bemerkung = body.bemerkung ? String(body.bemerkung).trim() : null;
    if (!Number.isFinite(mitarbeiterId)) return json({ error: "mitarbeiter_id_required" }, 400);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(vonDatum) || !/^\d{4}-\d{2}-\d{2}$/.test(bisDatum)) return json({ error: "invalid_datum" }, 400);
    if (bisDatum < vonDatum) return json({ error: "bis_vor_von" }, 400);
    const mitarbeiter = await D().get("users", mitarbeiterId);
    if (!mitarbeiter || mitarbeiter.deleted_at) return json({ error: "mitarbeiter_not_found" }, 400);
    const au = activeUser();
    const rec = await D().add("urlaub", stampNeu({
      mitarbeiter_id: mitarbeiterId, von_datum: vonDatum, bis_datum: bisDatum, bemerkung,
      erstellt_von: au ? au.id : null, erstellt_am: new Date().toISOString()
    }));
    return json({ ok: true, urlaub: rec });
  });
  put("/api/urlaub/:id", async ({ params, request }) => {
    if (!(await istVerwalterOderBerechtigung("urlaub", "bearbeiten"))) return json({ error: "forbidden_vorarbeiter" }, 403);
    const e = await D().get("urlaub", Number(params.id));
    if (!e || e.deleted_at) return json({ error: "urlaub_not_found" }, 404);
    const body = await bodyOf(request);
    const vonDatum = body.von_datum !== undefined ? String(body.von_datum) : e.von_datum;
    const bisDatum = body.bis_datum !== undefined ? String(body.bis_datum) : e.bis_datum;
    if (body.von_datum !== undefined && !/^\d{4}-\d{2}-\d{2}$/.test(vonDatum)) return json({ error: "invalid_datum" }, 400);
    if (body.bis_datum !== undefined && !/^\d{4}-\d{2}-\d{2}$/.test(bisDatum)) return json({ error: "invalid_datum" }, 400);
    if (bisDatum < vonDatum) return json({ error: "bis_vor_von" }, 400);
    e.von_datum = vonDatum;
    e.bis_datum = bisDatum;
    if (body.bemerkung !== undefined) e.bemerkung = body.bemerkung ? String(body.bemerkung).trim() : null;
    stampGeaendert(e);
    await D().put("urlaub", e);
    return json({ ok: true, urlaub: e });
  });
  del("/api/urlaub/:id", async ({ params }) => {
    if (!(await istVerwalterOderBerechtigung("urlaub", "loeschen"))) return json({ error: "forbidden_vorarbeiter" }, 403);
    const e = await D().get("urlaub", Number(params.id));
    if (!e || e.deleted_at) return json({ error: "urlaub_not_found" }, 404);
    e.deleted_at = new Date().toISOString();
    stampGeaendert(e);
    await D().put("urlaub", e);
    return json({ ok: true });
  });

  // =================================================================== ROLLEN
  // Verwaltung frei anlegbarer Rollen (siehe hatBerechtigung/EINGEBAUTE_ROLLEN
  // oben) - Offline-Pendant zu backend/routes/rollen.routes.js. Wie die
  // Mitarbeiter-Verwaltung bewusst admin-only (nicht Vorarbeiter).
  function slugifiziereRolle(name) {
    const basis = String(name || "")
      .toLocaleLowerCase("de-DE")
      .replace(/ä/g, "ae").replace(/ö/g, "oe").replace(/ü/g, "ue").replace(/ß/g, "ss")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 40) || "rolle";
    return `${basis}-${Math.random().toString(36).slice(2, 7)}`;
  }
  get("/api/rollen", async () => {
    if (!isAdmin()) return json({ error: "forbidden_admin" }, 403);
    const rollen = (await D().getAll("rollen")).filter((r) => !r.deleted_at);
    rollen.sort((a, b) => (b.eingebaut - a.eingebaut) || a.name.localeCompare(b.name, "de"));
    return json({ ok: true, rollen });
  });
  post("/api/rollen", async ({ request }) => {
    if (!isAdmin()) return json({ error: "forbidden_admin" }, 403);
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);

    let berechtigungen = {};
    if (body.kopieren_von) {
      if (body.kopieren_von === "admin") {
        berechtigungen = JSON.parse(JSON.stringify(ADMIN_EFFEKTIVE_BERECHTIGUNGEN));
      } else {
        const quelle = await D().get("rollen", body.kopieren_von);
        if (!quelle || quelle.deleted_at) return json({ error: "quelle_nicht_gefunden" }, 404);
        berechtigungen = quelle.berechtigungen || {};
      }
    } else if (body.berechtigungen && typeof body.berechtigungen === "object") {
      berechtigungen = body.berechtigungen;
    }

    const id = slugifiziereRolle(name);
    const rec = await D().add("rollen", stampNeu({ id, name, eingebaut: false, berechtigungen, erstellt_am: new Date().toISOString() }));
    return json({ ok: true, rolle: rec });
  });
  put("/api/rollen/:id", async ({ params, request }) => {
    if (!isAdmin()) return json({ error: "forbidden_admin" }, 403);
    if (params.id === "admin") return json({ error: "eingebaute_rolle_nicht_editierbar" }, 400);
    const r = await D().get("rollen", params.id);
    if (!r || r.deleted_at) return json({ error: "rolle_nicht_gefunden" }, 404);
    const body = await bodyOf(request);
    if (body.name !== undefined) {
      const name = String(body.name).trim();
      if (!name) return json({ error: "name_required" }, 400);
      r.name = name;
    }
    if (body.berechtigungen !== undefined && typeof body.berechtigungen === "object") r.berechtigungen = body.berechtigungen;
    stampGeaendert(r);
    await D().put("rollen", r);
    return json({ ok: true, rolle: r });
  });
  del("/api/rollen/:id", async ({ params }) => {
    if (!isAdmin()) return json({ error: "forbidden_admin" }, 403);
    if (params.id === "admin") return json({ error: "eingebaute_rolle_nicht_loeschbar" }, 400);
    const r = await D().get("rollen", params.id);
    if (!r || r.deleted_at) return json({ error: "rolle_nicht_gefunden" }, 404);
    const zugewiesen = (await D().getAll("users")).filter((u) => !u.deleted_at && u.role === params.id);
    if (zugewiesen.length) return json({ error: "rolle_noch_zugewiesen", anzahl: zugewiesen.length }, 409);
    r.deleted_at = new Date().toISOString();
    stampGeaendert(r);
    await D().put("rollen", r);
    return json({ ok: true });
  });

  // ================================================================ BAUPLAENE
  // Bauplan-Tool: PDF/Bild oeffnen, mehrere ein-/ausblendbare Ebenen mit
  // Freihand-Strichen und Notiz-Pins - Offline-Pendant zu
  // backend/routes/bauplaene.routes.js. Ein hochgeladenes PDF wird im
  // Browser per pdf.js zu einem Bild gerendert (siehe bauplaene.html) - hier
  // kommt nie ein PDF selbst an, nur das fertige Bild als Data-URL. Anders
  // als bei notiz_bilder/heckenschnitt_bilder liegt das Bild-Blob direkt in
  // der bauplaene-Zeile selbst statt in einer eigenen Kind-Tabelle, da es
  // hier immer genau ein Bild je Bauplan gibt.
  function dataUrlZuBauplanBlob(dataUrl) {
    const match = /^data:image\/(png|jpeg);base64,(.+)$/.exec(String(dataUrl || ""));
    if (!match) return null;
    const binaer = atob(match[2]);
    const bytes = new Uint8Array(binaer.length);
    for (let i = 0; i < binaer.length; i++) bytes[i] = binaer.charCodeAt(i);
    return new Blob([bytes], { type: `image/${match[1]}` });
  }
  function mapBauplanEbene(e) {
    return { ...e, striche: e.striche ?? [], notizen: e.notizen ?? [] };
  }
  function ohneBauplanBild(b) {
    const { blob, ...rest } = b;
    return rest;
  }
  get("/api/bauplaene", async ({ url }) => {
    let plaene = (await D().getAll("bauplaene")).filter((b) => !b.deleted_at);
    const projektIdParam = url.searchParams.get("projekt_id");
    if (projektIdParam !== null) {
      const pid = Number(projektIdParam);
      if (!Number.isFinite(pid)) return json({ error: "invalid_projekt_id" }, 400);
      plaene = plaene.filter((b) => b.projekt_id === pid);
    }
    const [users, projekte, ebenen] = await Promise.all([
      D().getAll("users"), D().getAll("lv_bau_projekte"), D().getAll("bauplan_ebenen")
    ]);
    plaene.sort((a, b) => new Date(b.erstellt_am) - new Date(a.erstellt_am));
    const ergebnis = plaene.map((b) => ({
      ...ohneBauplanBild(b),
      projekt_name: projekte.find((p) => p.id === b.projekt_id)?.name || null,
      erstellt_von_name: users.find((u) => u.id === b.erstellt_von)?.username || null,
      ebenen_anzahl: ebenen.filter((e) => e.bauplan_id === b.id && !e.deleted_at).length
    }));
    return json({ ok: true, plaene: ergebnis });
  });
  post("/api/bauplaene", async ({ request }) => {
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);
    const breite = Number(body.breite);
    const hoehe = Number(body.hoehe);
    if (!Number.isFinite(breite) || !Number.isFinite(hoehe) || breite <= 0 || hoehe <= 0) {
      return json({ error: "invalid_masse" }, 400);
    }
    const blob = dataUrlZuBauplanBlob(body.bild);
    if (!blob) return json({ error: "bild_required" }, 400);
    if (blob.size > 20 * 1024 * 1024) return json({ error: "bild_zu_gross" }, 413);
    let projektId = null;
    if (body.projekt_id !== undefined && body.projekt_id !== null && body.projekt_id !== "") {
      projektId = Number(body.projekt_id);
      if (!Number.isFinite(projektId)) return json({ error: "invalid_projekt_id" }, 400);
      const p = await D().get("lv_bau_projekte", projektId);
      if (!p || p.deleted_at) return json({ error: "projekt_not_found" }, 400);
    }
    const au = activeUser();
    const rec = await D().add("bauplaene", stampBildNeu({
      name, projekt_id: projektId, breite, hoehe, blob,
      erstellt_von: au?.id || 0, erstellt_am: new Date().toISOString()
    }));
    return json({ ok: true, bauplan: ohneBauplanBild(rec) });
  });
  get("/api/bauplaene/:id/bild", async ({ params }) => {
    const b = await D().get("bauplaene", Number(params.id));
    if (!b || b.deleted_at || !b.blob) return json({ error: "not_found" }, 404);
    return new Response(b.blob, { status: 200, headers: { "Content-Type": b.blob.type || "image/jpeg" } });
  });
  get("/api/bauplaene/:id", async ({ params }) => {
    const id = Number(params.id);
    const b = await D().get("bauplaene", id);
    if (!b || b.deleted_at) return json({ error: "not_found" }, 404);
    const p = b.projekt_id ? await D().get("lv_bau_projekte", b.projekt_id) : null;
    const ebenen = (await D().getAll("bauplan_ebenen"))
      .filter((e) => e.bauplan_id === id && !e.deleted_at)
      .sort((a, c) => (a.reihenfolge - c.reihenfolge) || (a.id - c.id))
      .map(mapBauplanEbene);
    return json({ ok: true, bauplan: { ...ohneBauplanBild(b), projekt_name: p?.name || null }, ebenen });
  });
  put("/api/bauplaene/:id", async ({ params, request }) => {
    const id = Number(params.id);
    const b = await D().get("bauplaene", id);
    if (!b || b.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    if (body.name !== undefined) {
      const name = String(body.name).trim();
      if (!name) return json({ error: "name_required" }, 400);
      b.name = name;
    }
    if (body.projekt_id !== undefined) {
      b.projekt_id = body.projekt_id === null || body.projekt_id === "" ? null : Number(body.projekt_id);
    }
    if (body.pixel_pro_meter !== undefined) {
      const wert = body.pixel_pro_meter === null ? null : Number(body.pixel_pro_meter);
      if (wert !== null && (!Number.isFinite(wert) || wert <= 0)) return json({ error: "invalid_pixel_pro_meter" }, 400);
      b.pixel_pro_meter = wert;
    }
    stampGeaendert(b);
    await D().put("bauplaene", b);
    return json({ ok: true, bauplan: ohneBauplanBild(b) });
  });
  del("/api/bauplaene/:id", async ({ params }) => {
    const id = Number(params.id);
    const b = await D().get("bauplaene", id);
    if (!b || b.deleted_at) return json({ error: "not_found" }, 404);
    b.deleted_at = new Date().toISOString();
    stampGeaendert(b);
    await D().put("bauplaene", b);
    const ebenen = (await D().getAll("bauplan_ebenen")).filter((e) => e.bauplan_id === id && !e.deleted_at);
    for (const e of ebenen) {
      e.deleted_at = new Date().toISOString();
      stampGeaendert(e);
      await D().put("bauplan_ebenen", e);
    }
    return json({ ok: true });
  });
  post("/api/bauplaene/:id/ebenen", async ({ params, request }) => {
    const bauplanId = Number(params.id);
    const bauplan = await D().get("bauplaene", bauplanId);
    if (!bauplan || bauplan.deleted_at) return json({ error: "bauplan_not_found" }, 404);
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);
    const farbe = String(body.farbe || "#dc2626");
    const bestehende = (await D().getAll("bauplan_ebenen")).filter((e) => e.bauplan_id === bauplanId && !e.deleted_at);
    const reihenfolge = bestehende.length ? Math.max(...bestehende.map((e) => e.reihenfolge)) + 1 : 0;
    const au = activeUser();
    const rec = await D().add("bauplan_ebenen", stampNeu({
      bauplan_id: bauplanId, name, farbe, reihenfolge, striche: [], notizen: [], erstellt_von: au?.id || 0
    }));
    return json({ ok: true, ebene: mapBauplanEbene(rec) });
  });
  put("/api/bauplaene/ebenen/:id", async ({ params, request }) => {
    const id = Number(params.id);
    const e = await D().get("bauplan_ebenen", id);
    if (!e || e.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    if (body.name !== undefined) {
      const name = String(body.name).trim();
      if (!name) return json({ error: "name_required" }, 400);
      e.name = name;
    }
    if (body.farbe !== undefined) e.farbe = String(body.farbe);
    if (body.striche !== undefined) {
      if (!Array.isArray(body.striche)) return json({ error: "invalid_striche" }, 400);
      e.striche = body.striche;
    }
    if (body.notizen !== undefined) {
      if (!Array.isArray(body.notizen)) return json({ error: "invalid_notizen" }, 400);
      e.notizen = body.notizen;
    }
    stampGeaendert(e);
    await D().put("bauplan_ebenen", e);
    return json({ ok: true, ebene: mapBauplanEbene(e) });
  });
  del("/api/bauplaene/ebenen/:id", async ({ params }) => {
    const e = await D().get("bauplan_ebenen", Number(params.id));
    if (!e || e.deleted_at) return json({ error: "not_found" }, 404);
    e.deleted_at = new Date().toISOString();
    stampGeaendert(e);
    await D().put("bauplan_ebenen", e);
    return json({ ok: true });
  });

  // ================================================================= MATERIAL
  // Materialverbrauch (Bau) - Offline-Pendant zu
  // backend/routes/material.routes.js, siehe dort und
  // backend/migrations/039_material.sql fuer die Begruendung des Datenmodells.
  function stringListe(wert) {
    if (!Array.isArray(wert)) return [];
    return wert.map((v) => String(v ?? "").trim()).filter(Boolean);
  }
  function textOderNull(wert) {
    const s = String(wert ?? "").trim();
    return s || null;
  }

  get("/api/material/katalog", async () => {
    const katalog = (await D().getAll("material_katalog")).filter((k) => !k.deleted_at);
    katalog.sort((a, b) => String(a.gruppe || "Sonstiges").localeCompare(String(b.gruppe || "Sonstiges"), "de")
      || (b.eingebaut - a.eingebaut) || String(a.name).localeCompare(String(b.name), "de"));
    return json({ ok: true, katalog });
  });
  post("/api/material/katalog", async ({ request }) => {
    if (!isVerwalter("bau")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);
    const rec = await D().add("material_katalog", stampNeu({
      name,
      variante_label: String(body.variante_label || "Länge").trim() || "Länge",
      dimensionen: stringListe(body.dimensionen),
      varianten: stringListe(body.varianten),
      einheit: String(body.einheit || "Stück").trim() || "Stück",
      mengen_frei: !!body.mengen_frei,
      gruppe: String(body.gruppe || "Sonstiges").trim() || "Sonstiges",
      eingebaut: false, erstellt_am: new Date().toISOString()
    }));
    return json({ ok: true, eintrag: rec });
  });
  // Auch eingebaute KG-Eintraege duerfen bearbeitet werden (fehlende Dimension
  // nachtragen ist der Normalfall) - nur Loeschen bleibt ihnen verwehrt.
  put("/api/material/katalog/:id", async ({ params, request }) => {
    if (!isVerwalter("bau")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const k = await D().get("material_katalog", Number(params.id));
    if (!k || k.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    if (body.name !== undefined) {
      const name = String(body.name).trim();
      if (!name) return json({ error: "name_required" }, 400);
      k.name = name;
    }
    if (body.variante_label !== undefined) k.variante_label = String(body.variante_label).trim() || "Länge";
    if (body.dimensionen !== undefined) k.dimensionen = stringListe(body.dimensionen);
    if (body.varianten !== undefined) k.varianten = stringListe(body.varianten);
    if (body.einheit !== undefined) k.einheit = String(body.einheit).trim() || "Stück";
    if (body.mengen_frei !== undefined) k.mengen_frei = !!body.mengen_frei;
    if (body.gruppe !== undefined) k.gruppe = String(body.gruppe).trim() || "Sonstiges";
    stampGeaendert(k);
    await D().put("material_katalog", k);
    return json({ ok: true, eintrag: k });
  });
  del("/api/material/katalog/:id", async ({ params }) => {
    if (!isVerwalter("bau")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const k = await D().get("material_katalog", Number(params.id));
    if (!k || k.deleted_at) return json({ error: "not_found" }, 404);
    k.deleted_at = new Date().toISOString();
    stampGeaendert(k);
    await D().put("material_katalog", k);
    return json({ ok: true });
  });

  get("/api/material/listen", async () => {
    const listen = (await D().getAll("materiallisten")).filter((l) => !l.deleted_at);
    const eintraege = (await D().getAll("material_eintraege")).filter((e) => !e.deleted_at);
    const projekte = (await D().getAll("lv_bau_projekte")).filter((p) => !p.deleted_at);
    const angereichert = listen.map((l) => {
      const eigene = eintraege.filter((e) => e.liste_id === l.id);
      return {
        ...l,
        projekt_name: projekte.find((p) => p.id === l.projekt_id)?.name || null,
        eintraege_anzahl: eigene.length,
        menge_gesamt: eigene.reduce((s, e) => s + (Number(e.anzahl) || 0), 0)
      };
    });
    angereichert.sort((a, b) => new Date(b.erstellt_am) - new Date(a.erstellt_am));
    return json({ ok: true, listen: angereichert });
  });
  get("/api/material/listen/:id", async ({ params }) => {
    const liste = await D().get("materiallisten", Number(params.id));
    if (!liste || liste.deleted_at) return json({ error: "not_found" }, 404);
    const eintraege = (await D().getAll("material_eintraege"))
      .filter((e) => !e.deleted_at && e.liste_id === liste.id)
      .sort((a, b) => a.id - b.id);
    return json({ ok: true, liste, eintraege });
  });
  post("/api/material/listen", async ({ request }) => {
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);
    const au = activeUser();
    const rec = await D().add("materiallisten", stampNeu({
      name, projekt_id: Number(body.projekt_id) || null,
      beschreibung: textOderNull(body.beschreibung),
      erstellt_von: au?.id || null, erstellt_am: new Date().toISOString()
    }));
    return json({ ok: true, liste: rec });
  });
  put("/api/material/listen/:id", async ({ params, request }) => {
    const l = await D().get("materiallisten", Number(params.id));
    if (!l || l.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    const name = String(body.name || "").trim();
    if (!name) return json({ error: "name_required" }, 400);
    l.name = name;
    l.projekt_id = Number(body.projekt_id) || null;
    l.beschreibung = textOderNull(body.beschreibung);
    stampGeaendert(l);
    await D().put("materiallisten", l);
    return json({ ok: true, liste: l });
  });
  del("/api/material/listen/:id", async ({ params }) => {
    if (!isVerwalter("bau")) return json({ error: "forbidden_vorarbeiter" }, 403);
    const l = await D().get("materiallisten", Number(params.id));
    if (!l || l.deleted_at) return json({ error: "not_found" }, 404);
    const jetzt = new Date().toISOString();
    l.deleted_at = jetzt;
    stampGeaendert(l);
    await D().put("materiallisten", l);
    // Kaskade als Tombstone (siehe backend/routes/material.routes.js).
    for (const e of (await D().getAll("material_eintraege")).filter((e) => !e.deleted_at && e.liste_id === l.id)) {
      e.deleted_at = jetzt;
      stampGeaendert(e);
      await D().put("material_eintraege", e);
    }
    return json({ ok: true });
  });

  post("/api/material/listen/:id/eintraege", async ({ params, request }) => {
    const liste = await D().get("materiallisten", Number(params.id));
    if (!liste || liste.deleted_at) return json({ error: "liste_nicht_gefunden" }, 404);
    const body = await bodyOf(request);
    const material = String(body.material || "").trim();
    if (!material) return json({ error: "material_required" }, 400);
    const anzahl = Number(body.anzahl);
    if (!Number.isFinite(anzahl) || anzahl <= 0) return json({ error: "anzahl_ungueltig" }, 400);
    const au = activeUser();
    const rec = await D().add("material_eintraege", stampNeu({
      liste_id: liste.id, material,
      dimension: textOderNull(body.dimension), variante: textOderNull(body.variante),
      anzahl, einheit: textOderNull(body.einheit),
      datum: textOderNull(body.datum), bemerkung: textOderNull(body.bemerkung),
      erfasst_von: textOderNull(body.erfasst_von) || au?.username || null,
      erstellt_am: new Date().toISOString()
    }));
    return json({ ok: true, eintrag: rec });
  });
  put("/api/material/eintraege/:id", async ({ params, request }) => {
    const e = await D().get("material_eintraege", Number(params.id));
    if (!e || e.deleted_at) return json({ error: "not_found" }, 404);
    const body = await bodyOf(request);
    const anzahl = Number(body.anzahl);
    if (!Number.isFinite(anzahl) || anzahl <= 0) return json({ error: "anzahl_ungueltig" }, 400);
    e.anzahl = anzahl;
    e.bemerkung = textOderNull(body.bemerkung);
    e.datum = textOderNull(body.datum);
    stampGeaendert(e);
    await D().put("material_eintraege", e);
    return json({ ok: true, eintrag: e });
  });
  del("/api/material/eintraege/:id", async ({ params }) => {
    const e = await D().get("material_eintraege", Number(params.id));
    if (!e || e.deleted_at) return json({ error: "not_found" }, 404);
    e.deleted_at = new Date().toISOString();
    stampGeaendert(e);
    await D().put("material_eintraege", e);
    return json({ ok: true });
  });

  // =================================================================== WETTER
  // Live-Wetterdaten + geheimer API-Key sind ohne Server grundsätzlich nicht
  // möglich - bewusst immer "nicht verfügbar", das Frontend blendet die
  // Wetter-Karte dann still aus (siehe tagesbericht.html).
  get("/api/wetter", async () => json({ ok: false, error: "weather_not_configured" }, 503));

  // ----------------------------------------------------------- fetch-Shim
  async function handle(request) {
    const url = new URL(request.url, location.origin);
    // Matrix der aktiven Rolle pro Request frisch cachen, damit isVerwalter()
    // synchron bleiben kann und Rollen-Änderungen sofort greifen.
    await ladeAktiveBerechtigungen();
    for (const r of ROUTES) {
      if (r.method !== request.method) continue;
      const m = url.pathname.match(r.pattern);
      if (m) {
        try {
          return await r.handler({ request, url, params: m.groups || {} });
        } catch (err) {
          console.error("local-api Fehler:", request.method, url.pathname, err);
          return json({ ok: false, error: "local_api_error" }, 500);
        }
      }
    }
    return json({ ok: false, error: "not_found" }, 404);
  }

  window.fetch = async function (input, init) {
    const url = typeof input === "string" ? input : input.url;
    if (url && url.startsWith("/api/")) {
      await (window.LocalDB && window.LocalDB.ensureSeeded ? window.LocalDB.ensureSeeded() : Promise.resolve());
      return handle(new Request(input, init));
    }
    return originalFetch(input, init);
  };
})();
