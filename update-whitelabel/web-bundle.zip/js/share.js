// Gemeinsames Speichern/Teilen von Dateien (PDF, Excel, CSV, ...) - server-lose App.
//
// In einer normalen Browser-Registerkarte funktioniert ein <a download>-Klick
// zuverlässig (Browser-Downloadmanager). In der als Capacitor-App verpackten
// WebView auf dem Gerät gibt es dafür aber keinen Download-Handler - ein Klick
// auf einen blob:-Link passiert dort einfach nichts sicht- oder spürbares (das
// war zuerst beim PDF-Export aufgefallen, betrifft aber genauso jeden anderen
// Export-Button, der nur mit <a download> arbeitet). Auf dem Gerät wird die
// Datei deshalb über die nativen Capacitor-Plugins Filesystem (ins
// Cache-Verzeichnis schreiben, braucht keine Berechtigung) + Share (nativer
// Teilen/Öffnen/Speichern-Dialog von Android) ausgeliefert - darüber lässt
// sich die Datei direkt öffnen (z.B. mit Excel/Sheets) oder z.B. nach
// "Downloads"/Drive/WhatsApp weitergeben.
(function () {
  "use strict";

  function istNativeApp() {
    return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  }

  function blobZuBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(String(reader.result).split(",")[1] || "");
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
  }

  function browserDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  // Einzelne Datei speichern/teilen - je nach Umgebung nativ oder im Browser.
  async function speichereUndTeile(blob, filename) {
    if (!istNativeApp()) { browserDownload(blob, filename); return; }
    const { Filesystem, Share } = window.Capacitor.Plugins;
    const base64 = await blobZuBase64(blob);
    const datei = await Filesystem.writeFile({ path: filename, data: base64, directory: "CACHE" });
    await Share.share({ title: filename, files: [datei.uri] });
  }

  // Mehrere Dateien auf einmal teilen (Bulk-Export) - nativ in einem einzigen
  // Teilen-Dialog mit allen Dateien, im Browser nacheinander als Download.
  async function speichereUndTeileMehrere(dateien) {
    if (!dateien.length) return;
    if (!istNativeApp()) {
      for (const { blob, filename } of dateien) {
        browserDownload(blob, filename);
        await new Promise((r) => setTimeout(r, 400)); // sonst blockt der Browser Mehrfach-Downloads
      }
      return;
    }
    const { Filesystem, Share } = window.Capacitor.Plugins;
    const uris = [];
    for (const { blob, filename } of dateien) {
      const base64 = await blobZuBase64(blob);
      const datei = await Filesystem.writeFile({ path: filename, data: base64, directory: "CACHE" });
      uris.push(datei.uri);
    }
    await Share.share({ title: `${dateien.length} Dateien`, files: uris });
  }

  window.Share = { speichereUndTeile, speichereUndTeileMehrere, istNativeApp };
})();
