// Geräte-Erinnerungen für Kalender-Termine (nur in der installierten App).
//
// Nutzt das Capacitor-Plugin @capacitor/local-notifications, das komplett
// offline funktioniert (kein Push-Server nötig) - passend zur server-losen
// App. Jeder Termin bekommt, falls eine Erinnerung gewählt wurde (Feld
// "erinnerung_minuten" in public/js/local-api.js), eine geplante
// Benachrichtigung unter seiner eigenen lokalen ID; beim Bearbeiten/Löschen/
// Abschließen (siehe public/kalender.html, public/tagesbericht.html) wird sie
// neu geplant bzw. entfernt.
(function () {
  "use strict";

  function plugin() {
    if (!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform())) return null;
    return (window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications) || null;
  }

  let berechtigungOk = null; // Cache, damit nicht bei jedem Aufruf erneut gefragt wird
  async function sicherstellenBerechtigung(LocalNotifications) {
    if (berechtigungOk !== null) return berechtigungOk;
    try {
      const status = await LocalNotifications.checkPermissions();
      if (status.display === "granted") { berechtigungOk = true; return true; }
      const angefragt = await LocalNotifications.requestPermissions();
      berechtigungOk = angefragt.display === "granted";
    } catch (err) {
      console.warn("Benachrichtigungs-Berechtigung konnte nicht geprüft werden:", err);
      berechtigungOk = false;
    }
    return berechtigungOk;
  }

  // Android 12+ (API 31+) verlangt für einen "exakten" Alarm (AlarmManager)
  // zusätzlich diese Berechtigung - fehlt sie, löst der Wecker im
  // Hintergrund/Ruhezustand des Geräts stark verzögert oder gar nicht mehr
  // aus, während er bei geöffneter App unauffällig funktioniert (genau das
  // gemeldete Symptom). Ohne Play-Store-Vertrieb wird USE_EXACT_ALARM
  // automatisch erteilt; dieser Hinweis greift daher nur auf Geräten, bei
  // denen zusätzlich SCHEDULE_EXACT_ALARM manuell in den Einstellungen
  // freigegeben werden muss (i.d.R. Android 12/12L).
  const BANNER_DISMISS_KEY = "go-exact-alarm-hinweis-am";
  async function zeigeExakteAlarmHinweisFallsNoetig(LocalNotifications, hatAktiveErinnerungen) {
    if (!hatAktiveErinnerungen || document.getElementById("goExactAlarmHinweis")) return;
    try {
      const status = await LocalNotifications.checkExactNotificationSetting();
      if (status.exact_alarm === "granted") return;
    } catch {
      return; // Methode auf diesem Geräte/Plugin-Stand nicht verfügbar - nichts erzwingen
    }
    const heute = new Date().toISOString().slice(0, 10);
    if (localStorage.getItem(BANNER_DISMISS_KEY) === heute) return; // höchstens 1x/Tag anzeigen

    const banner = document.createElement("div");
    banner.id = "goExactAlarmHinweis";
    banner.className = "fixed left-0 right-0 bottom-0 z-[998] bg-amber-50 border-t border-amber-200 text-amber-800 text-sm px-4 py-3 flex items-center justify-between gap-3 flex-wrap";
    banner.innerHTML = `
      <span><i class="fa-solid fa-triangle-exclamation mr-2"></i>Für zuverlässige Termin-Erinnerungen bitte "Alarme &amp; Erinnerungen" für diese App erlauben.</span>
      <span class="flex gap-2">
        <button id="goExactAlarmErlauben" class="px-3 py-1.5 rounded-lg bg-amber-600 text-white text-xs font-bold hover:bg-amber-700">Einstellungen öffnen</button>
        <button id="goExactAlarmSchliessen" class="px-3 py-1.5 rounded-lg bg-white border border-amber-300 text-xs font-bold hover:bg-amber-100">Später</button>
      </span>`;
    document.body.appendChild(banner);
    document.getElementById("goExactAlarmErlauben").addEventListener("click", async () => {
      try { await LocalNotifications.changeExactNotificationSetting(); } catch (err) { console.warn("Alarm-Einstellung konnte nicht geöffnet werden:", err); }
      banner.remove();
    });
    document.getElementById("goExactAlarmSchliessen").addEventListener("click", () => {
      localStorage.setItem(BANNER_DISMISS_KEY, heute);
      banner.remove();
    });
  }

  function terminZeitpunkt(termin) {
    if (!termin || !termin.datum) return null;
    const zeit = termin.von || "09:00";
    const dt = new Date(`${termin.datum}T${zeit}:00`);
    return Number.isNaN(dt.getTime()) ? null : dt;
  }

  // Neu plant (bzw. entfernt, wenn "keine" gewählt ist) die Erinnerung für
  // genau diesen Termin - immer zuerst abbestellen, dann ggf. neu anlegen,
  // damit Bearbeiten nie zu doppelten Benachrichtigungen führt.
  async function planeErinnerung(termin) {
    const LocalNotifications = plugin();
    if (!LocalNotifications || !termin || !termin.id) return;
    try {
      await LocalNotifications.cancel({ notifications: [{ id: termin.id }] });
      const minuten = termin.erinnerung_minuten;
      if (minuten === null || minuten === undefined) return;
      if (termin.status === "erledigt" || termin.status === "abgesagt") return;
      const start = terminZeitpunkt(termin);
      if (!start) return;
      const wann = new Date(start.getTime() - minuten * 60000);
      if (wann.getTime() <= Date.now()) return; // liegt schon in der Vergangenheit
      if (!(await sicherstellenBerechtigung(LocalNotifications))) return;
      await LocalNotifications.schedule({
        notifications: [{
          id: termin.id,
          title: termin.titel || "Termin",
          body: [termin.kunde, termin.von ? `um ${termin.von} Uhr` : ""].filter(Boolean).join(" – ") || "Erinnerung an deinen Termin",
          schedule: { at: wann }
        }]
      });
    } catch (err) {
      console.warn("Erinnerung konnte nicht geplant werden:", err);
    }
  }

  async function entferneErinnerung(terminId) {
    const LocalNotifications = plugin();
    if (!LocalNotifications || !terminId) return;
    try {
      await LocalNotifications.cancel({ notifications: [{ id: terminId }] });
    } catch (err) {
      console.warn("Erinnerung konnte nicht entfernt werden:", err);
    }
  }

  // Beim App-Start alle Termine mit gewünschter Erinnerung durchgehen und
  // (neu) planen - fängt Termine ab, die auf einem anderen Gerät oder vor
  // dieser Funktion angelegt wurden, sowie geplante Benachrichtigungen, die
  // ein App-Update/Neustart verloren haben könnte.
  async function alleNeuPlanen() {
    const LocalNotifications = plugin();
    if (!LocalNotifications || !window.LocalDB) return;
    try {
      const termine = await window.LocalDB.getAll("termine");
      const relevante = termine.filter((t) =>
        t.erinnerung_minuten !== null && t.erinnerung_minuten !== undefined &&
        t.status !== "erledigt" && t.status !== "abgesagt"
      );
      for (const t of relevante) await planeErinnerung(t);
      await zeigeExakteAlarmHinweisFallsNoetig(LocalNotifications, relevante.length > 0);
    } catch (err) {
      console.warn("Erinnerungen konnten nicht neu geplant werden:", err);
    }
  }

  window.GONotifications = { planeErinnerung, entferneErinnerung, alleNeuPlanen };

  function start() { alleNeuPlanen(); }
  if (document.readyState === "complete") start();
  else window.addEventListener("load", start);
})();
